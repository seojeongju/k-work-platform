var ss=Object.defineProperty;var Nt=e=>{throw TypeError(e)};var as=(e,t,r)=>t in e?ss(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r;var y=(e,t,r)=>as(e,typeof t!="symbol"?t+"":t,r),lt=(e,t,r)=>t.has(e)||Nt("Cannot "+r);var u=(e,t,r)=>(lt(e,t,"read from private field"),r?r.call(e):t.get(e)),x=(e,t,r)=>t.has(e)?Nt("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,r),_=(e,t,r,s)=>(lt(e,t,"write to private field"),s?s.call(e,r):t.set(e,r),r),S=(e,t,r)=>(lt(e,t,"access private method"),r);var It=(e,t,r,s)=>({set _(a){_(e,t,a,r)},get _(){return u(e,t,s)}});var Mt=(e,t,r)=>(s,a)=>{let n=-1;return o(0);async function o(i){if(i<=n)throw new Error("next() called multiple times");n=i;let l,c=!1,d;if(e[i]?(d=e[i][0][0],s.req.routeIndex=i):d=i===e.length&&a||void 0,d)try{l=await d(s,()=>o(i+1))}catch(p){if(p instanceof Error&&t)s.error=p,l=await t(p,s),c=!0;else throw p}else s.finalized===!1&&r&&(l=await r(s));return l&&(s.finalized===!1||c)&&(s.res=l),s}},ns=Symbol(),os=async(e,t=Object.create(null))=>{const{all:r=!1,dot:s=!1}=t,n=(e instanceof vr?e.raw.headers:e.headers).get("Content-Type");return n!=null&&n.startsWith("multipart/form-data")||n!=null&&n.startsWith("application/x-www-form-urlencoded")?is(e,{all:r,dot:s}):{}};async function is(e,t){const r=await e.formData();return r?ls(r,t):{}}function ls(e,t){const r=Object.create(null);return e.forEach((s,a)=>{t.all||a.endsWith("[]")?cs(r,a,s):r[a]=s}),t.dot&&Object.entries(r).forEach(([s,a])=>{s.includes(".")&&(ds(r,s,a),delete r[s])}),r}var cs=(e,t,r)=>{e[t]!==void 0?Array.isArray(e[t])?e[t].push(r):e[t]=[e[t],r]:t.endsWith("[]")?e[t]=[r]:e[t]=r},ds=(e,t,r)=>{let s=e;const a=t.split(".");a.forEach((n,o)=>{o===a.length-1?s[n]=r:((!s[n]||typeof s[n]!="object"||Array.isArray(s[n])||s[n]instanceof File)&&(s[n]=Object.create(null)),s=s[n])})},pr=e=>{const t=e.split("/");return t[0]===""&&t.shift(),t},us=e=>{const{groups:t,path:r}=ps(e),s=pr(r);return ms(s,t)},ps=e=>{const t=[];return e=e.replace(/\{[^}]+\}/g,(r,s)=>{const a=`@${s}`;return t.push([a,r]),a}),{groups:t,path:e}},ms=(e,t)=>{for(let r=t.length-1;r>=0;r--){const[s]=t[r];for(let a=e.length-1;a>=0;a--)if(e[a].includes(s)){e[a]=e[a].replace(s,t[r][1]);break}}return e},$e={},fs=(e,t)=>{if(e==="*")return"*";const r=e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(r){const s=`${e}#${t}`;return $e[s]||(r[2]?$e[s]=t&&t[0]!==":"&&t[0]!=="*"?[s,r[1],new RegExp(`^${r[2]}(?=/${t})`)]:[e,r[1],new RegExp(`^${r[2]}$`)]:$e[s]=[e,r[1],!0]),$e[s]}return null},Tt=(e,t)=>{try{return t(e)}catch{return e.replace(/(?:%[0-9A-Fa-f]{2})+/g,r=>{try{return t(r)}catch{return r}})}},hs=e=>Tt(e,decodeURI),mr=e=>{const t=e.url,r=t.indexOf("/",t.charCodeAt(9)===58?13:8);let s=r;for(;s<t.length;s++){const a=t.charCodeAt(s);if(a===37){const n=t.indexOf("?",s),o=t.slice(r,n===-1?void 0:n);return hs(o.includes("%25")?o.replace(/%25/g,"%2525"):o)}else if(a===63)break}return t.slice(r,s)},gs=e=>{const t=mr(e);return t.length>1&&t.at(-1)==="/"?t.slice(0,-1):t},me=(e,t,...r)=>(r.length&&(t=me(t,...r)),`${(e==null?void 0:e[0])==="/"?"":"/"}${e}${t==="/"?"":`${(e==null?void 0:e.at(-1))==="/"?"":"/"}${(t==null?void 0:t[0])==="/"?t.slice(1):t}`}`),fr=e=>{if(e.charCodeAt(e.length-1)!==63||!e.includes(":"))return null;const t=e.split("/"),r=[];let s="";return t.forEach(a=>{if(a!==""&&!/\:/.test(a))s+="/"+a;else if(/\:/.test(a))if(/\?/.test(a)){r.length===0&&s===""?r.push("/"):r.push(s);const n=a.replace("?","");s+="/"+n,r.push(s)}else s+="/"+a}),r.filter((a,n,o)=>o.indexOf(a)===n)},ct=e=>/[%+]/.test(e)?(e.indexOf("+")!==-1&&(e=e.replace(/\+/g," ")),e.indexOf("%")!==-1?Tt(e,gr):e):e,hr=(e,t,r)=>{let s;if(!r&&t&&!/[%+]/.test(t)){let o=e.indexOf(`?${t}`,8);for(o===-1&&(o=e.indexOf(`&${t}`,8));o!==-1;){const i=e.charCodeAt(o+t.length+1);if(i===61){const l=o+t.length+2,c=e.indexOf("&",l);return ct(e.slice(l,c===-1?void 0:c))}else if(i==38||isNaN(i))return"";o=e.indexOf(`&${t}`,o+1)}if(s=/[%+]/.test(e),!s)return}const a={};s??(s=/[%+]/.test(e));let n=e.indexOf("?",8);for(;n!==-1;){const o=e.indexOf("&",n+1);let i=e.indexOf("=",n);i>o&&o!==-1&&(i=-1);let l=e.slice(n+1,i===-1?o===-1?void 0:o:i);if(s&&(l=ct(l)),n=o,l==="")continue;let c;i===-1?c="":(c=e.slice(i+1,o===-1?void 0:o),s&&(c=ct(c))),r?(a[l]&&Array.isArray(a[l])||(a[l]=[]),a[l].push(c)):a[l]??(a[l]=c)}return t?a[t]:a},vs=hr,bs=(e,t)=>hr(e,t,!0),gr=decodeURIComponent,Ft=e=>Tt(e,gr),ge,F,V,br,yr,yt,Q,sr,vr=(sr=class{constructor(e,t="/",r=[[]]){x(this,V);y(this,"raw");x(this,ge);x(this,F);y(this,"routeIndex",0);y(this,"path");y(this,"bodyCache",{});x(this,Q,e=>{const{bodyCache:t,raw:r}=this,s=t[e];if(s)return s;const a=Object.keys(t)[0];return a?t[a].then(n=>(a==="json"&&(n=JSON.stringify(n)),new Response(n)[e]())):t[e]=r[e]()});this.raw=e,this.path=t,_(this,F,r),_(this,ge,{})}param(e){return e?S(this,V,br).call(this,e):S(this,V,yr).call(this)}query(e){return vs(this.url,e)}queries(e){return bs(this.url,e)}header(e){if(e)return this.raw.headers.get(e)??void 0;const t={};return this.raw.headers.forEach((r,s)=>{t[s]=r}),t}async parseBody(e){var t;return(t=this.bodyCache).parsedBody??(t.parsedBody=await os(this,e))}json(){return u(this,Q).call(this,"text").then(e=>JSON.parse(e))}text(){return u(this,Q).call(this,"text")}arrayBuffer(){return u(this,Q).call(this,"arrayBuffer")}blob(){return u(this,Q).call(this,"blob")}formData(){return u(this,Q).call(this,"formData")}addValidatedData(e,t){u(this,ge)[e]=t}valid(e){return u(this,ge)[e]}get url(){return this.raw.url}get method(){return this.raw.method}get[ns](){return u(this,F)}get matchedRoutes(){return u(this,F)[0].map(([[,e]])=>e)}get routePath(){return u(this,F)[0].map(([[,e]])=>e)[this.routeIndex].path}},ge=new WeakMap,F=new WeakMap,V=new WeakSet,br=function(e){const t=u(this,F)[0][this.routeIndex][1][e],r=S(this,V,yt).call(this,t);return r?/\%/.test(r)?Ft(r):r:void 0},yr=function(){const e={},t=Object.keys(u(this,F)[0][this.routeIndex][1]);for(const r of t){const s=S(this,V,yt).call(this,u(this,F)[0][this.routeIndex][1][r]);s&&typeof s=="string"&&(e[r]=/\%/.test(s)?Ft(s):s)}return e},yt=function(e){return u(this,F)[1]?u(this,F)[1][e]:e},Q=new WeakMap,sr),_r={Stringify:1},L=(e,t)=>{const r=new String(e);return r.isEscaped=!0,r.callbacks=t,r},ys=/[&<>'"]/,jr=async(e,t)=>{let r="";t||(t=[]);const s=await Promise.all(e);for(let a=s.length-1;r+=s[a],a--,!(a<0);a--){let n=s[a];typeof n=="object"&&t.push(...n.callbacks||[]);const o=n.isEscaped;if(n=await(typeof n=="object"?n.toString():n),typeof n=="object"&&t.push(...n.callbacks||[]),n.isEscaped??o)r+=n;else{const i=[r];se(n,i),r=i[0]}}return L(r,t)},se=(e,t)=>{const r=e.search(ys);if(r===-1){t[0]+=e;return}let s,a,n=0;for(a=r;a<e.length;a++){switch(e.charCodeAt(a)){case 34:s="&quot;";break;case 39:s="&#39;";break;case 38:s="&amp;";break;case 60:s="&lt;";break;case 62:s="&gt;";break;default:continue}t[0]+=e.substring(n,a)+s,n=a+1}t[0]+=e.substring(n,a)},Er=e=>{const t=e.callbacks;if(!(t!=null&&t.length))return e;const r=[e],s={};return t.forEach(a=>a({phase:_r.Stringify,buffer:r,context:s})),r[0]},wr=async(e,t,r,s,a)=>{typeof e=="object"&&!(e instanceof String)&&(e instanceof Promise||(e=e.toString()),e instanceof Promise&&(e=await e));const n=e.callbacks;return n!=null&&n.length?(a?a[0]+=e:a=[e],Promise.all(n.map(i=>i({phase:t,buffer:a,context:s}))).then(i=>Promise.all(i.filter(Boolean).map(l=>wr(l,t,!1,s,a))).then(()=>a[0]))):Promise.resolve(e)},_s="text/plain; charset=UTF-8",dt=(e,t)=>({"Content-Type":e,...t}),Ae,Ne,$,ve,J,I,Ie,be,ye,oe,Me,Fe,X,fe,ar,js=(ar=class{constructor(e,t){x(this,X);x(this,Ae);x(this,Ne);y(this,"env",{});x(this,$);y(this,"finalized",!1);y(this,"error");x(this,ve);x(this,J);x(this,I);x(this,Ie);x(this,be);x(this,ye);x(this,oe);x(this,Me);x(this,Fe);y(this,"render",(...e)=>(u(this,be)??_(this,be,t=>this.html(t)),u(this,be).call(this,...e)));y(this,"setLayout",e=>_(this,Ie,e));y(this,"getLayout",()=>u(this,Ie));y(this,"setRenderer",e=>{_(this,be,e)});y(this,"header",(e,t,r)=>{this.finalized&&_(this,I,new Response(u(this,I).body,u(this,I)));const s=u(this,I)?u(this,I).headers:u(this,oe)??_(this,oe,new Headers);t===void 0?s.delete(e):r!=null&&r.append?s.append(e,t):s.set(e,t)});y(this,"status",e=>{_(this,ve,e)});y(this,"set",(e,t)=>{u(this,$)??_(this,$,new Map),u(this,$).set(e,t)});y(this,"get",e=>u(this,$)?u(this,$).get(e):void 0);y(this,"newResponse",(...e)=>S(this,X,fe).call(this,...e));y(this,"body",(e,t,r)=>S(this,X,fe).call(this,e,t,r));y(this,"text",(e,t,r)=>!u(this,oe)&&!u(this,ve)&&!t&&!r&&!this.finalized?new Response(e):S(this,X,fe).call(this,e,t,dt(_s,r)));y(this,"json",(e,t,r)=>S(this,X,fe).call(this,JSON.stringify(e),t,dt("application/json",r)));y(this,"html",(e,t,r)=>{const s=a=>S(this,X,fe).call(this,a,t,dt("text/html; charset=UTF-8",r));return typeof e=="object"?wr(e,_r.Stringify,!1,{}).then(s):s(e)});y(this,"redirect",(e,t)=>{const r=String(e);return this.header("Location",/[^\x00-\xFF]/.test(r)?encodeURI(r):r),this.newResponse(null,t??302)});y(this,"notFound",()=>(u(this,ye)??_(this,ye,()=>new Response),u(this,ye).call(this,this)));_(this,Ae,e),t&&(_(this,J,t.executionCtx),this.env=t.env,_(this,ye,t.notFoundHandler),_(this,Fe,t.path),_(this,Me,t.matchResult))}get req(){return u(this,Ne)??_(this,Ne,new vr(u(this,Ae),u(this,Fe),u(this,Me))),u(this,Ne)}get event(){if(u(this,J)&&"respondWith"in u(this,J))return u(this,J);throw Error("This context has no FetchEvent")}get executionCtx(){if(u(this,J))return u(this,J);throw Error("This context has no ExecutionContext")}get res(){return u(this,I)||_(this,I,new Response(null,{headers:u(this,oe)??_(this,oe,new Headers)}))}set res(e){if(u(this,I)&&e){e=new Response(e.body,e);for(const[t,r]of u(this,I).headers.entries())if(t!=="content-type")if(t==="set-cookie"){const s=u(this,I).headers.getSetCookie();e.headers.delete("set-cookie");for(const a of s)e.headers.append("set-cookie",a)}else e.headers.set(t,r)}_(this,I,e),this.finalized=!0}get var(){return u(this,$)?Object.fromEntries(u(this,$)):{}}},Ae=new WeakMap,Ne=new WeakMap,$=new WeakMap,ve=new WeakMap,J=new WeakMap,I=new WeakMap,Ie=new WeakMap,be=new WeakMap,ye=new WeakMap,oe=new WeakMap,Me=new WeakMap,Fe=new WeakMap,X=new WeakSet,fe=function(e,t,r){const s=u(this,I)?new Headers(u(this,I).headers):u(this,oe)??new Headers;if(typeof t=="object"&&"headers"in t){const n=t.headers instanceof Headers?t.headers:new Headers(t.headers);for(const[o,i]of n)o.toLowerCase()==="set-cookie"?s.append(o,i):s.set(o,i)}if(r)for(const[n,o]of Object.entries(r))if(typeof o=="string")s.set(n,o);else{s.delete(n);for(const i of o)s.append(n,i)}const a=typeof t=="number"?t:(t==null?void 0:t.status)??u(this,ve);return new Response(e,{status:a,headers:s})},ar),O="ALL",Es="all",ws=["get","post","put","delete","options","patch"],xr="Can not add a route since the matcher is already built.",Tr=class extends Error{},xs="__COMPOSED_HANDLER",Ts=e=>e.text("404 Not Found",404),Lt=(e,t)=>{if("getResponse"in e){const r=e.getResponse();return t.newResponse(r.body,r)}return console.error(e),t.text("Internal Server Error",500)},q,C,Rr,B,ae,Ye,Ve,nr,Sr=(nr=class{constructor(t={}){x(this,C);y(this,"get");y(this,"post");y(this,"put");y(this,"delete");y(this,"options");y(this,"patch");y(this,"all");y(this,"on");y(this,"use");y(this,"router");y(this,"getPath");y(this,"_basePath","/");x(this,q,"/");y(this,"routes",[]);x(this,B,Ts);y(this,"errorHandler",Lt);y(this,"onError",t=>(this.errorHandler=t,this));y(this,"notFound",t=>(_(this,B,t),this));y(this,"fetch",(t,...r)=>S(this,C,Ve).call(this,t,r[1],r[0],t.method));y(this,"request",(t,r,s,a)=>t instanceof Request?this.fetch(r?new Request(t,r):t,s,a):(t=t.toString(),this.fetch(new Request(/^https?:\/\//.test(t)?t:`http://localhost${me("/",t)}`,r),s,a)));y(this,"fire",()=>{addEventListener("fetch",t=>{t.respondWith(S(this,C,Ve).call(this,t.request,t,void 0,t.request.method))})});[...ws,Es].forEach(n=>{this[n]=(o,...i)=>(typeof o=="string"?_(this,q,o):S(this,C,ae).call(this,n,u(this,q),o),i.forEach(l=>{S(this,C,ae).call(this,n,u(this,q),l)}),this)}),this.on=(n,o,...i)=>{for(const l of[o].flat()){_(this,q,l);for(const c of[n].flat())i.map(d=>{S(this,C,ae).call(this,c.toUpperCase(),u(this,q),d)})}return this},this.use=(n,...o)=>(typeof n=="string"?_(this,q,n):(_(this,q,"*"),o.unshift(n)),o.forEach(i=>{S(this,C,ae).call(this,O,u(this,q),i)}),this);const{strict:s,...a}=t;Object.assign(this,a),this.getPath=s??!0?t.getPath??mr:gs}route(t,r){const s=this.basePath(t);return r.routes.map(a=>{var o;let n;r.errorHandler===Lt?n=a.handler:(n=async(i,l)=>(await Mt([],r.errorHandler)(i,()=>a.handler(i,l))).res,n[xs]=a.handler),S(o=s,C,ae).call(o,a.method,a.path,n)}),this}basePath(t){const r=S(this,C,Rr).call(this);return r._basePath=me(this._basePath,t),r}mount(t,r,s){let a,n;s&&(typeof s=="function"?n=s:(n=s.optionHandler,s.replaceRequest===!1?a=l=>l:a=s.replaceRequest));const o=n?l=>{const c=n(l);return Array.isArray(c)?c:[c]}:l=>{let c;try{c=l.executionCtx}catch{}return[l.env,c]};a||(a=(()=>{const l=me(this._basePath,t),c=l==="/"?0:l.length;return d=>{const p=new URL(d.url);return p.pathname=p.pathname.slice(c)||"/",new Request(p,d)}})());const i=async(l,c)=>{const d=await r(a(l.req.raw),...o(l));if(d)return d;await c()};return S(this,C,ae).call(this,O,me(t,"*"),i),this}},q=new WeakMap,C=new WeakSet,Rr=function(){const t=new Sr({router:this.router,getPath:this.getPath});return t.errorHandler=this.errorHandler,_(t,B,u(this,B)),t.routes=this.routes,t},B=new WeakMap,ae=function(t,r,s){t=t.toUpperCase(),r=me(this._basePath,r);const a={basePath:this._basePath,path:r,method:t,handler:s};this.router.add(t,r,[s,a]),this.routes.push(a)},Ye=function(t,r){if(t instanceof Error)return this.errorHandler(t,r);throw t},Ve=function(t,r,s,a){if(a==="HEAD")return(async()=>new Response(null,await S(this,C,Ve).call(this,t,r,s,"GET")))();const n=this.getPath(t,{env:s}),o=this.router.match(a,n),i=new js(t,{path:n,matchResult:o,env:s,executionCtx:r,notFoundHandler:u(this,B)});if(o[0].length===1){let c;try{c=o[0][0][0][0](i,async()=>{i.res=await u(this,B).call(this,i)})}catch(d){return S(this,C,Ye).call(this,d,i)}return c instanceof Promise?c.then(d=>d||(i.finalized?i.res:u(this,B).call(this,i))).catch(d=>S(this,C,Ye).call(this,d,i)):c??u(this,B).call(this,i)}const l=Mt(o[0],this.errorHandler,u(this,B));return(async()=>{try{const c=await l(i);if(!c.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return c.res}catch(c){return S(this,C,Ye).call(this,c,i)}})()},nr),tt="[^/]+",Re=".*",ke="(?:|/.*)",he=Symbol(),Ss=new Set(".\\+*[^]$()");function Rs(e,t){return e.length===1?t.length===1?e<t?-1:1:-1:t.length===1||e===Re||e===ke?1:t===Re||t===ke?-1:e===tt?1:t===tt?-1:e.length===t.length?e<t?-1:1:t.length-e.length}var ie,le,H,or,_t=(or=class{constructor(){x(this,ie);x(this,le);x(this,H,Object.create(null))}insert(t,r,s,a,n){if(t.length===0){if(u(this,ie)!==void 0)throw he;if(n)return;_(this,ie,r);return}const[o,...i]=t,l=o==="*"?i.length===0?["","",Re]:["","",tt]:o==="/*"?["","",ke]:o.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let c;if(l){const d=l[1];let p=l[2]||tt;if(d&&l[2]&&(p===".*"||(p=p.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(p))))throw he;if(c=u(this,H)[p],!c){if(Object.keys(u(this,H)).some(m=>m!==Re&&m!==ke))throw he;if(n)return;c=u(this,H)[p]=new _t,d!==""&&_(c,le,a.varIndex++)}!n&&d!==""&&s.push([d,u(c,le)])}else if(c=u(this,H)[o],!c){if(Object.keys(u(this,H)).some(d=>d.length>1&&d!==Re&&d!==ke))throw he;if(n)return;c=u(this,H)[o]=new _t}c.insert(i,r,s,a,n)}buildRegExpStr(){const r=Object.keys(u(this,H)).sort(Rs).map(s=>{const a=u(this,H)[s];return(typeof u(a,le)=="number"?`(${s})@${u(a,le)}`:Ss.has(s)?`\\${s}`:s)+a.buildRegExpStr()});return typeof u(this,ie)=="number"&&r.unshift(`#${u(this,ie)}`),r.length===0?"":r.length===1?r[0]:"(?:"+r.join("|")+")"}},ie=new WeakMap,le=new WeakMap,H=new WeakMap,or),nt,Le,ir,ks=(ir=class{constructor(){x(this,nt,{varIndex:0});x(this,Le,new _t)}insert(e,t,r){const s=[],a=[];for(let o=0;;){let i=!1;if(e=e.replace(/\{[^}]+\}/g,l=>{const c=`@\\${o}`;return a[o]=[c,l],o++,i=!0,c}),!i)break}const n=e.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let o=a.length-1;o>=0;o--){const[i]=a[o];for(let l=n.length-1;l>=0;l--)if(n[l].indexOf(i)!==-1){n[l]=n[l].replace(i,a[o][1]);break}}return u(this,Le).insert(n,t,s,u(this,nt),r),s}buildRegExp(){let e=u(this,Le).buildRegExpStr();if(e==="")return[/^$/,[],[]];let t=0;const r=[],s=[];return e=e.replace(/#(\d+)|@(\d+)|\.\*\$/g,(a,n,o)=>n!==void 0?(r[++t]=Number(n),"$()"):(o!==void 0&&(s[Number(o)]=++t),"")),[new RegExp(`^${e}`),r,s]}},nt=new WeakMap,Le=new WeakMap,ir),kr=[],Ds=[/^$/,[],Object.create(null)],Ke=Object.create(null);function Dr(e){return Ke[e]??(Ke[e]=new RegExp(e==="*"?"":`^${e.replace(/\/\*$|([.\\+*[^\]$()])/g,(t,r)=>r?`\\${r}`:"(?:|/.*)")}$`))}function Os(){Ke=Object.create(null)}function Cs(e){var c;const t=new ks,r=[];if(e.length===0)return Ds;const s=e.map(d=>[!/\*|\/:/.test(d[0]),...d]).sort(([d,p],[m,h])=>d?1:m?-1:p.length-h.length),a=Object.create(null);for(let d=0,p=-1,m=s.length;d<m;d++){const[h,v,g]=s[d];h?a[v]=[g.map(([j])=>[j,Object.create(null)]),kr]:p++;let b;try{b=t.insert(v,p,h)}catch(j){throw j===he?new Tr(v):j}h||(r[p]=g.map(([j,w])=>{const T=Object.create(null);for(w-=1;w>=0;w--){const[E,D]=b[w];T[E]=D}return[j,T]}))}const[n,o,i]=t.buildRegExp();for(let d=0,p=r.length;d<p;d++)for(let m=0,h=r[d].length;m<h;m++){const v=(c=r[d][m])==null?void 0:c[1];if(!v)continue;const g=Object.keys(v);for(let b=0,j=g.length;b<j;b++)v[g[b]]=i[v[g[b]]]}const l=[];for(const d in o)l[d]=r[o[d]];return[n,l,a]}function ue(e,t){if(e){for(const r of Object.keys(e).sort((s,a)=>a.length-s.length))if(Dr(r).test(t))return[...e[r]]}}var Z,ee,we,Or,Cr,lr,As=(lr=class{constructor(){x(this,we);y(this,"name","RegExpRouter");x(this,Z);x(this,ee);_(this,Z,{[O]:Object.create(null)}),_(this,ee,{[O]:Object.create(null)})}add(e,t,r){var i;const s=u(this,Z),a=u(this,ee);if(!s||!a)throw new Error(xr);s[e]||[s,a].forEach(l=>{l[e]=Object.create(null),Object.keys(l[O]).forEach(c=>{l[e][c]=[...l[O][c]]})}),t==="/*"&&(t="*");const n=(t.match(/\/:/g)||[]).length;if(/\*$/.test(t)){const l=Dr(t);e===O?Object.keys(s).forEach(c=>{var d;(d=s[c])[t]||(d[t]=ue(s[c],t)||ue(s[O],t)||[])}):(i=s[e])[t]||(i[t]=ue(s[e],t)||ue(s[O],t)||[]),Object.keys(s).forEach(c=>{(e===O||e===c)&&Object.keys(s[c]).forEach(d=>{l.test(d)&&s[c][d].push([r,n])})}),Object.keys(a).forEach(c=>{(e===O||e===c)&&Object.keys(a[c]).forEach(d=>l.test(d)&&a[c][d].push([r,n]))});return}const o=fr(t)||[t];for(let l=0,c=o.length;l<c;l++){const d=o[l];Object.keys(a).forEach(p=>{var m;(e===O||e===p)&&((m=a[p])[d]||(m[d]=[...ue(s[p],d)||ue(s[O],d)||[]]),a[p][d].push([r,n-c+l+1]))})}}match(e,t){Os();const r=S(this,we,Or).call(this);return this.match=(s,a)=>{const n=r[s]||r[O],o=n[2][a];if(o)return o;const i=a.match(n[0]);if(!i)return[[],kr];const l=i.indexOf("",1);return[n[1][l],i]},this.match(e,t)}},Z=new WeakMap,ee=new WeakMap,we=new WeakSet,Or=function(){const e=Object.create(null);return Object.keys(u(this,ee)).concat(Object.keys(u(this,Z))).forEach(t=>{e[t]||(e[t]=S(this,we,Cr).call(this,t))}),_(this,Z,_(this,ee,void 0)),e},Cr=function(e){const t=[];let r=e===O;return[u(this,Z),u(this,ee)].forEach(s=>{const a=s[e]?Object.keys(s[e]).map(n=>[n,s[e][n]]):[];a.length!==0?(r||(r=!0),t.push(...a)):e!==O&&t.push(...Object.keys(s[O]).map(n=>[n,s[O][n]]))}),r?Cs(t):null},lr),te,z,cr,Ns=(cr=class{constructor(e){y(this,"name","SmartRouter");x(this,te,[]);x(this,z,[]);_(this,te,e.routers)}add(e,t,r){if(!u(this,z))throw new Error(xr);u(this,z).push([e,t,r])}match(e,t){if(!u(this,z))throw new Error("Fatal error");const r=u(this,te),s=u(this,z),a=r.length;let n=0,o;for(;n<a;n++){const i=r[n];try{for(let l=0,c=s.length;l<c;l++)i.add(...s[l]);o=i.match(e,t)}catch(l){if(l instanceof Tr)continue;throw l}this.match=i.match.bind(i),_(this,te,[i]),_(this,z,void 0);break}if(n===a)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,o}get activeRouter(){if(u(this,z)||u(this,te).length!==1)throw new Error("No active router has been determined yet.");return u(this,te)[0]}},te=new WeakMap,z=new WeakMap,cr),Te=Object.create(null),re,N,ce,_e,A,Y,ne,dr,Ar=(dr=class{constructor(e,t,r){x(this,Y);x(this,re);x(this,N);x(this,ce);x(this,_e,0);x(this,A,Te);if(_(this,N,r||Object.create(null)),_(this,re,[]),e&&t){const s=Object.create(null);s[e]={handler:t,possibleKeys:[],score:0},_(this,re,[s])}_(this,ce,[])}insert(e,t,r){_(this,_e,++It(this,_e)._);let s=this;const a=us(t),n=[];for(let o=0,i=a.length;o<i;o++){const l=a[o],c=a[o+1],d=fs(l,c),p=Array.isArray(d)?d[0]:l;if(p in u(s,N)){s=u(s,N)[p],d&&n.push(d[1]);continue}u(s,N)[p]=new Ar,d&&(u(s,ce).push(d),n.push(d[1])),s=u(s,N)[p]}return u(s,re).push({[e]:{handler:r,possibleKeys:n.filter((o,i,l)=>l.indexOf(o)===i),score:u(this,_e)}}),s}search(e,t){var i;const r=[];_(this,A,Te);let a=[this];const n=pr(t),o=[];for(let l=0,c=n.length;l<c;l++){const d=n[l],p=l===c-1,m=[];for(let h=0,v=a.length;h<v;h++){const g=a[h],b=u(g,N)[d];b&&(_(b,A,u(g,A)),p?(u(b,N)["*"]&&r.push(...S(this,Y,ne).call(this,u(b,N)["*"],e,u(g,A))),r.push(...S(this,Y,ne).call(this,b,e,u(g,A)))):m.push(b));for(let j=0,w=u(g,ce).length;j<w;j++){const T=u(g,ce)[j],E=u(g,A)===Te?{}:{...u(g,A)};if(T==="*"){const G=u(g,N)["*"];G&&(r.push(...S(this,Y,ne).call(this,G,e,u(g,A))),_(G,A,E),m.push(G));continue}const[D,M,K]=T;if(!d&&!(K instanceof RegExp))continue;const U=u(g,N)[D],rs=n.slice(l).join("/");if(K instanceof RegExp){const G=K.exec(rs);if(G){if(E[M]=G[0],r.push(...S(this,Y,ne).call(this,U,e,u(g,A),E)),Object.keys(u(U,N)).length){_(U,A,E);const it=((i=G[0].match(/\//))==null?void 0:i.length)??0;(o[it]||(o[it]=[])).push(U)}continue}}(K===!0||K.test(d))&&(E[M]=d,p?(r.push(...S(this,Y,ne).call(this,U,e,E,u(g,A))),u(U,N)["*"]&&r.push(...S(this,Y,ne).call(this,u(U,N)["*"],e,E,u(g,A)))):(_(U,A,E),m.push(U)))}}a=m.concat(o.shift()??[])}return r.length>1&&r.sort((l,c)=>l.score-c.score),[r.map(({handler:l,params:c})=>[l,c])]}},re=new WeakMap,N=new WeakMap,ce=new WeakMap,_e=new WeakMap,A=new WeakMap,Y=new WeakSet,ne=function(e,t,r,s){const a=[];for(let n=0,o=u(e,re).length;n<o;n++){const i=u(e,re)[n],l=i[t]||i[O],c={};if(l!==void 0&&(l.params=Object.create(null),a.push(l),r!==Te||s&&s!==Te))for(let d=0,p=l.possibleKeys.length;d<p;d++){const m=l.possibleKeys[d],h=c[l.score];l.params[m]=s!=null&&s[m]&&!h?s[m]:r[m]??(s==null?void 0:s[m]),c[l.score]=!0}}return a},dr),de,ur,Is=(ur=class{constructor(){y(this,"name","TrieRouter");x(this,de);_(this,de,new Ar)}add(e,t,r){const s=fr(t);if(s){for(let a=0,n=s.length;a<n;a++)u(this,de).insert(e,s[a],r);return}u(this,de).insert(e,t,r)}match(e,t){return u(this,de).search(e,t)}},de=new WeakMap,ur),Nr=class extends Sr{constructor(e={}){super(e),this.router=e.router??new Ns({routers:[new As,new Is]})}},Ms=e=>{const r={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...e},s=(n=>typeof n=="string"?n==="*"?()=>n:o=>n===o?o:null:typeof n=="function"?n:o=>n.includes(o)?o:null)(r.origin),a=(n=>typeof n=="function"?n:Array.isArray(n)?()=>n:()=>[])(r.allowMethods);return async function(o,i){var d;function l(p,m){o.res.headers.set(p,m)}const c=s(o.req.header("origin")||"",o);if(c&&l("Access-Control-Allow-Origin",c),r.origin!=="*"){const p=o.req.header("Vary");p?l("Vary",p):l("Vary","Origin")}if(r.credentials&&l("Access-Control-Allow-Credentials","true"),(d=r.exposeHeaders)!=null&&d.length&&l("Access-Control-Expose-Headers",r.exposeHeaders.join(",")),o.req.method==="OPTIONS"){r.maxAge!=null&&l("Access-Control-Max-Age",r.maxAge.toString());const p=a(o.req.header("origin")||"",o);p.length&&l("Access-Control-Allow-Methods",p.join(","));let m=r.allowHeaders;if(!(m!=null&&m.length)){const h=o.req.header("Access-Control-Request-Headers");h&&(m=h.split(/\s*,\s*/))}return m!=null&&m.length&&(l("Access-Control-Allow-Headers",m.join(",")),o.res.headers.append("Vary","Access-Control-Request-Headers")),o.res.headers.delete("Content-Length"),o.res.headers.delete("Content-Type"),new Response(null,{headers:o.res.headers,status:204,statusText:"No Content"})}await i()}},Ir=e=>Mr(e.replace(/_|-/g,t=>({_:"/","-":"+"})[t]??t)),Mr=e=>{const t=atob(e),r=new Uint8Array(new ArrayBuffer(t.length)),s=t.length/2;for(let a=0,n=t.length-1;a<=s;a++,n--)r[a]=t.charCodeAt(a),r[n]=t.charCodeAt(n);return r},Fr=(e=>(e.HS256="HS256",e.HS384="HS384",e.HS512="HS512",e.RS256="RS256",e.RS384="RS384",e.RS512="RS512",e.PS256="PS256",e.PS384="PS384",e.PS512="PS512",e.ES256="ES256",e.ES384="ES384",e.ES512="ES512",e.EdDSA="EdDSA",e))(Fr||{}),Fs={deno:"Deno",bun:"Bun",workerd:"Cloudflare-Workers",node:"Node.js"},Ls=()=>{var r,s;const e=globalThis;if(typeof navigator<"u"&&typeof navigator.userAgent=="string"){for(const[a,n]of Object.entries(Fs))if(qs(n))return a}return typeof(e==null?void 0:e.EdgeRuntime)=="string"?"edge-light":(e==null?void 0:e.fastly)!==void 0?"fastly":((s=(r=e==null?void 0:e.process)==null?void 0:r.release)==null?void 0:s.name)==="node"?"node":"other"},qs=e=>navigator.userAgent.startsWith(e),Bs=class extends Error{constructor(e){super(`${e} is not an implemented algorithm`),this.name="JwtAlgorithmNotImplemented"}},Lr=class extends Error{constructor(e){super(`invalid JWT token: ${e}`),this.name="JwtTokenInvalid"}},Hs=class extends Error{constructor(e){super(`token (${e}) is being used before it's valid`),this.name="JwtTokenNotBefore"}},Ps=class extends Error{constructor(e){super(`token (${e}) expired`),this.name="JwtTokenExpired"}},Us=class extends Error{constructor(e,t){super(`Invalid "iat" claim, must be a valid number lower than "${e}" (iat: "${t}")`),this.name="JwtTokenIssuedAt"}},ut=class extends Error{constructor(e,t){super(`expected issuer "${e}", got ${t?`"${t}"`:"none"} `),this.name="JwtTokenIssuer"}},Ws=class extends Error{constructor(e){super(`jwt header is invalid: ${JSON.stringify(e)}`),this.name="JwtHeaderInvalid"}},$s=class extends Error{constructor(e){super(`token(${e}) signature mismatched`),this.name="JwtTokenSignatureMismatched"}},rt=(e=>(e.Encrypt="encrypt",e.Decrypt="decrypt",e.Sign="sign",e.Verify="verify",e.DeriveKey="deriveKey",e.DeriveBits="deriveBits",e.WrapKey="wrapKey",e.UnwrapKey="unwrapKey",e))(rt||{}),qr=new TextEncoder,Js=new TextDecoder;async function zs(e,t,r,s){const a=Vs(t),n=await Ys(e,a);return await crypto.subtle.verify(a,n,r,s)}function qt(e){return Mr(e.replace(/-+(BEGIN|END).*/g,"").replace(/\s/g,""))}async function Ys(e,t){if(!crypto.subtle||!crypto.subtle.importKey)throw new Error("`crypto.subtle.importKey` is undefined. JWT auth middleware requires it.");if(Ks(e)){if(e.type==="public"||e.type==="secret")return e;e=await Bt(e)}if(typeof e=="string"&&e.includes("PRIVATE")){const s=await crypto.subtle.importKey("pkcs8",qt(e),t,!0,[rt.Sign]);e=await Bt(s)}const r=[rt.Verify];return typeof e=="object"?await crypto.subtle.importKey("jwk",e,t,!1,r):e.includes("PUBLIC")?await crypto.subtle.importKey("spki",qt(e),t,!1,r):await crypto.subtle.importKey("raw",qr.encode(e),t,!1,r)}async function Bt(e){if(e.type!=="private")throw new Error(`unexpected key type: ${e.type}`);if(!e.extractable)throw new Error("unexpected private key is unextractable");const t=await crypto.subtle.exportKey("jwk",e),{kty:r}=t,{alg:s,e:a,n}=t,{crv:o,x:i,y:l}=t;return{kty:r,alg:s,e:a,n,crv:o,x:i,y:l,key_ops:[rt.Verify]}}function Vs(e){switch(e){case"HS256":return{name:"HMAC",hash:{name:"SHA-256"}};case"HS384":return{name:"HMAC",hash:{name:"SHA-384"}};case"HS512":return{name:"HMAC",hash:{name:"SHA-512"}};case"RS256":return{name:"RSASSA-PKCS1-v1_5",hash:{name:"SHA-256"}};case"RS384":return{name:"RSASSA-PKCS1-v1_5",hash:{name:"SHA-384"}};case"RS512":return{name:"RSASSA-PKCS1-v1_5",hash:{name:"SHA-512"}};case"PS256":return{name:"RSA-PSS",hash:{name:"SHA-256"},saltLength:32};case"PS384":return{name:"RSA-PSS",hash:{name:"SHA-384"},saltLength:48};case"PS512":return{name:"RSA-PSS",hash:{name:"SHA-512"},saltLength:64};case"ES256":return{name:"ECDSA",hash:{name:"SHA-256"},namedCurve:"P-256"};case"ES384":return{name:"ECDSA",hash:{name:"SHA-384"},namedCurve:"P-384"};case"ES512":return{name:"ECDSA",hash:{name:"SHA-512"},namedCurve:"P-521"};case"EdDSA":return{name:"Ed25519",namedCurve:"Ed25519"};default:throw new Bs(e)}}function Ks(e){return Ls()==="node"&&crypto.webcrypto?e instanceof crypto.webcrypto.CryptoKey:e instanceof CryptoKey}var Ht=e=>JSON.parse(Js.decode(Ir(e)));function Gs(e){if(typeof e=="object"&&e!==null){const t=e;return"alg"in t&&Object.values(Fr).includes(t.alg)&&(!("typ"in t)||t.typ==="JWT")}return!1}var Qs=async(e,t,r)=>{const s=typeof r=="string"?{alg:r}:r||{},a={alg:s.alg??"HS256",iss:s.iss,nbf:s.nbf??!0,exp:s.exp??!0,iat:s.iat??!0},n=e.split(".");if(n.length!==3)throw new Lr(e);const{header:o,payload:i}=Xs(e);if(!Gs(o))throw new Ws(o);const l=Date.now()/1e3|0;if(a.nbf&&i.nbf&&i.nbf>l)throw new Hs(e);if(a.exp&&i.exp&&i.exp<=l)throw new Ps(e);if(a.iat&&i.iat&&l<i.iat)throw new Us(l,i.iat);if(a.iss){if(!i.iss)throw new ut(a.iss,null);if(typeof a.iss=="string"&&i.iss!==a.iss)throw new ut(a.iss,i.iss);if(a.iss instanceof RegExp&&!a.iss.test(i.iss))throw new ut(a.iss,i.iss)}const c=e.substring(0,e.lastIndexOf("."));if(!await zs(t,a.alg,Ir(n[2]),qr.encode(c)))throw new $s(e);return i},Xs=e=>{try{const[t,r]=e.split("."),s=Ht(t),a=Ht(r);return{header:s,payload:a}}catch{throw new Lr(e)}},Zs={verify:Qs},qe=Zs.verify,ea=/^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i,Pt=(e,t=ra)=>{const r=/\.([a-zA-Z0-9]+?)$/,s=e.match(r);if(!s)return;let a=t[s[1]];return a&&a.startsWith("text")&&(a+="; charset=utf-8"),a},ta={aac:"audio/aac",avi:"video/x-msvideo",avif:"image/avif",av1:"video/av1",bin:"application/octet-stream",bmp:"image/bmp",css:"text/css",csv:"text/csv",eot:"application/vnd.ms-fontobject",epub:"application/epub+zip",gif:"image/gif",gz:"application/gzip",htm:"text/html",html:"text/html",ico:"image/x-icon",ics:"text/calendar",jpeg:"image/jpeg",jpg:"image/jpeg",js:"text/javascript",json:"application/json",jsonld:"application/ld+json",map:"application/json",mid:"audio/x-midi",midi:"audio/x-midi",mjs:"text/javascript",mp3:"audio/mpeg",mp4:"video/mp4",mpeg:"video/mpeg",oga:"audio/ogg",ogv:"video/ogg",ogx:"application/ogg",opus:"audio/opus",otf:"font/otf",pdf:"application/pdf",png:"image/png",rtf:"application/rtf",svg:"image/svg+xml",tif:"image/tiff",tiff:"image/tiff",ts:"video/mp2t",ttf:"font/ttf",txt:"text/plain",wasm:"application/wasm",webm:"video/webm",weba:"audio/webm",webmanifest:"application/manifest+json",webp:"image/webp",woff:"font/woff",woff2:"font/woff2",xhtml:"application/xhtml+xml",xml:"application/xml",zip:"application/zip","3gp":"video/3gpp","3g2":"video/3gpp2",gltf:"model/gltf+json",glb:"model/gltf-binary"},ra=ta,sa=(...e)=>{let t=e.filter(a=>a!=="").join("/");t=t.replace(new RegExp("(?<=\\/)\\/+","g"),"");const r=t.split("/"),s=[];for(const a of r)a===".."&&s.length>0&&s.at(-1)!==".."?s.pop():a!=="."&&s.push(a);return s.join("/")||"."},Br={br:".br",zstd:".zst",gzip:".gz"},aa=Object.keys(Br),na="index.html",oa=e=>{const t=e.root??"./",r=e.path,s=e.join??sa;return async(a,n)=>{var d,p,m,h;if(a.finalized)return n();let o;if(e.path)o=e.path;else try{if(o=decodeURIComponent(a.req.path),/(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(o))throw new Error}catch{return await((d=e.onNotFound)==null?void 0:d.call(e,a.req.path,a)),n()}let i=s(t,!r&&e.rewriteRequestPath?e.rewriteRequestPath(o):o);e.isDir&&await e.isDir(i)&&(i=s(i,na));const l=e.getContent;let c=await l(i,a);if(c instanceof Response)return a.newResponse(c.body,c);if(c){const v=e.mimes&&Pt(i,e.mimes)||Pt(i);if(a.header("Content-Type",v||"application/octet-stream"),e.precompressed&&(!v||ea.test(v))){const g=new Set((p=a.req.header("Accept-Encoding"))==null?void 0:p.split(",").map(b=>b.trim()));for(const b of aa){if(!g.has(b))continue;const j=await l(i+Br[b],a);if(j){c=j,a.header("Content-Encoding",b),a.header("Vary","Accept-Encoding",{append:!0});break}}}return await((m=e.onFound)==null?void 0:m.call(e,i,a)),a.body(c)}await((h=e.onNotFound)==null?void 0:h.call(e,i,a)),await n()}},ia=async(e,t)=>{let r;t&&t.manifest?typeof t.manifest=="string"?r=JSON.parse(t.manifest):r=t.manifest:typeof __STATIC_CONTENT_MANIFEST=="string"?r=JSON.parse(__STATIC_CONTENT_MANIFEST):r=__STATIC_CONTENT_MANIFEST;let s;t&&t.namespace?s=t.namespace:s=__STATIC_CONTENT;const a=r[e]||e;if(!a)return null;const n=await s.get(a,{type:"stream"});return n||null},la=e=>async function(r,s){return oa({...e,getContent:async n=>ia(n,{manifest:e.manifest,namespace:e.namespace?e.namespace:r.env?r.env.__STATIC_CONTENT:void 0})})(r,s)},ca=e=>la(e),da=(e,...t)=>{const r=[""];for(let s=0,a=e.length-1;s<a;s++){r[0]+=e[s];const n=Array.isArray(t[s])?t[s].flat(1/0):[t[s]];for(let o=0,i=n.length;o<i;o++){const l=n[o];if(typeof l=="string")se(l,r);else if(typeof l=="number")r[0]+=l;else{if(typeof l=="boolean"||l===null||l===void 0)continue;if(typeof l=="object"&&l.isEscaped)if(l.callbacks)r.unshift("",l);else{const c=l.toString();c instanceof Promise?r.unshift("",c):r[0]+=c}else l instanceof Promise?r.unshift("",l):se(l.toString(),r)}}}return r[0]+=e.at(-1),r.length===1?"callbacks"in r?L(Er(L(r[0],r.callbacks))):L(r[0]):jr(r,r.callbacks)},St=Symbol("RENDERER"),jt=Symbol("ERROR_HANDLER"),k=Symbol("STASH"),Hr=Symbol("INTERNAL"),ua=Symbol("MEMO"),st=Symbol("PERMALINK"),Ut=e=>(e[Hr]=!0,e),Pr=e=>({value:t,children:r})=>{if(!r)return;const s={children:[{tag:Ut(()=>{e.push(t)}),props:{}}]};Array.isArray(r)?s.children.push(...r.flat()):s.children.push(r),s.children.push({tag:Ut(()=>{e.pop()}),props:{}});const a={tag:"",props:s,type:""};return a[jt]=n=>{throw e.pop(),n},a},Ur=e=>{const t=[e],r=Pr(t);return r.values=t,r.Provider=r,je.push(r),r},je=[],Rt=e=>{const t=[e],r=s=>{t.push(s.value);let a;try{a=s.children?(Array.isArray(s.children)?new zr("",{},s.children):s.children).toString():""}finally{t.pop()}return a instanceof Promise?a.then(n=>L(n,n.callbacks)):L(a)};return r.values=t,r.Provider=r,r[St]=Pr(t),je.push(r),r},xe=e=>e.values.at(-1),Ge={title:[],script:["src"],style:["data-href"],link:["href"],meta:["name","httpEquiv","charset","itemProp"]},Et={},Qe="data-precedence",Be=e=>Array.isArray(e)?e:[e],Wt=new WeakMap,$t=(e,t,r,s)=>({buffer:a,context:n})=>{if(!a)return;const o=Wt.get(n)||{};Wt.set(n,o);const i=o[e]||(o[e]=[]);let l=!1;const c=Ge[e];if(c.length>0){e:for(const[,d]of i)for(const p of c)if(((d==null?void 0:d[p])??null)===(r==null?void 0:r[p])){l=!0;break e}}if(l?a[0]=a[0].replaceAll(t,""):c.length>0?i.push([t,r,s]):i.unshift([t,r,s]),a[0].indexOf("</head>")!==-1){let d;if(s===void 0)d=i.map(([p])=>p);else{const p=[];d=i.map(([m,,h])=>{let v=p.indexOf(h);return v===-1&&(p.push(h),v=p.length-1),[m,v]}).sort((m,h)=>m[1]-h[1]).map(([m])=>m)}d.forEach(p=>{a[0]=a[0].replaceAll(p,"")}),a[0]=a[0].replace(/(?=<\/head>)/,d.join(""))}},He=(e,t,r)=>L(new P(e,r,Be(t??[])).toString()),Pe=(e,t,r,s)=>{if("itemProp"in r)return He(e,t,r);let{precedence:a,blocking:n,...o}=r;a=s?a??"":void 0,s&&(o[Qe]=a);const i=new P(e,o,Be(t||[])).toString();return i instanceof Promise?i.then(l=>L(i,[...l.callbacks||[],$t(e,l,o,a)])):L(i,[$t(e,i,o,a)])},pa=({children:e,...t})=>{const r=kt();if(r){const s=xe(r);if(s==="svg"||s==="head")return new P("title",t,Be(e??[]))}return Pe("title",e,t,!1)},ma=({children:e,...t})=>{const r=kt();return["src","async"].some(s=>!t[s])||r&&xe(r)==="head"?He("script",e,t):Pe("script",e,t,!1)},fa=({children:e,...t})=>["href","precedence"].every(r=>r in t)?(t["data-href"]=t.href,delete t.href,Pe("style",e,t,!0)):He("style",e,t),ha=({children:e,...t})=>["onLoad","onError"].some(r=>r in t)||t.rel==="stylesheet"&&(!("precedence"in t)||"disabled"in t)?He("link",e,t):Pe("link",e,t,"precedence"in t),ga=({children:e,...t})=>{const r=kt();return r&&xe(r)==="head"?He("meta",e,t):Pe("meta",e,t,!1)},Wr=(e,{children:t,...r})=>new P(e,r,Be(t??[])),va=e=>(typeof e.action=="function"&&(e.action=st in e.action?e.action[st]:void 0),Wr("form",e)),$r=(e,t)=>(typeof t.formAction=="function"&&(t.formAction=st in t.formAction?t.formAction[st]:void 0),Wr(e,t)),ba=e=>$r("input",e),ya=e=>$r("button",e);const pt=Object.freeze(Object.defineProperty({__proto__:null,button:ya,form:va,input:ba,link:ha,meta:ga,script:ma,style:fa,title:pa},Symbol.toStringTag,{value:"Module"}));var _a=new Map([["className","class"],["htmlFor","for"],["crossOrigin","crossorigin"],["httpEquiv","http-equiv"],["itemProp","itemprop"],["fetchPriority","fetchpriority"],["noModule","nomodule"],["formAction","formaction"]]),at=e=>_a.get(e)||e,Jr=(e,t)=>{for(const[r,s]of Object.entries(e)){const a=r[0]==="-"||!/[A-Z]/.test(r)?r:r.replace(/[A-Z]/g,n=>`-${n.toLowerCase()}`);t(a,s==null?null:typeof s=="number"?a.match(/^(?:a|border-im|column(?:-c|s)|flex(?:$|-[^b])|grid-(?:ar|[^a])|font-w|li|or|sca|st|ta|wido|z)|ty$/)?`${s}`:`${s}px`:s)}},De=void 0,kt=()=>De,ja=e=>/[A-Z]/.test(e)&&e.match(/^(?:al|basel|clip(?:Path|Rule)$|co|do|fill|fl|fo|gl|let|lig|i|marker[EMS]|o|pai|pointe|sh|st[or]|text[^L]|tr|u|ve|w)/)?e.replace(/([A-Z])/g,"-$1").toLowerCase():e,Ea=["area","base","br","col","embed","hr","img","input","keygen","link","meta","param","source","track","wbr"],wa=["allowfullscreen","async","autofocus","autoplay","checked","controls","default","defer","disabled","download","formnovalidate","hidden","inert","ismap","itemscope","loop","multiple","muted","nomodule","novalidate","open","playsinline","readonly","required","reversed","selected"],Dt=(e,t)=>{for(let r=0,s=e.length;r<s;r++){const a=e[r];if(typeof a=="string")se(a,t);else{if(typeof a=="boolean"||a===null||a===void 0)continue;a instanceof P?a.toStringToBuffer(t):typeof a=="number"||a.isEscaped?t[0]+=a:a instanceof Promise?t.unshift("",a):Dt(a,t)}}},P=class{constructor(e,t,r){y(this,"tag");y(this,"props");y(this,"key");y(this,"children");y(this,"isEscaped",!0);y(this,"localContexts");this.tag=e,this.props=t,this.children=r}get type(){return this.tag}get ref(){return this.props.ref||null}toString(){var t,r;const e=[""];(t=this.localContexts)==null||t.forEach(([s,a])=>{s.values.push(a)});try{this.toStringToBuffer(e)}finally{(r=this.localContexts)==null||r.forEach(([s])=>{s.values.pop()})}return e.length===1?"callbacks"in e?Er(L(e[0],e.callbacks)).toString():e[0]:jr(e,e.callbacks)}toStringToBuffer(e){const t=this.tag,r=this.props;let{children:s}=this;e[0]+=`<${t}`;const a=De&&xe(De)==="svg"?n=>ja(at(n)):n=>at(n);for(let[n,o]of Object.entries(r))if(n=a(n),n!=="children"){if(n==="style"&&typeof o=="object"){let i="";Jr(o,(l,c)=>{c!=null&&(i+=`${i?";":""}${l}:${c}`)}),e[0]+=' style="',se(i,e),e[0]+='"'}else if(typeof o=="string")e[0]+=` ${n}="`,se(o,e),e[0]+='"';else if(o!=null)if(typeof o=="number"||o.isEscaped)e[0]+=` ${n}="${o}"`;else if(typeof o=="boolean"&&wa.includes(n))o&&(e[0]+=` ${n}=""`);else if(n==="dangerouslySetInnerHTML"){if(s.length>0)throw new Error("Can only set one of `children` or `props.dangerouslySetInnerHTML`.");s=[L(o.__html)]}else if(o instanceof Promise)e[0]+=` ${n}="`,e.unshift('"',o);else if(typeof o=="function"){if(!n.startsWith("on")&&n!=="ref")throw new Error(`Invalid prop '${n}' of type 'function' supplied to '${t}'.`)}else e[0]+=` ${n}="`,se(o.toString(),e),e[0]+='"'}if(Ea.includes(t)&&s.length===0){e[0]+="/>";return}e[0]+=">",Dt(s,e),e[0]+=`</${t}>`}},mt=class extends P{toStringToBuffer(e){const{children:t}=this,r=this.tag.call(null,{...this.props,children:t.length<=1?t[0]:t});if(!(typeof r=="boolean"||r==null))if(r instanceof Promise)if(je.length===0)e.unshift("",r);else{const s=je.map(a=>[a,a.values.at(-1)]);e.unshift("",r.then(a=>(a instanceof P&&(a.localContexts=s),a)))}else r instanceof P?r.toStringToBuffer(e):typeof r=="number"||r.isEscaped?(e[0]+=r,r.callbacks&&(e.callbacks||(e.callbacks=[]),e.callbacks.push(...r.callbacks))):se(r,e)}},zr=class extends P{toStringToBuffer(e){Dt(this.children,e)}},Jt=(e,t,...r)=>{t??(t={}),r.length&&(t.children=r.length===1?r[0]:r);const s=t.key;delete t.key;const a=Xe(e,t,r);return a.key=s,a},zt=!1,Xe=(e,t,r)=>{if(!zt){for(const s in Et)pt[s][St]=Et[s];zt=!0}return typeof e=="function"?new mt(e,t,r):pt[e]?new mt(pt[e],t,r):e==="svg"||e==="head"?(De||(De=Rt("")),new P(e,t,[new mt(De,{value:e},r)])):new P(e,t,r)},xa=({children:e})=>new zr("",{children:e},Array.isArray(e)?e:e?[e]:[]);function Je(e,t,r){let s;if(!t||!("children"in t))s=Xe(e,t,[]);else{const a=t.children;s=Array.isArray(a)?Xe(e,t,a):Xe(e,t,[a])}return s.key=r,s}var Oe="_hp",Ta={Change:"Input",DoubleClick:"DblClick"},Sa={svg:"2000/svg",math:"1998/Math/MathML"},Ce=[],wt=new WeakMap,Ee=void 0,Ra=()=>Ee,W=e=>"t"in e,ft={onClick:["click",!1]},Yt=e=>{if(!e.startsWith("on"))return;if(ft[e])return ft[e];const t=e.match(/^on([A-Z][a-zA-Z]+?(?:PointerCapture)?)(Capture)?$/);if(t){const[,r,s]=t;return ft[e]=[(Ta[r]||r).toLowerCase(),!!s]}},Vt=(e,t)=>Ee&&e instanceof SVGElement&&/[A-Z]/.test(t)&&(t in e.style||t.match(/^(?:o|pai|str|u|ve)/))?t.replace(/([A-Z])/g,"-$1").toLowerCase():t,ka=(e,t,r)=>{var s;t||(t={});for(let a in t){const n=t[a];if(a!=="children"&&(!r||r[a]!==n)){a=at(a);const o=Yt(a);if(o){if((r==null?void 0:r[a])!==n&&(r&&e.removeEventListener(o[0],r[a],o[1]),n!=null)){if(typeof n!="function")throw new Error(`Event handler for "${a}" is not a function`);e.addEventListener(o[0],n,o[1])}}else if(a==="dangerouslySetInnerHTML"&&n)e.innerHTML=n.__html;else if(a==="ref"){let i;typeof n=="function"?i=n(e)||(()=>n(null)):n&&"current"in n&&(n.current=e,i=()=>n.current=null),wt.set(e,i)}else if(a==="style"){const i=e.style;typeof n=="string"?i.cssText=n:(i.cssText="",n!=null&&Jr(n,i.setProperty.bind(i)))}else{if(a==="value"){const l=e.nodeName;if(l==="INPUT"||l==="TEXTAREA"||l==="SELECT"){if(e.value=n==null||n===!1?null:n,l==="TEXTAREA"){e.textContent=n;continue}else if(l==="SELECT"){e.selectedIndex===-1&&(e.selectedIndex=0);continue}}}else(a==="checked"&&e.nodeName==="INPUT"||a==="selected"&&e.nodeName==="OPTION")&&(e[a]=n);const i=Vt(e,a);n==null||n===!1?e.removeAttribute(i):n===!0?e.setAttribute(i,""):typeof n=="string"||typeof n=="number"?e.setAttribute(i,n):e.setAttribute(i,n.toString())}}}if(r)for(let a in r){const n=r[a];if(a!=="children"&&!(a in t)){a=at(a);const o=Yt(a);o?e.removeEventListener(o[0],n,o[1]):a==="ref"?(s=wt.get(e))==null||s():e.removeAttribute(Vt(e,a))}}},Da=(e,t)=>{t[k][0]=0,Ce.push([e,t]);const r=t.tag[St]||t.tag,s=r.defaultProps?{...r.defaultProps,...t.props}:t.props;try{return[r.call(null,s)]}finally{Ce.pop()}},Yr=(e,t,r,s,a)=>{var n,o;(n=e.vR)!=null&&n.length&&(s.push(...e.vR),delete e.vR),typeof e.tag=="function"&&((o=e[k][1][Qr])==null||o.forEach(i=>a.push(i))),e.vC.forEach(i=>{var l;if(W(i))r.push(i);else if(typeof i.tag=="function"||i.tag===""){i.c=t;const c=r.length;if(Yr(i,t,r,s,a),i.s){for(let d=c;d<r.length;d++)r[d].s=!0;i.s=!1}}else r.push(i),(l=i.vR)!=null&&l.length&&(s.push(...i.vR),delete i.vR)})},Oa=e=>{for(;;e=e.tag===Oe||!e.vC||!e.pP?e.nN:e.vC[0]){if(!e)return null;if(e.tag!==Oe&&e.e)return e.e}},Vr=e=>{var t,r,s,a,n,o;W(e)||((r=(t=e[k])==null?void 0:t[1][Qr])==null||r.forEach(i=>{var l;return(l=i[2])==null?void 0:l.call(i)}),(s=wt.get(e.e))==null||s(),e.p===2&&((a=e.vC)==null||a.forEach(i=>i.p=2)),(n=e.vC)==null||n.forEach(Vr)),e.p||((o=e.e)==null||o.remove(),delete e.e),typeof e.tag=="function"&&(Se.delete(e),Ze.delete(e),delete e[k][3],e.a=!0)},Kr=(e,t,r)=>{e.c=t,Gr(e,t,r)},Kt=(e,t)=>{if(t){for(let r=0,s=e.length;r<s;r++)if(e[r]===t)return r}},Gt=Symbol(),Gr=(e,t,r)=>{var c;const s=[],a=[],n=[];Yr(e,t,s,a,n),a.forEach(Vr);const o=r?void 0:t.childNodes;let i,l=null;if(r)i=-1;else if(!o.length)i=0;else{const d=Kt(o,Oa(e.nN));d!==void 0?(l=o[d],i=d):i=Kt(o,(c=s.find(p=>p.tag!==Oe&&p.e))==null?void 0:c.e)??-1,i===-1&&(r=!0)}for(let d=0,p=s.length;d<p;d++,i++){const m=s[d];let h;if(m.s&&m.e)h=m.e,m.s=!1;else{const v=r||!m.e;W(m)?(m.e&&m.d&&(m.e.textContent=m.t),m.d=!1,h=m.e||(m.e=document.createTextNode(m.t))):(h=m.e||(m.e=m.n?document.createElementNS(m.n,m.tag):document.createElement(m.tag)),ka(h,m.props,m.pP),Gr(m,h,v))}m.tag===Oe?i--:r?h.parentNode||t.appendChild(h):o[i]!==h&&o[i-1]!==h&&(o[i+1]===h?t.appendChild(o[i]):t.insertBefore(h,l||o[i]||null))}if(e.pP&&delete e.pP,n.length){const d=[],p=[];n.forEach(([,m,,h,v])=>{m&&d.push(m),h&&p.push(h),v==null||v()}),d.forEach(m=>m()),p.length&&requestAnimationFrame(()=>{p.forEach(m=>m())})}},Ca=(e,t)=>!!(e&&e.length===t.length&&e.every((r,s)=>r[1]===t[s][1])),Ze=new WeakMap,xt=(e,t,r)=>{var n,o,i,l,c,d;const s=!r&&t.pC;r&&(t.pC||(t.pC=t.vC));let a;try{r||(r=typeof t.tag=="function"?Da(e,t):Be(t.props.children)),((n=r[0])==null?void 0:n.tag)===""&&r[0][jt]&&(a=r[0][jt],e[5].push([e,a,t]));const p=s?[...t.pC]:t.vC?[...t.vC]:void 0,m=[];let h;for(let v=0;v<r.length;v++){Array.isArray(r[v])&&r.splice(v,1,...r[v].flat());let g=Aa(r[v]);if(g){typeof g.tag=="function"&&!g.tag[Hr]&&(je.length>0&&(g[k][2]=je.map(j=>[j,j.values.at(-1)])),(o=e[5])!=null&&o.length&&(g[k][3]=e[5].at(-1)));let b;if(p&&p.length){const j=p.findIndex(W(g)?w=>W(w):g.key!==void 0?w=>w.key===g.key&&w.tag===g.tag:w=>w.tag===g.tag);j!==-1&&(b=p[j],p.splice(j,1))}if(b)if(W(g))b.t!==g.t&&(b.t=g.t,b.d=!0),g=b;else{const j=b.pP=b.props;if(b.props=g.props,b.f||(b.f=g.f||t.f),typeof g.tag=="function"){const w=b[k][2];b[k][2]=g[k][2]||[],b[k][3]=g[k][3],!b.f&&((b.o||b)===g.o||(l=(i=b.tag)[ua])!=null&&l.call(i,j,b.props))&&Ca(w,b[k][2])&&(b.s=!0)}g=b}else if(!W(g)&&Ee){const j=xe(Ee);j&&(g.n=j)}if(!W(g)&&!g.s&&(xt(e,g),delete g.f),m.push(g),h&&!h.s&&!g.s)for(let j=h;j&&!W(j);j=(c=j.vC)==null?void 0:c.at(-1))j.nN=g;h=g}}t.vR=s?[...t.vC,...p||[]]:p||[],t.vC=m,s&&delete t.pC}catch(p){if(t.f=!0,p===Gt){if(a)return;throw p}const[m,h,v]=((d=t[k])==null?void 0:d[3])||[];if(h){const g=()=>et([0,!1,e[2]],v),b=Ze.get(v)||[];b.push(g),Ze.set(v,b);const j=h(p,()=>{const w=Ze.get(v);if(w){const T=w.indexOf(g);if(T!==-1)return w.splice(T,1),g()}});if(j){if(e[0]===1)e[1]=!0;else if(xt(e,v,[j]),(h.length===1||e!==m)&&v.c){Kr(v,v.c,!1);return}throw Gt}}throw p}finally{a&&e[5].pop()}},Aa=e=>{if(!(e==null||typeof e=="boolean")){if(typeof e=="string"||typeof e=="number")return{t:e.toString(),d:!0};if("vR"in e&&(e={tag:e.tag,props:e.props,key:e.key,f:e.f,type:e.tag,ref:e.props.ref,o:e.o||e}),typeof e.tag=="function")e[k]=[0,[]];else{const t=Sa[e.tag];t&&(Ee||(Ee=Ur("")),e.props.children=[{tag:Ee,props:{value:e.n=`http://www.w3.org/${t}`,children:e.props.children}}])}return e}},Qt=(e,t)=>{var r,s;(r=t[k][2])==null||r.forEach(([a,n])=>{a.values.push(n)});try{xt(e,t,void 0)}catch{return}if(t.a){delete t.a;return}(s=t[k][2])==null||s.forEach(([a])=>{a.values.pop()}),(e[0]!==1||!e[1])&&Kr(t,t.c,!1)},Se=new WeakMap,Xt=[],et=async(e,t)=>{e[5]||(e[5]=[]);const r=Se.get(t);r&&r[0](void 0);let s;const a=new Promise(n=>s=n);if(Se.set(t,[s,()=>{e[2]?e[2](e,t,n=>{Qt(n,t)}).then(()=>s(t)):(Qt(e,t),s(t))}]),Xt.length)Xt.at(-1).add(t);else{await Promise.resolve();const n=Se.get(t);n&&(Se.delete(t),n[1]())}return a},Na=(e,t,r)=>({tag:Oe,props:{children:e},key:r,e:t,p:1}),ht=0,Qr=1,gt=2,vt=3,bt=new WeakMap,Xr=(e,t)=>!e||!t||e.length!==t.length||t.some((r,s)=>r!==e[s]),Ia=void 0,Zt=[],Ma=e=>{var o;const t=()=>typeof e=="function"?e():e,r=Ce.at(-1);if(!r)return[t(),()=>{}];const[,s]=r,a=(o=s[k][1])[ht]||(o[ht]=[]),n=s[k][0]++;return a[n]||(a[n]=[t(),i=>{const l=Ia,c=a[n];if(typeof i=="function"&&(i=i(c[0])),!Object.is(i,c[0]))if(c[0]=i,Zt.length){const[d,p]=Zt.at(-1);Promise.all([d===3?s:et([d,!1,l],s),p]).then(([m])=>{if(!m||!(d===2||d===3))return;const h=m.vC;requestAnimationFrame(()=>{setTimeout(()=>{h===m.vC&&et([d===3?1:0,!1,l],m)})})})}else et([0,!1,l],s)}])},Ot=(e,t)=>{var i;const r=Ce.at(-1);if(!r)return e;const[,s]=r,a=(i=s[k][1])[gt]||(i[gt]=[]),n=s[k][0]++,o=a[n];return Xr(o==null?void 0:o[1],t)?a[n]=[e,t]:e=a[n][0],e},Fa=e=>{const t=bt.get(e);if(t){if(t.length===2)throw t[1];return t[0]}throw e.then(r=>bt.set(e,[r]),r=>bt.set(e,[void 0,r])),e},La=(e,t)=>{var i;const r=Ce.at(-1);if(!r)return e();const[,s]=r,a=(i=s[k][1])[vt]||(i[vt]=[]),n=s[k][0]++,o=a[n];return Xr(o==null?void 0:o[1],t)&&(a[n]=[e(),t]),a[n][0]},qa=Ur({pending:!1,data:null,method:null,action:null}),er=new Set,Ba=e=>{er.add(e),e.finally(()=>er.delete(e))},Ct=(e,t)=>La(()=>r=>{let s;e&&(typeof e=="function"?s=e(r)||(()=>{e(null)}):e&&"current"in e&&(e.current=r,s=()=>{e.current=null}));const a=t(r);return()=>{a==null||a(),s==null||s()}},[e]),pe=Object.create(null),ze=Object.create(null),Ue=(e,t,r,s,a)=>{if(t!=null&&t.itemProp)return{tag:e,props:t,type:e,ref:t.ref};const n=document.head;let{onLoad:o,onError:i,precedence:l,blocking:c,...d}=t,p=null,m=!1;const h=Ge[e];let v;if(h.length>0){const w=n.querySelectorAll(e);e:for(const T of w)for(const E of Ge[e])if(T.getAttribute(E)===t[E]){p=T;break e}if(!p){const T=h.reduce((E,D)=>t[D]===void 0?E:`${E}-${D}-${t[D]}`,e);m=!ze[T],p=ze[T]||(ze[T]=(()=>{const E=document.createElement(e);for(const D of h)t[D]!==void 0&&E.setAttribute(D,t[D]),t.rel&&E.setAttribute("rel",t.rel);return E})())}}else v=n.querySelectorAll(e);l=s?l??"":void 0,s&&(d[Qe]=l);const g=Ot(w=>{if(h.length>0){let T=!1;for(const E of n.querySelectorAll(e)){if(T&&E.getAttribute(Qe)!==l){n.insertBefore(w,E);return}E.getAttribute(Qe)===l&&(T=!0)}n.appendChild(w)}else if(v){let T=!1;for(const E of v)if(E===w){T=!0;break}T||n.insertBefore(w,n.contains(v[0])?v[0]:n.querySelector(e)),v=void 0}},[l]),b=Ct(t.ref,w=>{var D;const T=h[0];if(r===2&&(w.innerHTML=""),(m||v)&&g(w),!i&&!o)return;let E=pe[D=w.getAttribute(T)]||(pe[D]=new Promise((M,K)=>{w.addEventListener("load",M),w.addEventListener("error",K)}));o&&(E=E.then(o)),i&&(E=E.catch(i)),E.catch(()=>{})});if(a&&c==="render"){const w=Ge[e][0];if(t[w]){const T=t[w],E=pe[T]||(pe[T]=new Promise((D,M)=>{g(p),p.addEventListener("load",D),p.addEventListener("error",M)}));Fa(E)}}const j={tag:e,type:e,props:{...d,ref:b},ref:b};return j.p=r,p&&(j.e=p),Na(j,n)},Ha=e=>{const t=Ra(),r=t&&xe(t);return r!=null&&r.endsWith("svg")?{tag:"title",props:e,type:"title",ref:e.ref}:Ue("title",e,void 0,!1,!1)},Pa=e=>!e||["src","async"].some(t=>!e[t])?{tag:"script",props:e,type:"script",ref:e.ref}:Ue("script",e,1,!1,!0),Ua=e=>!e||!["href","precedence"].every(t=>t in e)?{tag:"style",props:e,type:"style",ref:e.ref}:(e["data-href"]=e.href,delete e.href,Ue("style",e,2,!0,!0)),Wa=e=>!e||["onLoad","onError"].some(t=>t in e)||e.rel==="stylesheet"&&(!("precedence"in e)||"disabled"in e)?{tag:"link",props:e,type:"link",ref:e.ref}:Ue("link",e,1,"precedence"in e,!0),$a=e=>Ue("meta",e,void 0,!1,!1),Zr=Symbol(),Ja=e=>{const{action:t,...r}=e;typeof t!="function"&&(r.action=t);const[s,a]=Ma([null,!1]),n=Ot(async c=>{const d=c.isTrusted?t:c.detail[Zr];if(typeof d!="function")return;c.preventDefault();const p=new FormData(c.target);a([p,!0]);const m=d(p);m instanceof Promise&&(Ba(m),await m),a([null,!0])},[]),o=Ct(e.ref,c=>(c.addEventListener("submit",n),()=>{c.removeEventListener("submit",n)})),[i,l]=s;return s[1]=!1,{tag:qa,props:{value:{pending:i!==null,data:i,method:i?"post":null,action:i?t:null},children:{tag:"form",props:{...r,ref:o},type:"form",ref:o}},f:l}},es=(e,{formAction:t,...r})=>{if(typeof t=="function"){const s=Ot(a=>{a.preventDefault(),a.currentTarget.form.dispatchEvent(new CustomEvent("submit",{detail:{[Zr]:t}}))},[]);r.ref=Ct(r.ref,a=>(a.addEventListener("click",s),()=>{a.removeEventListener("click",s)}))}return{tag:e,props:r,type:e,ref:r.ref}},za=e=>es("input",e),Ya=e=>es("button",e);Object.assign(Et,{title:Ha,script:Pa,style:Ua,link:Wa,meta:$a,form:Ja,input:za,button:Ya});Rt(null);new TextEncoder;var Va=Rt(null),Ka=(e,t,r,s)=>(a,n)=>{const o="<!DOCTYPE html>",i=r?Jt(c=>r(c,e),{Layout:t,...n},a):a,l=da`${L(o)}${Jt(Va.Provider,{value:e},i)}`;return e.html(l)},Ga=(e,t)=>function(s,a){const n=s.getLayout()??xa;return e&&s.setLayout(o=>e({...o,Layout:n},s)),s.setRenderer(Ka(s,n,e)),a()};const Qa=Ga(({children:e})=>Je("html",{children:[Je("head",{children:Je("link",{href:"/static/style.css",rel:"stylesheet"})}),Je("body",{children:e})]}));async function We(e){const r=new TextEncoder().encode(e),s=await crypto.subtle.digest("SHA-256",r);return Array.from(new Uint8Array(s)).map(o=>o.toString(16).padStart(2,"0")).join("")}const f=new Nr;f.use("*",async(e,t)=>{e.header("X-Content-Type-Options","nosniff"),e.header("X-Frame-Options","DENY"),e.header("X-XSS-Protection","1; mode=block"),e.header("Referrer-Policy","strict-origin-when-cross-origin"),e.header("Content-Security-Policy","default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://cdn.jsdelivr.net; font-src 'self' https://cdn.jsdelivr.net; img-src 'self' data: https:; connect-src 'self' https://w-campus.com https://www.w-campus.com"),await t()});const tr=new Map;f.use("/api/*",async(e,t)=>{const r=e.req.header("CF-Connecting-IP")||e.req.header("X-Forwarded-For")||"unknown",s=Date.now(),a=900*1e3,n=100,o=`rate_limit_${r}`,i=tr.get(o);if(!i||s>i.resetTime)tr.set(o,{count:1,resetTime:s+a});else if(i.count++,i.count>n)return e.json({error:"요청 한도를 초과했습니다. 잠시 후 다시 시도해주세요."},429);await t()});f.use("/api/*",Ms({origin:["http://localhost:3000","https://w-campus.com","https://www.w-campus.com","https://w-campus-com.pages.dev","https://job-platform.pages.dev"],allowMethods:["GET","POST","PUT","DELETE","OPTIONS"],allowHeaders:["Content-Type","Authorization"]}));f.use("/static/*",ca({root:"./public"}));f.use(Qa);const ot="w-campus-secure-jwt-secret-key-2025";async function R(e,t){const r=e.req.header("Authorization");if(!r||!r.startsWith("Bearer "))return e.json({error:"인증이 필요합니다."},401);const s=r.substring(7);if(s.startsWith("token_")){const a=s.split("_");if(a.length>=3){const n=a[1],o=a[2];e.set("user",{id:parseInt(n),userType:o}),await t();return}}try{const a=await qe(s,ot);e.set("user",a),await t()}catch{return e.json({error:"유효하지 않은 토큰입니다."},401)}}f.get("/api/auth/verify",async e=>{const t=e.req.header("Authorization");if(!t||!t.startsWith("Bearer "))return e.json({authenticated:!1,error:"토큰이 없습니다."},401);const r=t.substring(7);if(r.startsWith("token_")){const s=r.split("_");return s.length<3?e.json({authenticated:!1,error:"유효하지 않은 토큰입니다."},401):e.json({authenticated:!0,user:{id:s[1],userType:s[2]}})}else try{const s=await qe(r,ot);return e.json({authenticated:!0,user:{id:s.id,email:s.email,userType:s.userType,name:s.name}})}catch{return e.json({authenticated:!1,error:"유효하지 않은 토큰입니다."},401)}});f.get("/api/auth/status",async e=>{try{const t=e.req.header("Cookie");if(!t)return e.json({authenticated:!1});const s=t.split(";").reduce((a,n)=>{const[o,i]=n.trim().split("=");return a[o]=i,a},{}).auth_token;if(!s)return e.json({authenticated:!1});if(s.startsWith("token_")){const a=s.split("_");if(a.length>=3){const n=a[1],o=a[2];let i=null;if(o==="employer"?i=await e.env.DB.prepare("SELECT id, company_name as name, email, status FROM employers WHERE id = ?").bind(n).first():o==="agent"?i=await e.env.DB.prepare("SELECT id, company_name as name, email, status FROM agents WHERE id = ?").bind(n).first():o==="jobseeker"&&(i=await e.env.DB.prepare("SELECT id, name, email, status FROM job_seekers WHERE id = ?").bind(n).first()),i){let l=!1;return l=i.status==="approved"||i.status==="active",e.json({authenticated:l,user:l?{id:i.id,email:i.email,name:i.name,userType:o,status:i.status}:null,status:i.status,message:!l&&o==="agent"&&i.status==="pending"?"에이전트 계정 승인 대기 중입니다.":void 0})}}}else try{const a=e.env.JWT_SECRET||"your-secret-key",n=await qe(s,a);return e.json({authenticated:!0,user:{id:n.id,email:n.email,name:n.name,userType:n.userType}})}catch(a){console.error("JWT 검증 실패:",a)}return e.json({authenticated:!1})}catch(t){return console.error("인증 상태 확인 중 오류:",t),e.json({authenticated:!1})}});f.post("/api/auth/logout",async e=>{try{return e.header("Set-Cookie","auth_token=; HttpOnly; Secure; SameSite=Strict; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT"),e.json({success:!0,message:"로그아웃되었습니다."})}catch(t){return console.error("로그아웃 중 오류:",t),e.json({error:"로그아웃 중 오류가 발생했습니다."},500)}});function At(e){return e&&{"1급":"beginner","2급":"beginner","3급":"intermediate","4급":"intermediate","5급":"advanced","6급":"advanced",초급:"beginner",기초:"beginner",중급:"intermediate",고급:"advanced",최고급:"native",원어민:"native",beginner:"beginner",intermediate:"intermediate",advanced:"advanced",native:"native",기타:"beginner"}[e]||"beginner"}f.get("/health",async e=>{try{return await e.env.DB.prepare("SELECT 1").first(),e.json({status:"healthy",timestamp:new Date().toISOString(),service:"WOW-CAMPUS K-Work Platform",version:"1.0.0",database:"connected"})}catch{return e.json({status:"unhealthy",timestamp:new Date().toISOString(),service:"WOW-CAMPUS K-Work Platform",version:"1.0.0",database:"error",error:"Database connection failed"},500)}});f.get("/api/system/status",async e=>{var t,r,s;try{const a=await e.env.DB.prepare("SELECT COUNT(*) as total FROM employers").first(),n={employers:(a==null?void 0:a.total)||0,jobSeekers:((t=await e.env.DB.prepare("SELECT COUNT(*) as total FROM job_seekers").first())==null?void 0:t.total)||0,agents:((r=await e.env.DB.prepare("SELECT COUNT(*) as total FROM agents").first())==null?void 0:r.total)||0,jobPostings:((s=await e.env.DB.prepare("SELECT COUNT(*) as total FROM job_postings").first())==null?void 0:s.total)||0};return e.json({status:"operational",timestamp:new Date().toISOString(),counts:n,uptime:process.uptime?Math.floor(process.uptime()):0})}catch{return e.json({error:"시스템 상태 확인 중 오류가 발생했습니다.",timestamp:new Date().toISOString()},500)}});f.get("/",e=>{const t=e.req.header("Authorization")||e.req.query("token")||"";return t&&t.length>0,e.html(`
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>WOW-CAMPUS 외국인 구인구직 및 유학생 지원플랫폼</title>
        <script src="https://cdn.tailwindcss.com"><\/script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <script>
          tailwind.config = {
            theme: {
              extend: {
                colors: {
                  primary: '#1E40AF',
                  secondary: '#3B82F6',
                  accent: '#059669',
                  wowcampus: {
                    blue: '#1E40AF',
                    light: '#E0F2FE',
                    dark: '#0F172A'
                  }
                }
              }
            }
          }
        <\/script>
        <style>
          /* 부드러운 호버 전환 효과 */
          .smooth-transition {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .smooth-transition-fast {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .smooth-transition-slow {
            transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          /* 내비게이션 링크 호버 효과 */
          .nav-link {
            position: relative;
            color: #374151;
            transition: color 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .nav-link::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: #1E40AF;
            transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .nav-link:hover {
            color: #1E40AF;
          }
          
          .nav-link:hover::after {
            width: 100%;
          }
          
          /* 버튼 호버 효과 */
          .btn-primary {
            background-color: #1E40AF;
            color: white;
            transform: translateY(0);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .btn-primary:hover {
            background-color: #1D4ED8;
            transform: translateY(-1px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
          }
          
          .btn-secondary {
            border: 2px solid #1E40AF;
            color: #1E40AF;
            background-color: transparent;
            transform: translateY(0);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .btn-secondary:hover {
            background-color: #1E40AF;
            color: white;
            transform: translateY(-1px);
            box-shadow: 0 10px 15px -3px rgba(30, 64, 175, 0.2), 0 4px 6px -2px rgba(30, 64, 175, 0.1);
          }
          
          .btn-success {
            background-color: #059669;
            color: white;
            transform: translateY(0);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .btn-success:hover {
            background-color: #047857;
            transform: translateY(-1px);
            box-shadow: 0 10px 15px -3px rgba(5, 150, 105, 0.2), 0 4px 6px -2px rgba(5, 150, 105, 0.1);
          }
          
          /* 탭 버튼 스타일 */
          .tab-button {
            position: relative;
            background-color: #F8FAFC;
            color: #64748B;
            border: 1px solid #E2E8F0;
            padding: 12px 24px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            transform: translateY(0);
          }
          
          .tab-button.active {
            background-color: #1E40AF;
            color: white;
            border-color: #1E40AF;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px -5px rgba(30, 64, 175, 0.3);
          }
          
          .tab-button:hover:not(.active) {
            background-color: #E0F2FE;
            color: #1E40AF;
            border-color: #1E40AF;
            transform: translateY(-1px);
            box-shadow: 0 4px 6px -1px rgba(30, 64, 175, 0.1);
          }
          
          /* 드롭다운 메뉴 */
          .nav-dropdown-menu {
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            pointer-events: none;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
          }
          
          .nav-dropdown:hover .nav-dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
            pointer-events: auto;
          }
          
          .nav-dropdown-btn {
            transition: color 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .nav-dropdown-btn:hover {
            color: #1E40AF;
          }
          
          .nav-dropdown-menu:hover {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
            pointer-events: auto;
          }
          
          .nav-dropdown.active .nav-dropdown-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
            pointer-events: auto;
          }
          
          .nav-dropdown-menu a {
            display: flex;
            align-items: center;
            text-decoration: none;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            padding: 8px 16px;
          }
          
          .nav-dropdown-menu a:hover {
            background-color: #E0F2FE;
            color: #1E40AF;
            transform: translateX(4px);
          }
          
          /* 카드 효과 */
          .hero-gradient {
            background: linear-gradient(135deg, #1E40AF 0%, #3B82F6 50%, #059669 100%);
          }
          
          .card-shadow {
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            transform: translateY(0);
          }
          
          .card-shadow:hover {
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15), 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            transform: translateY(-8px);
          }
          
          /* 프로필 카드 효과 */
          .profile-card {
            border: 1px solid #E5E7EB;
            border-radius: 8px;
            padding: 16px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            transform: translateY(0);
            background-color: white;
          }
          
          .profile-card:hover {
            border-color: #1E40AF;
            transform: translateY(-4px);
            box-shadow: 0 20px 25px -5px rgba(30, 64, 175, 0.1), 0 10px 10px -5px rgba(30, 64, 175, 0.04);
          }
          
          /* 링크 효과 */
          .link-hover {
            color: #1E40AF;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
          }
          
          .link-hover:hover {
            color: #1D4ED8;
            transform: translateX(2px);
          }
          
          .link-hover::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 1px;
            background-color: #1D4ED8;
            transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .link-hover:hover::after {
            width: 100%;
          }
          
          /* 검색 및 입력 필드 */
          .input-focus {
            border: 2px solid #E5E7EB;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .input-focus:focus {
            border-color: #1E40AF;
            box-shadow: 0 0 0 3px rgba(30, 64, 175, 0.1);
            outline: none;
          }
          
          /* 페이지네이션 */
          .pagination-btn {
            border: 1px solid #D1D5DB;
            color: #6B7280;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .pagination-btn:hover {
            border-color: #1E40AF;
            color: #1E40AF;
            transform: translateY(-1px);
          }
          
          .pagination-btn.active {
            background-color: #1E40AF;
            border-color: #1E40AF;
            color: white;
          }
          .step-connector {
            position: relative;
          }
          .step-connector::before {
            content: '';
            position: absolute;
            top: 50%;
            right: -2rem;
            width: 3rem;
            height: 2px;
            background: #CBD5E1;
            z-index: 1;
          }
          @media (max-width: 768px) {
            .step-connector::before {
              display: none;
            }
          }
          /* 매우 높은 우선순위로 인증 상태별 UI 컨트롤 */
          html body.auth-logged-in header div.container div.flex div#auth-buttons,
          html body.auth-logged-in header div.container div.flex div#auth-buttons a#login-btn,
          html body.auth-logged-in header div.container div.flex div#auth-buttons a#register-btn,
          html body.auth-logged-in div#auth-buttons,
          html body.auth-logged-in a#login-btn,
          html body.auth-logged-in a#register-btn {
            display: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
            pointer-events: none !important;
            width: 0 !important;
            height: 0 !important;
            overflow: hidden !important;
          }
          
          html body.auth-logged-in header div.container div.flex div#user-menu,
          html body.auth-logged-in div#user-menu {
            display: flex !important;
            visibility: visible !important;
            opacity: 1 !important;
            pointer-events: auto !important;
          }
          
          /* 로그아웃 상태에서는 user-menu 완전히 숨기기 */
          html body:not(.auth-logged-in) header div.container div.flex div#user-menu,
          html body:not(.auth-logged-in) div#user-menu {
            display: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
            pointer-events: none !important;
            width: 0 !important;
            height: 0 !important;
            overflow: hidden !important;
          }
          
          /* 로그아웃 상태에서는 auth-buttons 확실히 보이기 */
          html body:not(.auth-logged-in) header div.container div.flex div#auth-buttons,
          html body:not(.auth-logged-in) div#auth-buttons {
            display: flex !important;
            visibility: visible !important;
            opacity: 1 !important;
            pointer-events: auto !important;
          }
          
          /* 추가 안전장치: 클래스 기반 숨김 */
          .force-hide-auth {
            display: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
            pointer-events: none !important;
            width: 0 !important;
            height: 0 !important;
            overflow: hidden !important;
          }
          
          .force-show-user {
            display: flex !important;
            visibility: visible !important;
            opacity: 1 !important;
            pointer-events: auto !important;
          }
          
          /* Normal auth button styles */
          

          

          

          

          

          

        </style>
    </head>
    <body class="bg-gray-50 min-h-screen font-sans">
        <!-- Header -->
        <header class="bg-white shadow-md border-b-2 border-wowcampus-blue">
            <div class="container mx-auto px-6 py-4">
                <div class="flex justify-between items-center">
                    <a href="/" class="flex items-center space-x-3 hover:opacity-80 transition-opacity cursor-pointer">
                        <div class="w-10 h-10 bg-gradient-to-br from-wowcampus-blue to-accent rounded-lg flex items-center justify-center">
                            <i class="fas fa-graduation-cap text-white text-xl"></i>
                        </div>
                        <div class="flex flex-col">
                            <h1 class="text-2xl font-bold text-wowcampus-blue tracking-tight">WOW-CAMPUS</h1>
                            <span class="text-xs text-gray-500">외국인 구인구직 및 유학 플랫폼</span>
                        </div>
                    </a>
                    <!-- Desktop Navigation -->
                    <nav class="hidden md:flex items-center space-x-8">
                        <div class="relative nav-dropdown">
                            <button class="nav-dropdown-btn text-gray-700 hover:text-wowcampus-blue flex items-center font-medium py-2">
                                구인정보 <i class="fas fa-chevron-down ml-1 text-xs transition-transform"></i>
                            </button>
                            <div class="nav-dropdown-menu absolute left-0 top-full mt-1 w-48 bg-white shadow-xl rounded-lg border border-gray-100 py-2 z-50">
                                <a href="#jobs-view" onclick="event.preventDefault(); showJobListView(); return false;" class="block px-4 py-3 text-gray-700 hover:bg-wowcampus-light hover:text-wowcampus-blue transition-colors cursor-pointer">
                                    <i class="fas fa-list mr-2"></i>구인정보 보기
                                </a>
        
                            </div>
                        </div>
                        <div class="relative nav-dropdown">
                            <button class="nav-dropdown-btn text-gray-700 hover:text-wowcampus-blue flex items-center font-medium py-2">
                                구직정보 <i class="fas fa-chevron-down ml-1 text-xs transition-transform"></i>
                            </button>
                            <div class="nav-dropdown-menu absolute left-0 top-full mt-1 w-48 bg-white shadow-xl rounded-lg border border-gray-100 py-2 z-50">
                                <a href="#jobseekers-view" onclick="event.preventDefault(); showJobSeekerListView(); return false;" class="block px-4 py-3 text-gray-700 hover:bg-wowcampus-light hover:text-wowcampus-blue transition-colors cursor-pointer">
                                    <i class="fas fa-users mr-2"></i>구직자 보기
                                </a>
                                <a href="#jobseekers-register" onclick="event.preventDefault(); showJobSeekerRegisterForm(); return false;" class="block px-4 py-3 text-gray-700 hover:bg-wowcampus-light hover:text-wowcampus-blue transition-colors cursor-pointer">
                                    <i class="fas fa-user-plus mr-2"></i>구직정보 등록
                                </a>
                            </div>
                        </div>
                        <div class="relative nav-dropdown">
                            <button class="nav-dropdown-btn text-gray-700 hover:text-wowcampus-blue flex items-center font-medium py-2">
                                유학지원 <i class="fas fa-chevron-down ml-1 text-xs transition-transform"></i>
                            </button>
                            <div class="nav-dropdown-menu absolute left-0 top-full mt-1 w-52 bg-white shadow-xl rounded-lg border border-gray-100 py-2 z-50">
                                <a href="#study-language" onclick="event.preventDefault(); showLanguageStudyView(); return false;" class="block px-4 py-3 text-gray-700 hover:bg-wowcampus-light hover:text-wowcampus-blue transition-colors cursor-pointer">
                                    <i class="fas fa-language mr-2"></i>어학연수 과정
                                </a>
                                <a href="#study-undergraduate" onclick="event.preventDefault(); showUndergraduateView(); return false;" class="block px-4 py-3 text-gray-700 hover:bg-wowcampus-light hover:text-wowcampus-blue transition-colors cursor-pointer">
                                    <i class="fas fa-graduation-cap mr-2"></i>학부(학위) 과정
                                </a>
                                <a href="#study-graduate" onclick="event.preventDefault(); showGraduateView(); return false;" class="block px-4 py-3 text-gray-700 hover:bg-wowcampus-light hover:text-wowcampus-blue transition-colors cursor-pointer">
                                    <i class="fas fa-university mr-2"></i>석·박사 과정
                                </a>
                            </div>
                        </div>
                        <a href="/static/agent-dashboard?agentId=1" id="agent-menu" class="text-gray-700 hover:text-wowcampus-blue font-medium hidden">에이전트</a>
                    </nav>
                    
                    <!-- Mobile Menu Button & Auth Buttons -->
                    <div class="flex items-center space-x-4">
                        <!-- Mobile Menu Toggle -->
                        <button id="mobile-menu-btn" class="md:hidden text-gray-700 hover:text-wowcampus-blue">
                            <i class="fas fa-bars text-xl"></i>
                        </button>
                        
                        <!-- Auth Buttons (Show by default, hide when logged in) -->
                        <div id="auth-buttons" class="flex items-center space-x-3">
                            <a href="/static/login.html" id="login-btn" class="btn-primary px-4 md:px-6 py-2 rounded-full font-medium text-sm md:text-base">
                                <i class="fas fa-sign-in-alt mr-1 md:mr-2"></i>로그인
                            </a>
                            <a href="/static/register.html" id="register-btn" class="btn-secondary px-4 md:px-6 py-2 rounded-full font-medium text-sm md:text-base">
                                <i class="fas fa-user-plus mr-1 md:mr-2"></i>회원가입
                            </a>
                        </div>
                        
                        <!-- User Menu (Hidden by default) -->
                        <div id="user-menu" class="hidden flex items-center space-x-4">
                            <span class="text-sm text-gray-600 hidden sm:inline">환영합니다, <span id="user-name" class="font-medium">사용자님</span></span>
                            <button id="logout-btn" class="btn-primary px-3 md:px-4 py-2 rounded-full font-medium text-sm" style="background-color: #ef4444;">
                                <i class="fas fa-sign-out-alt mr-1"></i>로그아웃
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Mobile Navigation Menu -->
        <div id="mobile-menu" class="md:hidden bg-white border-b-2 border-wowcampus-blue shadow-lg hidden">
            <div class="container mx-auto px-6 py-4">
                <nav class="space-y-4">
                    <div class="border-b border-gray-200 pb-4">
                        <button onclick="showJobListView(); closeMobileMenu();" class="block w-full text-left py-3 text-gray-700 hover:text-wowcampus-blue hover:bg-wowcampus-light font-medium rounded-lg transition-colors">
                            <i class="fas fa-briefcase mr-3"></i>구인정보 보기
                        </button>

                    </div>
                    
                    <div class="border-b border-gray-200 pb-4">
                        <button onclick="showJobSeekerListView(); closeMobileMenu();" class="block w-full text-left py-3 text-gray-700 hover:text-wowcampus-blue hover:bg-wowcampus-light font-medium rounded-lg transition-colors">
                            <i class="fas fa-users mr-3"></i>구직자 보기
                        </button>
                        <button onclick="showJobSeekerRegisterForm(); closeMobileMenu();" class="block w-full text-left py-3 text-gray-700 hover:text-wowcampus-blue hover:bg-wowcampus-light font-medium rounded-lg transition-colors">
                            <i class="fas fa-user-plus mr-3"></i>구직정보 등록
                        </button>
                    </div>
                    
                    <div class="border-b border-gray-200 pb-4">
                        <button onclick="showLanguageStudyView(); closeMobileMenu();" class="block w-full text-left py-3 text-gray-700 hover:text-wowcampus-blue hover:bg-wowcampus-light font-medium rounded-lg transition-colors">
                            <i class="fas fa-language mr-3"></i>어학연수 과정
                        </button>
                        <button onclick="showUndergraduateView(); closeMobileMenu();" class="block w-full text-left py-3 text-gray-700 hover:text-wowcampus-blue hover:bg-wowcampus-light font-medium rounded-lg transition-colors">
                            <i class="fas fa-graduation-cap mr-3"></i>학부(학위) 과정
                        </button>
                        <button onclick="showGraduateView(); closeMobileMenu();" class="block w-full text-left py-3 text-gray-700 hover:text-wowcampus-blue hover:bg-wowcampus-light font-medium rounded-lg transition-colors">
                            <i class="fas fa-university mr-3"></i>석·박사 과정
                        </button>
                    </div>
                    
                    <div id="mobile-agent-menu" class="hidden">
                        <a href="/static/agent-dashboard?agentId=1" class="block w-full text-left py-2 text-gray-700 hover:text-wowcampus-blue font-medium">
                            <i class="fas fa-handshake mr-3"></i>에이전트
                        </a>
                    </div>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <main>
            <!-- Hero Section -->
            <section class="hero-gradient relative overflow-hidden">
                <div class="absolute inset-0 bg-black opacity-10"></div>
                <div class="relative container mx-auto px-6 py-20 text-center">
                    <div class="max-w-4xl mx-auto">
                        <h1 class="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
                            WOW-CAMPUS
                        </h1>
                        <p class="text-xl md:text-2xl text-white/90 mb-4 font-light">
                            외국인을 위한 한국 취업 & 유학 플랫폼
                        </p>
                        <p class="text-lg text-white/80 mb-12 max-w-3xl mx-auto leading-relaxed">
                            해외 에이전트와 국내 기업을 연결하여 외국인 인재의 한국 진출을 지원합니다
                        </p>
                        
                        <!-- 주요 서비스 CTA 버튼 -->
                        <div class="flex flex-col sm:flex-row gap-4 justify-center mb-16">
                            <button onclick="showJobListView()" class="btn-secondary px-8 py-4 rounded-full font-semibold">
                                <i class="fas fa-briefcase mr-2"></i>구인정보 보기
                            </button>
                            <button onclick="showJobSeekerListView()" class="btn-primary px-8 py-4 rounded-full font-semibold">
                                <i class="fas fa-user-graduate mr-2"></i>구직자 보기
                            </button>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- 주요 서비스 소개 -->
            <section class="py-20 bg-white">
                <div class="container mx-auto px-6">
                    <div class="text-center mb-16">
                        <h2 class="text-4xl font-bold text-gray-800 mb-4">우리의 서비스</h2>
                        <p class="text-xl text-gray-600 max-w-2xl mx-auto">
                            외국인 구직자와 국내 기업을 연결하는 전문 플랫폼
                        </p>
                    </div>
                    
                    <div class="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                        <div class="text-center card-shadow bg-white p-8 rounded-xl">
                            <div class="w-16 h-16 bg-gradient-to-br from-wowcampus-blue to-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                                <i class="fas fa-briefcase text-white text-2xl"></i>
                            </div>
                            <h3 class="text-2xl font-semibold text-gray-800 mb-4">구인구직 매칭</h3>
                            <p class="text-gray-600 leading-relaxed mb-6">비자별, 직종별, 지역별 맞춤 매칭 서비스로 최적의 일자리를 찾아드립니다</p>
                            <a href="#" class="text-wowcampus-blue font-semibold hover:underline">자세히 보기 →</a>
                        </div>
                        
                        <div class="text-center card-shadow bg-white p-8 rounded-xl">
                            <div class="w-16 h-16 bg-gradient-to-br from-accent to-green-400 rounded-full flex items-center justify-center mx-auto mb-6">
                                <i class="fas fa-graduation-cap text-white text-2xl"></i>
                            </div>
                            <h3 class="text-2xl font-semibold text-gray-800 mb-4">유학 지원</h3>
                            <p class="text-gray-600 leading-relaxed mb-6">한국어 연수부터 학위과정까지 전 과정에 대한 체계적 지원을 제공합니다</p>
                            <a href="#" class="text-accent font-semibold hover:underline">자세히 보기 →</a>
                        </div>
                        
                        <div class="text-center card-shadow bg-white p-8 rounded-xl cursor-pointer" onclick="handleAgentManagementClick()">
                            <div class="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-6">
                                <i class="fas fa-users text-white text-2xl"></i>
                            </div>
                            <h3 class="text-2xl font-semibold text-gray-800 mb-4">에이전트 관리</h3>
                            <p class="text-gray-600 leading-relaxed mb-6">해외 에이전트별 구직자 관리 및 지원 현황을 체계적으로 관리합니다</p>
                            <a href="#" class="text-purple-500 font-semibold hover:underline">자세히 보기 →</a>
                        </div>
                    </div>
                </div>
            </section>
            
            <!-- 이용 절차 안내 -->
            <section class="py-20 bg-wowcampus-light">
                <div class="container mx-auto px-6">
                    <div class="text-center mb-16">
                        <h2 class="text-4xl font-bold text-gray-800 mb-4">이용 절차</h2>
                        <p class="text-xl text-gray-600">간단한 3단계로 시작하세요</p>
                    </div>
                    
                    <div class="max-w-4xl mx-auto">
                        <div class="grid md:grid-cols-3 gap-8">
                            <div class="text-center step-connector">
                                <div class="w-20 h-20 bg-wowcampus-blue rounded-full flex items-center justify-center mx-auto mb-6">
                                    <span class="text-2xl font-bold text-white">1</span>
                                </div>
                                <h3 class="text-xl font-semibold text-gray-800 mb-3">회원가입</h3>
                                <p class="text-gray-600">간단한 정보 입력으로 <br>회원가입을 완료하세요</p>
                            </div>
                            
                            <div class="text-center step-connector">
                                <div class="w-20 h-20 bg-accent rounded-full flex items-center justify-center mx-auto mb-6">
                                    <span class="text-2xl font-bold text-white">2</span>
                                </div>
                                <h3 class="text-xl font-semibold text-gray-800 mb-3">정보 등록</h3>
                                <p class="text-gray-600">구직 또는 구인 정보를 <br>등록하고 매칭을 기다리세요</p>
                            </div>
                            
                            <div class="text-center">
                                <div class="w-20 h-20 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
                                    <span class="text-2xl font-bold text-white">3</span>
                                </div>
                                <h3 class="text-xl font-semibold text-gray-800 mb-3">매칭 성공</h3>
                                <p class="text-gray-600">전문 에이전트의 도움으로 <br>성공적인 취업 또는 인재 발굴</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
            <div class="container mx-auto px-6 py-12">

            <!-- Dashboard Tabs -->
            <section class="mb-12">
                <div class="bg-white rounded-xl shadow-lg overflow-hidden card-shadow">
                    <div class="border-b border-gray-100">
                        <div class="flex overflow-x-auto">
                            <button id="tab-jobs" class="tab-button active px-6 py-4 whitespace-nowrap font-medium">
                                <i class="fas fa-briefcase mr-2"></i>구인 정보
                            </button>
                            <button id="tab-jobseekers" class="tab-button px-6 py-4 whitespace-nowrap font-medium">
                                <i class="fas fa-users mr-2"></i>구직정보
                            </button>
                            <button id="tab-matching" class="tab-button px-6 py-4 whitespace-nowrap font-medium">
                                <i class="fas fa-handshake mr-2"></i>매칭 서비스
                            </button>
                            <button id="tab-study" class="tab-button px-6 py-4 whitespace-nowrap font-medium">
                                <i class="fas fa-graduation-cap mr-2"></i>유학 프로그램
                            </button>
                            <button id="tab-stats" class="tab-button px-6 py-4 whitespace-nowrap font-medium">
                                <i class="fas fa-chart-bar mr-2"></i>통계 대시보드
                            </button>
                        </div>
                    </div>

                    <!-- Tab Contents -->
                    <div class="p-6">
                        <div id="content-jobs" class="tab-content">
                            <!-- 구인 서브메뉴 -->
                            <div class="bg-gray-50 p-4 rounded-lg mb-6">
                                <div class="flex space-x-4">
                                    <button id="job-view-btn" class="job-sub-btn btn-primary px-4 py-2 rounded-lg">
                                        <i class="fas fa-list mr-2"></i>구인정보 보기
                                    </button>
                                </div>
                            </div>
                            
                            <!-- 구인정보 보기 -->
                            <div id="job-view-section" class="job-sub-content">
                                <div class="flex justify-between items-center mb-4">
                                    <h3 class="text-xl font-semibold">최신 구인 정보</h3>
                                    <button class="btn-primary px-4 py-2 rounded-lg">
                                        전체보기
                                    </button>
                                </div>
                                <div id="jobs-list" class="space-y-4">
                                    <!-- Job listings will be loaded here -->
                                </div>
                            </div>
                            

                        </div>

                        <div id="content-jobseekers" class="tab-content hidden">
                            <!-- 구직 서브메뉴 -->
                            <div class="bg-gray-50 p-4 rounded-lg mb-6">
                                <div class="flex space-x-4">
                                    <button id="jobseeker-view-btn" class="jobseeker-sub-btn btn-primary px-4 py-2 rounded-lg">
                                        <i class="fas fa-users mr-2"></i>구직자 보기
                                    </button>
                                    <button id="jobseeker-register-btn" class="jobseeker-sub-btn btn-secondary px-4 py-2 rounded-lg">
                                        <i class="fas fa-user-plus mr-2"></i>구직정보 등록
                                    </button>
                                </div>
                            </div>
                            
                            <!-- 구직자 보기 -->
                            <div id="jobseeker-view-section" class="jobseeker-sub-content">
                                <div class="flex justify-between items-center mb-4">
                                    <h3 class="text-xl font-semibold">최신 구직정보</h3>
                                    <button class="btn-primary px-4 py-2 rounded-lg">
                                        전체보기
                                    </button>
                                </div>
                                <div id="jobseekers-list" class="space-y-4">
                                    <!-- Job seekers will be loaded here -->
                                </div>
                            </div>
                            
                            <!-- 구직정보 등록 -->
                            <div id="jobseeker-register-section" class="jobseeker-sub-content hidden">
                                <h3 class="text-xl font-semibold mb-6">구직정보 등록</h3>
                                <form id="jobseeker-register-form" class="space-y-6">
                                    <div class="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">이름 *</label>
                                            <input type="text" id="jobseeker-name" required class="input-focus w-full px-3 py-2 rounded-lg">
                                        </div>
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">이메일 *</label>
                                            <input type="email" id="jobseeker-email" required class="input-focus w-full px-3 py-2 rounded-lg">
                                        </div>
                                    </div>
                                    
                                    <div class="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">생년월일 *</label>
                                            <input type="date" id="jobseeker-birth-date" required class="input-focus w-full px-3 py-2 rounded-lg">
                                        </div>
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">성별 *</label>
                                            <select id="jobseeker-gender" required class="input-focus w-full px-3 py-2 rounded-lg">
                                                <option value="">성별 선택</option>
                                                <option value="male">남성</option>
                                                <option value="female">여성</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">국적 *</label>
                                            <select id="jobseeker-nationality" required class="input-focus w-full px-3 py-2 rounded-lg">
                                                <option value="">국적 선택</option>
                                                <option value="중국">중국</option>
                                                <option value="베트남">베트남</option>
                                                <option value="필리핀">필리핀</option>
                                                <option value="태국">태국</option>
                                                <option value="캄보디아">캄보디아</option>
                                                <option value="미얀마">미얀마</option>
                                                <option value="네팔">네팔</option>
                                                <option value="스리랑카">스리랑카</option>
                                                <option value="방글라데시">방글라데시</option>
                                                <option value="기타">기타</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">연락처 *</label>
                                            <input type="tel" id="jobseeker-phone" required class="input-focus w-full px-3 py-2 rounded-lg" placeholder="예: 010-1234-5678">
                                        </div>
                                    </div>
                                    
                                    <div class="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">현재 비자 *</label>
                                            <select id="jobseeker-current-visa" required class="input-focus w-full px-3 py-2 rounded-lg">
                                                <option value="">현재 비자 선택</option>
                                                <option value="E-9">E-9 (비전문취업)</option>
                                                <option value="E-7">E-7 (특정활동)</option>
                                                <option value="H-2">H-2 (방문취업)</option>
                                                <option value="F-4">F-4 (재외동포)</option>
                                                <option value="F-5">F-5 (영주)</option>
                                                <option value="F-6">F-6 (결혼이민)</option>
                                                <option value="D-2">D-2 (유학)</option>
                                                <option value="D-4">D-4 (일반연수)</option>
                                                <option value="관광비자">관광비자</option>
                                                <option value="무비자">무비자</option>
                                                <option value="기타">기타</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">희망 비자 *</label>
                                            <select id="jobseeker-desired-visa" required class="input-focus w-full px-3 py-2 rounded-lg">
                                                <option value="">희망 비자 선택</option>
                                                <option value="E-9">E-9 (비전문취업)</option>
                                                <option value="E-7">E-7 (특정활동)</option>
                                                <option value="H-2">H-2 (방문취업)</option>
                                                <option value="F-4">F-4 (재외동포)</option>
                                                <option value="F-5">F-5 (영주)</option>
                                                <option value="F-6">F-6 (결혼이민)</option>
                                                <option value="기타">기타</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">현재 주소 *</label>
                                        <input type="text" id="jobseeker-address" required class="input-focus w-full px-3 py-2 rounded-lg" placeholder="현재 거주지 주소를 입력해주세요">
                                    </div>
                                    
                                    <div class="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">한국어 수준 *</label>
                                            <select id="jobseeker-korean-level" required class="input-focus w-full px-3 py-2 rounded-lg">
                                                <option value="">한국어 수준 선택</option>
                                                <option value="1급">초급 (1급)</option>
                                                <option value="2급">초급 (2급)</option>
                                                <option value="3급">중급 (3급)</option>
                                                <option value="4급">중급 (4급)</option>
                                                <option value="5급">고급 (5급)</option>
                                                <option value="6급">고급 (6급)</option>
                                                <option value="기타">기타</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-2">학력 *</label>
                                            <select id="jobseeker-education" required class="input-focus w-full px-3 py-2 rounded-lg">
                                                <option value="">학력 선택</option>
                                                <option value="초등학교졸업">초등학교 졸업</option>
                                                <option value="중학교졸업">중학교 졸업</option>
                                                <option value="고등학교졸업">고등학교 졸업</option>
                                                <option value="대학재학">대학교 재학</option>
                                                <option value="대학졸업">대학교 졸업</option>
                                                <option value="대학원졸업">대학원 졸업</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">경력 사항</label>
                                        <textarea id="jobseeker-experience" rows="4" class="input-focus w-full px-3 py-2 rounded-lg" placeholder="이전 직장 경험, 기술, 자격증 등을 입력해주세요 (선택사항)"></textarea>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">에이전트 ID</label>
                                        <input type="number" id="jobseeker-agent-id" min="1" class="input-focus w-full px-3 py-2 rounded-lg" placeholder="담당 에이전트 ID (선택사항)">
                                    </div>
                                    
                                    <div class="flex justify-end space-x-4">
                                        <button type="button" onclick="resetJobSeekerForm()" class="btn-secondary px-6 py-2 rounded-lg">
                                            초기화
                                        </button>
                                        <button type="submit" class="btn-primary px-6 py-2 rounded-lg">
                                            등록하기
                                        </button>
                                    </div>
                                </form>
                                
                                <div id="jobseeker-register-success" class="hidden mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                                    <div class="flex items-center">
                                        <i class="fas fa-check-circle text-green-500 mr-2"></i>
                                        <span class="text-green-800">구직정보가 성공적으로 등록되었습니다!</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="content-matching" class="tab-content hidden">
                            <div class="mb-6">
                                <h3 class="text-xl font-semibold mb-4">스마트 매칭 시스템</h3>
                                <div class="bg-blue-50 p-4 rounded-lg mb-4">
                                    <p class="text-blue-800 text-sm">
                                        <i class="fas fa-info-circle mr-2"></i>
                                        AI 기반으로 구직자의 조건과 구인공고를 자동 매칭합니다
                                    </p>
                                </div>
                            </div>
                            
                            <!-- 매칭 통계 -->
                            <div class="grid md:grid-cols-3 gap-4 mb-6">
                                <div class="bg-green-50 p-4 rounded-lg">
                                    <div class="flex items-center">
                                        <i class="fas fa-check-circle text-green-500 text-2xl mr-3"></i>
                                        <div>
                                            <div class="text-2xl font-bold text-green-600" id="perfect-matches">0</div>
                                            <div class="text-sm text-gray-600">완벽 매칭</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="bg-yellow-50 p-4 rounded-lg">
                                    <div class="flex items-center">
                                        <i class="fas fa-star text-yellow-500 text-2xl mr-3"></i>
                                        <div>
                                            <div class="text-2xl font-bold text-yellow-600" id="good-matches">0</div>
                                            <div class="text-sm text-gray-600">좋은 매칭</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="bg-blue-50 p-4 rounded-lg">
                                    <div class="flex items-center">
                                        <i class="fas fa-clock text-blue-500 text-2xl mr-3"></i>
                                        <div>
                                            <div class="text-2xl font-bold text-blue-600" id="pending-matches">0</div>
                                            <div class="text-sm text-gray-600">검토 중</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- 최신 매칭 결과 -->
                            <div class="bg-white border rounded-lg p-4">
                                <h4 class="font-semibold mb-4">최신 매칭 결과</h4>
                                <div id="matching-results" class="space-y-3">
                                    <!-- Matching results will be loaded here -->
                                </div>
                            </div>
                        </div>

                        <div id="content-study" class="tab-content hidden">
                            <!-- 유학 서브메뉴 -->
                            <div class="bg-gray-50 p-4 rounded-lg mb-6">
                                <div class="flex space-x-4">
                                    <button id="study-language-btn" class="study-sub-btn btn-primary px-4 py-2 rounded-lg">
                                        <i class="fas fa-language mr-2"></i>어학연수
                                    </button>
                                    <button id="study-undergraduate-btn" class="study-sub-btn btn-secondary px-4 py-2 rounded-lg">
                                        <i class="fas fa-graduation-cap mr-2"></i>학부(학위)과정
                                    </button>
                                    <button id="study-graduate-btn" class="study-sub-btn btn-secondary px-4 py-2 rounded-lg">
                                        <i class="fas fa-university mr-2"></i>석·박사과정
                                    </button>
                                </div>
                            </div>
                            
                            <!-- 어학연수 -->
                            <div id="study-language-section" class="study-sub-content">
                                <div class="mb-6">
                                    <h3 class="text-2xl font-bold text-gray-800 mb-4">한국어학연수 프로그램</h3>
                                    <div class="bg-blue-50 p-4 rounded-lg mb-6">
                                        <p class="text-blue-800 text-sm">
                                            <i class="fas fa-info-circle mr-2"></i>
                                            한국어 실력 향상을 위한 체계적인 어학연수 프로그램 정보를 제공합니다
                                        </p>
                                    </div>
                                </div>
                                
                                <!-- 어학연수 개요 -->
                                <div class="grid md:grid-cols-2 gap-6 mb-8">
                                    <div class="bg-white p-6 rounded-lg shadow-md">
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                            <i class="fas fa-clock text-blue-500 mr-2"></i>프로그램 기간
                                        </h4>
                                        <ul class="space-y-2 text-gray-600">
                                            <li><strong>단기과정:</strong> 3개월 ~ 6개월</li>
                                            <li><strong>장기과정:</strong> 1년 ~ 2년</li>
                                            <li><strong>집중과정:</strong> 주 20시간 이상</li>
                                            <li><strong>일반과정:</strong> 주 15시간</li>
                                        </ul>
                                    </div>
                                    
                                    <div class="bg-white p-6 rounded-lg shadow-md">
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                            <i class="fas fa-won-sign text-green-500 mr-2"></i>예상 비용
                                        </h4>
                                        <ul class="space-y-2 text-gray-600">
                                            <li><strong>수업료:</strong> 학기당 150만원 ~ 200만원</li>
                                            <li><strong>기숙사:</strong> 월 30만원 ~ 50만원</li>
                                            <li><strong>생활비:</strong> 월 40만원 ~ 60만원</li>
                                            <li><strong>교재비:</strong> 학기당 10만원 ~ 15만원</li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <!-- 필요 서류 및 절차 -->
                                <div class="bg-white p-6 rounded-lg shadow-md mb-6">
                                    <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                        <i class="fas fa-file-alt text-purple-500 mr-2"></i>필요 서류 및 절차
                                    </h4>
                                    <div class="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <h5 class="font-medium text-gray-700 mb-3">필수 서류</h5>
                                            <ul class="space-y-1 text-gray-600 text-sm">
                                                <li>• 입학원서</li>
                                                <li>• 여권 사본</li>
                                                <li>• 최종 학력 증명서</li>
                                                <li>• 성적 증명서</li>
                                                <li>• 은행 잔고 증명서 ($10,000 이상)</li>
                                                <li>• 건강진단서</li>
                                                <li>• 범죄경력증명서</li>
                                            </ul>
                                        </div>
                                        <div>
                                            <h5 class="font-medium text-gray-700 mb-3">지원 절차</h5>
                                            <ol class="space-y-1 text-gray-600 text-sm">
                                                <li>1. 학교 선택 및 정보 수집</li>
                                                <li>2. 서류 준비 및 제출</li>
                                                <li>3. 입학 허가서 수령</li>
                                                <li>4. D-4 비자 신청</li>
                                                <li>5. 항공권 예약 및 출국 준비</li>
                                                <li>6. 입국 후 외국인등록</li>
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- 추천 대학교 -->
                                <div class="bg-white p-6 rounded-lg shadow-md">
                                    <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                        <i class="fas fa-star text-yellow-500 mr-2"></i>추천 어학원
                                    </h4>
                                    <div class="grid md:grid-cols-3 gap-4">
                                        <div class="border rounded-lg p-4 hover:shadow-md transition-shadow">
                                            <h5 class="font-medium text-gray-800">서울대학교 언어교육원</h5>
                                            <p class="text-sm text-gray-600 mt-2">체계적인 커리큘럼과 우수한 강사진</p>
                                            <div class="text-xs text-blue-600 mt-2">학기당 180만원</div>
                                        </div>
                                        <div class="border rounded-lg p-4 hover:shadow-md transition-shadow">
                                            <h5 class="font-medium text-gray-800">연세대학교 한국어학당</h5>
                                            <p class="text-sm text-gray-600 mt-2">60년 전통의 한국어 교육 기관</p>
                                            <div class="text-xs text-blue-600 mt-2">학기당 170만원</div>
                                        </div>
                                        <div class="border rounded-lg p-4 hover:shadow-md transition-shadow">
                                            <h5 class="font-medium text-gray-800">고려대학교 한국어센터</h5>
                                            <p class="text-sm text-gray-600 mt-2">실용적인 한국어 교육 프로그램</p>
                                            <div class="text-xs text-blue-600 mt-2">학기당 165만원</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 학부(학위)과정 -->
                            <div id="study-undergraduate-section" class="study-sub-content hidden">
                                <div class="mb-6">
                                    <h3 class="text-2xl font-bold text-gray-800 mb-4">학부(학위)과정 프로그램</h3>
                                    <div class="bg-green-50 p-4 rounded-lg mb-6">
                                        <p class="text-green-800 text-sm">
                                            <i class="fas fa-info-circle mr-2"></i>
                                            한국 대학교 학부과정 진학을 위한 종합 정보를 제공합니다
                                        </p>
                                    </div>
                                </div>
                                
                                <!-- 학부과정 개요 -->
                                <div class="grid md:grid-cols-2 gap-6 mb-8">
                                    <div class="bg-white p-6 rounded-lg shadow-md">
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                            <i class="fas fa-calendar text-blue-500 mr-2"></i>프로그램 정보
                                        </h4>
                                        <ul class="space-y-2 text-gray-600">
                                            <li><strong>학위:</strong> 학사 (Bachelor's Degree)</li>
                                            <li><strong>기간:</strong> 4년 (8학기)</li>
                                            <li><strong>입학 시기:</strong> 3월, 9월</li>
                                            <li><strong>수업 언어:</strong> 한국어 (일부 영어 과정)</li>
                                        </ul>
                                    </div>
                                    
                                    <div class="bg-white p-6 rounded-lg shadow-md">
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                            <i class="fas fa-won-sign text-green-500 mr-2"></i>학비 및 생활비
                                        </h4>
                                        <ul class="space-y-2 text-gray-600">
                                            <li><strong>국립대 학비:</strong> 연 300만원 ~ 500만원</li>
                                            <li><strong>사립대 학비:</strong> 연 800만원 ~ 1,200만원</li>
                                            <li><strong>기숙사비:</strong> 월 30만원 ~ 80만원</li>
                                            <li><strong>생활비:</strong> 월 60만원 ~ 100만원</li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <!-- 입학 요건 -->
                                <div class="bg-white p-6 rounded-lg shadow-md mb-6">
                                    <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                        <i class="fas fa-clipboard-check text-purple-500 mr-2"></i>입학 요건 및 지원 절차
                                    </h4>
                                    <div class="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <h5 class="font-medium text-gray-700 mb-3">입학 요건</h5>
                                            <ul class="space-y-1 text-gray-600 text-sm">
                                                <li>• 고등학교 졸업 또는 동등 학력</li>
                                                <li>• TOPIK 3급 이상 (권장 4급 이상)</li>
                                                <li>• 영어: TOEFL 80+ 또는 IELTS 6.0+</li>
                                                <li>• 고교 성적 평균 70점 이상</li>
                                                <li>• 학업 계획서 및 자기소개서</li>
                                                <li>• 추천서 (교사 또는 교수)</li>
                                            </ul>
                                        </div>
                                        <div>
                                            <h5 class="font-medium text-gray-700 mb-3">지원 절차</h5>
                                            <ol class="space-y-1 text-gray-600 text-sm">
                                                <li>1. 대학 및 학과 선택</li>
                                                <li>2. 어학 성적 준비</li>
                                                <li>3. 지원 서류 준비</li>
                                                <li>4. 온라인 지원서 제출</li>
                                                <li>5. 면접 (필요시)</li>
                                                <li>6. 합격 발표 및 등록</li>
                                                <li>7. D-2 비자 신청</li>
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- 인기 학과 -->
                                <div class="bg-white p-6 rounded-lg shadow-md">
                                    <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                        <i class="fas fa-chart-line text-orange-500 mr-2"></i>외국인 학생 인기 학과
                                    </h4>
                                    <div class="grid md:grid-cols-4 gap-4">
                                        <div class="text-center p-4 border rounded-lg hover:shadow-md transition-shadow">
                                            <div class="text-2xl mb-2">💻</div>
                                            <h5 class="font-medium text-gray-800">컴퓨터공학</h5>
                                            <p class="text-xs text-gray-600 mt-1">IT 강국 한국의 핵심 분야</p>
                                        </div>
                                        <div class="text-center p-4 border rounded-lg hover:shadow-md transition-shadow">
                                            <div class="text-2xl mb-2">🏢</div>
                                            <h5 class="font-medium text-gray-800">경영학</h5>
                                            <p class="text-xs text-gray-600 mt-1">글로벌 비즈니스 역량</p>
                                        </div>
                                        <div class="text-center p-4 border rounded-lg hover:shadow-md transition-shadow">
                                            <div class="text-2xl mb-2">🎨</div>
                                            <h5 class="font-medium text-gray-800">디자인</h5>
                                            <p class="text-xs text-gray-600 mt-1">K-컬처의 창조적 산업</p>
                                        </div>
                                        <div class="text-center p-4 border rounded-lg hover:shadow-md transition-shadow">
                                            <div class="text-2xl mb-2">🌐</div>
                                            <h5 class="font-medium text-gray-800">국제학</h5>
                                            <p class="text-xs text-gray-600 mt-1">국제 관계 및 외교</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 석·박사과정 -->
                            <div id="study-graduate-section" class="study-sub-content hidden">
                                <div class="mb-6">
                                    <h3 class="text-2xl font-bold text-gray-800 mb-4">석·박사과정 프로그램</h3>
                                    <div class="bg-purple-50 p-4 rounded-lg mb-6">
                                        <p class="text-purple-800 text-sm">
                                            <i class="fas fa-info-circle mr-2"></i>
                                            한국 대학원 석사 및 박사과정 진학을 위한 상세 정보를 제공합니다
                                        </p>
                                    </div>
                                </div>
                                
                                <!-- 대학원 과정 개요 -->
                                <div class="grid md:grid-cols-2 gap-6 mb-8">
                                    <div class="bg-white p-6 rounded-lg shadow-md">
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                            <i class="fas fa-graduation-cap text-blue-500 mr-2"></i>석사과정 (Master's)
                                        </h4>
                                        <ul class="space-y-2 text-gray-600">
                                            <li><strong>기간:</strong> 2년 (4학기)</li>
                                            <li><strong>학점:</strong> 24학점 + 논문</li>
                                            <li><strong>입학 시기:</strong> 3월, 9월</li>
                                            <li><strong>학비:</strong> 연 500만원 ~ 1,500만원</li>
                                            <li><strong>장학금:</strong> 다양한 정부/교내 장학금</li>
                                        </ul>
                                    </div>
                                    
                                    <div class="bg-white p-6 rounded-lg shadow-md">
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                            <i class="fas fa-user-graduate text-purple-500 mr-2"></i>박사과정 (Doctorate)
                                        </h4>
                                        <ul class="space-y-2 text-gray-600">
                                            <li><strong>기간:</strong> 3년 이상 (6학기+)</li>
                                            <li><strong>학점:</strong> 36학점 + 박사논문</li>
                                            <li><strong>입학 시기:</strong> 3월, 9월</li>
                                            <li><strong>학비:</strong> 연 600만원 ~ 1,800만원</li>
                                            <li><strong>연구비 지원:</strong> BK21, NRF 등</li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <!-- 입학 요건 및 절차 -->
                                <div class="bg-white p-6 rounded-lg shadow-md mb-6">
                                    <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                        <i class="fas fa-tasks text-green-500 mr-2"></i>입학 요건 및 지원 절차
                                    </h4>
                                    <div class="grid md:grid-cols-2 gap-6">
                                        <div>
                                            <h5 class="font-medium text-gray-700 mb-3">공통 입학 요건</h5>
                                            <ul class="space-y-1 text-gray-600 text-sm">
                                                <li>• 학사/석사 학위 (해당 과정)</li>
                                                <li>• TOPIK 4급 이상 (이공계 3급 가능)</li>
                                                <li>• 영어: TOEFL 80+ 또는 IELTS 6.5+</li>
                                                <li>• 학부/석사 성적 3.0/4.5 이상</li>
                                                <li>• 연구계획서 (매우 중요)</li>
                                                <li>• 추천서 2부 (교수 추천)</li>
                                                <li>• 포트폴리오 (분야별)</li>
                                            </ul>
                                        </div>
                                        <div>
                                            <h5 class="font-medium text-gray-700 mb-3">지원 및 선발 과정</h5>
                                            <ol class="space-y-1 text-gray-600 text-sm">
                                                <li>1. 연구 분야 및 지도교수 선정</li>
                                                <li>2. 사전 컨택 (이메일 교류)</li>
                                                <li>3. 지원서류 준비 및 제출</li>
                                                <li>4. 서류 심사</li>
                                                <li>5. 면접 또는 구술시험</li>
                                                <li>6. 최종 합격 발표</li>
                                                <li>7. 등록 및 D-2 비자 신청</li>
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- 연구 분야 및 장학금 -->
                                <div class="grid md:grid-cols-2 gap-6">
                                    <div class="bg-white p-6 rounded-lg shadow-md">
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                            <i class="fas fa-flask text-blue-500 mr-2"></i>주요 연구 분야
                                        </h4>
                                        <div class="space-y-3">
                                            <div class="border-l-4 border-blue-500 pl-4">
                                                <h5 class="font-medium text-gray-800">이공계열</h5>
                                                <p class="text-sm text-gray-600">AI, 바이오, 반도체, 신재생에너지</p>
                                            </div>
                                            <div class="border-l-4 border-green-500 pl-4">
                                                <h5 class="font-medium text-gray-800">인문사회</h5>
                                                <p class="text-sm text-gray-600">한국학, 국제관계, 경영학, 교육학</p>
                                            </div>
                                            <div class="border-l-4 border-purple-500 pl-4">
                                                <h5 class="font-medium text-gray-800">예술체육</h5>
                                                <p class="text-sm text-gray-600">K-컬처, 디자인, 음악, 체육학</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="bg-white p-6 rounded-lg shadow-md">
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">
                                            <i class="fas fa-medal text-yellow-500 mr-2"></i>장학금 정보
                                        </h4>
                                        <div class="space-y-3 text-sm">
                                            <div class="bg-yellow-50 p-3 rounded">
                                                <h5 class="font-medium text-yellow-800">정부 장학금</h5>
                                                <p class="text-yellow-700">GKS, KGSP (전액 + 생활비)</p>
                                            </div>
                                            <div class="bg-blue-50 p-3 rounded">
                                                <h5 class="font-medium text-blue-800">교내 장학금</h5>
                                                <p class="text-blue-700">성적우수, 연구조교, 교육조교</p>
                                            </div>
                                            <div class="bg-green-50 p-3 rounded">
                                                <h5 class="font-medium text-green-800">외부 장학금</h5>
                                                <p class="text-green-700">기업 후원, 재단 장학금</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="content-stats" class="tab-content hidden">
                            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                                <div class="bg-blue-50 p-4 rounded-lg">
                                    <div class="flex items-center">
                                        <i class="fas fa-users text-blue-500 text-2xl mr-3"></i>
                                        <div>
                                            <div class="text-2xl font-bold text-blue-600" id="stat-jobseekers">-</div>
                                            <div class="text-sm text-gray-600">구직자</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="bg-green-50 p-4 rounded-lg">
                                    <div class="flex items-center">
                                        <i class="fas fa-building text-green-500 text-2xl mr-3"></i>
                                        <div>
                                            <div class="text-2xl font-bold text-green-600" id="stat-employers">-</div>
                                            <div class="text-sm text-gray-600">기업</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="bg-purple-50 p-4 rounded-lg">
                                    <div class="flex items-center">
                                        <i class="fas fa-briefcase text-purple-500 text-2xl mr-3"></i>
                                        <div>
                                            <div class="text-2xl font-bold text-purple-600" id="stat-jobs">-</div>
                                            <div class="text-sm text-gray-600">구인공고</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="bg-orange-50 p-4 rounded-lg">
                                    <div class="flex items-center">
                                        <i class="fas fa-handshake text-orange-500 text-2xl mr-3"></i>
                                        <div>
                                            <div class="text-2xl font-bold text-orange-600" id="stat-matches">-</div>
                                            <div class="text-sm text-gray-600">매칭 성공</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            </div>
        </main>

        <!-- Footer -->
        <footer class="bg-wowcampus-dark text-white py-16">
            <div class="container mx-auto px-6">
                <div class="grid md:grid-cols-4 gap-8 mb-8">
                    <div class="col-span-2">
                        <div class="flex items-center space-x-3 mb-6">
                            <div class="w-12 h-12 bg-gradient-to-br from-wowcampus-blue to-accent rounded-lg flex items-center justify-center">
                                <i class="fas fa-graduation-cap text-white text-xl"></i>
                            </div>
                            <div>
                                <h3 class="text-2xl font-bold">WOW-CAMPUS</h3>
                                <span class="text-gray-300 text-sm">외국인 구인구직 및 유학 플랫폼</span>
                            </div>
                        </div>
                        <p class="text-gray-300 mb-4 leading-relaxed">
                            외국인 인재와 국내 기업을 연결하는 전문 플랫폼입니다. <br>
                            전문 에이전트와 함께 성공적인 취업과 유학을 지원합니다.
                        </p>
                        <div class="flex space-x-4">
                            <a href="#" class="text-gray-300 hover:text-white transition-colors">
                                <i class="fab fa-facebook-f text-xl"></i>
                            </a>
                            <a href="#" class="text-gray-300 hover:text-white transition-colors">
                                <i class="fab fa-twitter text-xl"></i>
                            </a>
                            <a href="#" class="text-gray-300 hover:text-white transition-colors">
                                <i class="fab fa-linkedin-in text-xl"></i>
                            </a>
                        </div>
                    </div>
                    
                    <div>
                        <h4 class="text-lg font-semibold mb-4">서비스</h4>
                        <ul class="space-y-2 text-gray-300">
                            <li><a href="#" class="hover:text-white transition-colors">구인정보</a></li>
                            <li><a href="#" class="hover:text-white transition-colors">구직정보</a></li>
                            <li><a href="#" class="hover:text-white transition-colors">유학지원</a></li>
                            <li><a href="#" class="hover:text-white transition-colors">에이전트</a></li>
                        </ul>
                    </div>
                    
                    <div>
                        <h4 class="text-lg font-semibold mb-4">고객지원</h4>
                        <ul class="space-y-2 text-gray-300">
                            <li><a href="/static/notice" class="hover:text-white transition-colors">공지사항</a></li>
                            <li><a href="/static/faq" class="hover:text-white transition-colors">FAQ</a></li>
                            <li><a href="/static/contact" class="hover:text-white transition-colors">문의하기</a></li>
                            <li><a href="/static/terms" class="hover:text-white transition-colors">이용약관</a></li>
                            <li><a href="/static/privacy" class="hover:text-white transition-colors">개인정보처리방침</a></li>
                            <li><a href="/static/cookies" class="hover:text-white transition-colors">쿠키정책</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="border-t border-gray-700 pt-8">
                    <div class="flex flex-col md:flex-row justify-between items-center">
                        <p class="text-gray-400 text-sm">
                            &copy; 2025 WOW-CAMPUS 외국인 구인구직 및 유학생 지원플랫폼. All rights reserved.
                        </p>
                        <div class="flex space-x-6 mt-4 md:mt-0">
                            <a href="/static/terms" class="text-gray-400 hover:text-white text-sm transition-colors">이용약관</a>
                            <a href="/static/privacy" class="text-gray-400 hover:text-white text-sm transition-colors">개인정보처리방침</a>
                            <a href="/static/cookies" class="text-gray-400 hover:text-white text-sm transition-colors">쿠키정책</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"><\/script>
        <script>
            // 에이전트 관리 클릭 처리 함수
            function handleAgentManagementClick() {
                // 로그인 상태 확인
                const token = localStorage.getItem('token');
                const user = JSON.parse(localStorage.getItem('user') || '{}');
                
                if (!token) {
                    // 미로그인 상태
                    const message = "로그인이 필요합니다\\n\\n에이전트 관리 기능을 이용하시려면 먼저 로그인해주세요.\\n\\n에이전트 계정으로 로그인 시:\\n- 구직자 등록 및 관리\\n- 학생 등록 및 관리\\n- 지원 현황 관리\\n- 매칭 서비스 이용\\n\\n지금 로그인하시겠습니까?";

                    if (confirm(message)) {
                        window.location.href = '/static/login.html';
                    }
                    return;
                }
                
                // 로그인된 상태 - 사용자 유형 확인
                if (user.type === 'agent' || user.type === 'admin') {
                    // 에이전트 또는 관리자인 경우 대시보드로 이동
                    window.location.href = \`/static/agent-dashboard?agentId=\${user.id}\`;
                } else {
                    // 일반 회원인 경우
                    const restrictMessage = "에이전트 전용 메뉴입니다\\n\\n죄송합니다. 이 기능은 에이전트 회원만 이용할 수 있습니다.\\n\\n현재 회원 유형: " + getUserTypeName(user.type) + "\\n\\n에이전트 기능을 이용하시려면:\\n- 에이전트 계정으로 새로 회원가입\\n- 또는 에이전트 계정으로 로그인\\n\\n에이전트 회원가입을 진행하시겠습니까?";

                    if (confirm(restrictMessage)) {
                        window.location.href = '/static/register.html?type=agent';
                    }
                }
            }
            
            // 사용자 유형명 변환 함수
            function getUserTypeName(userType) {
                const typeNames = {
                    'jobseeker': '구직자',
                    'employer': '기업 회원',
                    'agent': '에이전트',
                    'admin': '관리자'
                };
                return typeNames[userType] || userType;
            }
        <\/script>
        
        <!-- Auth UI control script removed for normal operation -->
            (function(){

        <script src="/static/app.js"><\/script>
    </body>
    </html>
  `)});f.post("/api/auth/login",async e=>{try{const{email:t,password:r,userType:s}=await e.req.json();if(!t||!r||!s)return e.json({error:"필수 정보가 누락되었습니다."},400);let a;switch(s){case"agent":a="agents";break;case"employer":a="employers";break;case"jobseeker":a="job_seekers";break;case"admin":a="admins";break;default:return e.json({error:"잘못된 사용자 유형입니다."},400)}let n="id, email, password, status";a==="employers"?n+=", company_name, contact_person":a==="job_seekers"?n+=", name":a==="agents"&&(n+=", company_name, contact_person");const o=await e.env.DB.prepare(`SELECT ${n} FROM ${a} WHERE email = ?`).bind(t).first();if(!o)return e.json({error:"이메일 또는 비밀번호가 올바르지 않습니다."},401);const i=await We(r);if(!(o.password===i||o.password===r))return e.json({error:"이메일 또는 비밀번호가 올바르지 않습니다."},401);if(s==="agent"){if(o.status!=="approved"&&o.status!=="active")return o.status==="pending"?e.json({error:"에이전트 계정은 관리자 승인이 필요합니다. 승인 대기 중입니다.",status:"pending_approval"},403):e.json({error:"승인되지 않은 계정입니다."},401)}else if(!["approved","active"].includes(o.status))return e.json({error:"계정 상태를 확인해주세요."},401);const c=`token_${o.id}_${s}`,d={id:o.id,email:o.email,type:s,status:o.status};return s==="employer"?(d.company_name=o.company_name,d.contact_person=o.contact_person):s==="jobseeker"?d.name=o.name:s==="agent"&&(d.company_name=o.company_name,d.contact_person=o.contact_person),e.json({success:!0,token:c,user:d})}catch{return e.json({error:"로그인 중 오류가 발생했습니다."},500)}});f.post("/api/auth/register/employer",async e=>{try{const{email:t,password:r,company_name:s,business_number:a,industry:n,contact_person:o,phone:i,address:l,region:c,website:d}=await e.req.json();if(!t||!r||!s||!a||!n||!o||!i||!l||!c)return e.json({error:"필수 정보가 누락되었습니다."},400);if(await e.env.DB.prepare("SELECT id FROM employers WHERE email = ?").bind(t).first())return e.json({error:"이미 등록된 이메일입니다."},400);if(await e.env.DB.prepare("SELECT id FROM employers WHERE business_number = ?").bind(a).first())return e.json({error:"이미 등록된 사업자번호입니다."},400);const h=await We(r),v=await e.env.DB.prepare(`
      INSERT INTO employers (
        email, password, company_name, business_number, industry, 
        contact_person, phone, address, region, website, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'approved')
    `).bind(t,h,s,a,n,o,i,l,c,d||null).run(),g=`token_${v.meta.last_row_id}_employer`;return e.json({success:!0,message:"구인 기업 회원가입이 완료되었습니다. 바로 로그인하여 이용하실 수 있습니다.",token:g,user:{id:v.meta.last_row_id,email:t,type:"employer",company_name:s,status:"approved"}},201)}catch(t){return console.error("Employer registration error:",t),e.json({error:"구인 기업 회원가입 중 오류가 발생했습니다."},500)}});f.post("/api/auth/register/jobseeker",async e=>{try{console.log("=== 구직자 회원가입 API 시작 ===");const t=await e.req.json();console.log("Request Data:",t);const{email:r,password:s,name:a,birth_date:n,gender:o,nationality:i,current_visa:l,desired_visa:c,phone:d,current_address:p,korean_level:m,education_level:h,work_experience:v,agent_id:g}=t;if(!r||!s||!a||!i||!d)return console.log("❌ 필수 정보 누락"),e.json({error:"필수 정보가 누락되었습니다."},400);if(console.log("✅ 필수 정보 확인 완료"),await e.env.DB.prepare("SELECT id FROM job_seekers WHERE email = ?").bind(r).first())return e.json({error:"이미 등록된 이메일입니다."},400);const j=At(m||""),w=o==="남성"?"male":o==="여성"?"female":o;if(g&&!await e.env.DB.prepare(`
        SELECT id FROM agents WHERE id = ? AND status = 'approved'
      `).bind(g).first())return e.json({error:"유효하지 않은 에이전트입니다."},400);const T=await We(s);console.log("데이터베이스 삽입 시작...");const E=await e.env.DB.prepare(`
      INSERT INTO job_seekers (
        email, password, name, birth_date, gender, nationality, 
        current_visa, desired_visa, phone, current_address, 
        korean_level, education_level, work_experience, agent_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'approved')
    `).bind(r,T,a,n||null,w||null,i,l||null,c||null,d,p||null,j,h||null,v||null,g||null).run();console.log("✅ 데이터베이스 삽입 완료:",E),console.log("New User ID:",E.meta.last_row_id);const D=`token_${E.meta.last_row_id}_jobseeker`;console.log("Generated Token:",D);const M={success:!0,message:"구직자 회원가입이 완료되었습니다. 바로 로그인하여 이용하실 수 있습니다.",token:D,user:{id:E.meta.last_row_id,email:r,type:"jobseeker",name:a,status:"approved"}};return console.log("✅ 구직자 회원가입 성공 응답:",M),e.json(M,201)}catch(t){return console.error("❌ 구직자 회원가입 오류:",t),console.error("Error details:",t.message,t.stack),e.json({error:"구직자 회원가입 중 오류가 발생했습니다: "+t.message},500)}});f.post("/api/auth/register/agent",async e=>{try{const{email:t,password:r,company_name:s,country:a,contact_person:n,phone:o,address:i,license_number:l,description:c}=await e.req.json();if(!t||!r||!s||!a||!n||!o||!i)return e.json({error:"필수 정보가 누락되었습니다."},400);if(await e.env.DB.prepare("SELECT id FROM agents WHERE email = ?").bind(t).first())return e.json({error:"이미 등록된 이메일입니다."},400);const p=await We(r),m=await e.env.DB.prepare(`
      INSERT INTO agents (
        email, password, company_name, country, contact_person, 
        phone, address, license_number, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    `).bind(t,p,s,a,n,o,i,l||null).run(),h=`token_${m.meta.last_row_id}_agent`;return e.json({success:!0,message:"에이전트 회원가입이 완료되었습니다. 관리자 승인 후 이용 가능합니다. 승인까지 1-2일 소요될 수 있습니다.",token:h,user:{id:m.meta.last_row_id,email:t,type:"agent",company_name:s,status:"pending"}},201)}catch(t){return console.error("Agent registration error:",t),e.json({error:"에이전트 회원가입 중 오류가 발생했습니다."},500)}});f.post("/api/auth/google",async e=>{try{const{googleToken:t,userType:r,additionalData:s}=await e.req.json();if(!t||!r)return e.json({error:"필수 정보가 누락되었습니다."},400);const a={email:`user_${Date.now()}@gmail.com`,name:"Google User",verified:!0};let n=r==="employer"?"employers":"job_seekers";const o=await e.env.DB.prepare(`SELECT id, email, status FROM ${n} WHERE email = ?`).bind(a.email).first();if(o){const i=`token_${o.id}_${r}`;return e.json({message:"구글 로그인이 완료되었습니다.",token:i,user:{id:o.id,email:o.email,type:r,status:o.status}})}else{let i;if(r==="employer"){const{company_name:c,business_number:d,industry:p,contact_person:m,phone:h,address:v,region:g,website:b}=s||{};if(!c||!d||!p||!m||!h||!v||!g)return e.json({error:"구인 기업 추가 정보가 필요합니다."},400);i=await e.env.DB.prepare(`
          INSERT INTO employers (
            email, password, company_name, business_number, industry, 
            contact_person, phone, address, region, website, status
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        `).bind(a.email,"google_oauth",c,d,p,m,h,v,g,b||null).run()}else{const{name:c,nationality:d,phone:p}=s||{};if(!c||!d||!p)return e.json({error:"구직자 추가 정보가 필요합니다."},400);i=await e.env.DB.prepare(`
          INSERT INTO job_seekers (
            email, password, name, nationality, phone, status
          ) VALUES (?, ?, ?, ?, ?, 'active')
        `).bind(a.email,"google_oauth",c,d,p).run()}const l=`token_${i.meta.last_row_id}_${r}`;return e.json({message:"구글 회원가입이 완료되었습니다.",token:l,user:{id:i.meta.last_row_id,email:a.email,type:r,status:r==="employer"?"pending":"active"}},201)}}catch(t){return console.error("Google auth error:",t),e.json({error:"구글 인증 중 오류가 발생했습니다."},500)}});f.get("/admin-dashboard",async e=>{try{const t=await fetch(`${e.req.url.replace("/admin-dashboard","")}/static/admin-dashboard.html`);if(t.ok){const r=await t.text();return e.html(r)}else return e.redirect("/static/admin-dashboard.html")}catch(t){return console.error("Admin dashboard loading error:",t),e.redirect("/static/admin-dashboard.html")}});f.get("/api/jobs",async e=>{try{const{category:t,visa:r,region:s,page:a=1,limit:n=10}=e.req.query();let o=`
      SELECT jp.*, e.company_name, e.region as company_region
      FROM job_postings jp
      LEFT JOIN employers e ON jp.employer_id = e.id
      WHERE jp.status = 'active'
    `;const i=[];t&&(o+=" AND jp.job_category = ?",i.push(t)),r&&(o+=" AND jp.required_visa = ?",i.push(r)),s&&(o+=" AND jp.region = ?",i.push(s)),o+=" ORDER BY jp.created_at DESC LIMIT ? OFFSET ?",i.push(parseInt(n),(parseInt(a)-1)*parseInt(n));const l=await e.env.DB.prepare(o).bind(...i).all();return e.json({jobs:l.results,page:parseInt(a),limit:parseInt(n)})}catch{return e.json({error:"구인 정보 조회 중 오류가 발생했습니다."},500)}});f.get("/api/jobs/:id",async e=>{try{const t=e.req.param("id"),r=e.req.header("Authorization");if(!r||!r.startsWith("Bearer "))return e.json({error:"로그인이 필요합니다.",message:"구인정보의 상세 내용을 보시려면 로그인해주세요.",requireAuth:!0},401);const s=r.substring(7);if(s.startsWith("token_")){const n=s.split("_");if(n.length<3||!n[1]||!n[2])return e.json({error:"유효하지 않은 토큰입니다.",message:"다시 로그인해주세요.",requireAuth:!0},401)}else try{await qe(s,ot)}catch{return e.json({error:"유효하지 않은 토큰입니다.",message:"다시 로그인해주세요.",requireAuth:!0},401)}const a=await e.env.DB.prepare(`
      SELECT jp.*, e.company_name, e.contact_person, e.phone, e.address, e.website
      FROM job_postings jp
      LEFT JOIN employers e ON jp.employer_id = e.id
      WHERE jp.id = ? AND jp.status = 'active'
    `).bind(t).first();return a?e.json({job:a}):e.json({error:"구인 공고를 찾을 수 없습니다."},404)}catch{return e.json({error:"구인 공고 조회 중 오류가 발생했습니다."},500)}});f.post("/api/job-seekers",async e=>{try{const t=await e.req.json(),r=["name","email","birth_date","gender","nationality","phone","current_visa","desired_visa","current_address","korean_level","education_level"];for(const a of r)if(!t[a])return e.json({error:`${a} 필드는 필수입니다.`},400);const s=await e.env.DB.prepare(`
      INSERT INTO job_seekers (
        email, password, name, birth_date, gender, nationality,
        current_visa, desired_visa, phone, current_address,
        korean_level, education_level, work_experience, agent_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
    `).bind(t.email,t.password||"temp_password",t.name,t.birth_date,t.gender,t.nationality,t.current_visa,t.desired_visa,t.phone,t.current_address,At(t.korean_level),t.education_level,t.work_experience||null,t.agent_id||1).run();return e.json({success:!0,jobSeekerId:s.meta.last_row_id,message:"구직정보가 성공적으로 등록되었습니다."},201)}catch(t){return console.error("Job seeker registration error:",t),t.message.includes("UNIQUE constraint failed")?e.json({error:"이미 등록된 이메일입니다."},400):e.json({error:"구직정보 등록 중 오류가 발생했습니다."},500)}});f.get("/api/study-programs",async e=>{try{const{type:t,location:r,page:s=1,limit:a=10}=e.req.query();let n='SELECT * FROM study_programs WHERE status = "active"';const o=[];t&&(n+=" AND program_type = ?",o.push(t)),r&&(n+=" AND location LIKE ?",o.push(`%${r}%`)),n+=" ORDER BY created_at DESC LIMIT ? OFFSET ?",o.push(parseInt(a),(parseInt(s)-1)*parseInt(a));const i=await e.env.DB.prepare(n).bind(...o).all();return e.json({programs:i.results,page:parseInt(s),limit:parseInt(a)})}catch{return e.json({error:"유학 프로그램 조회 중 오류가 발생했습니다."},500)}});f.get("/api/agent/:agentId/job-seekers",async e=>{try{const t=e.req.param("agentId"),r=await e.env.DB.prepare(`
      SELECT * FROM job_seekers 
      WHERE agent_id = ? 
      ORDER BY created_at DESC
    `).bind(t).all();return e.json({jobSeekers:r.results})}catch{return e.json({error:"구직자 목록 조회 중 오류가 발생했습니다."},500)}});f.post("/api/agent/job-seekers",async e=>{try{const t=await e.req.json(),r=await e.env.DB.prepare(`
      INSERT INTO job_seekers (
        email, password, name, birth_date, gender, nationality, 
        current_visa, desired_visa, phone, current_address, 
        korean_level, education_level, work_experience, agent_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
    `).bind(t.email,t.password,t.name,t.birth_date,t.gender,t.nationality,t.current_visa,t.desired_visa,t.phone,t.current_address,t.korean_level,t.education_level,t.work_experience,t.agent_id).run();return e.json({success:!0,jobSeekerId:r.meta.last_row_id,message:"구직자가 성공적으로 등록되었습니다."})}catch(t){return t.message.includes("UNIQUE constraint failed")?e.json({error:"이미 등록된 이메일입니다."},400):e.json({error:"구직자 등록 중 오류가 발생했습니다."},500)}});f.put("/api/agent/job-seekers/:id",async e=>{try{const t=e.req.param("id"),r=await e.req.json();return await e.env.DB.prepare(`
      UPDATE job_seekers SET
        name = ?, birth_date = ?, gender = ?, nationality = ?,
        current_visa = ?, desired_visa = ?, phone = ?, current_address = ?,
        korean_level = ?, education_level = ?, work_experience = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(r.name,r.birth_date,r.gender,r.nationality,r.current_visa,r.desired_visa,r.phone,r.current_address,r.korean_level,r.education_level,r.work_experience,t).run(),e.json({success:!0,message:"구직자 정보가 수정되었습니다."})}catch{return e.json({error:"구직자 정보 수정 중 오류가 발생했습니다."},500)}});f.delete("/api/agent/job-seekers/:id",async e=>{try{const t=e.req.param("id");return await e.env.DB.prepare("DELETE FROM job_seekers WHERE id = ?").bind(t).run(),e.json({success:!0,message:"구직자가 삭제되었습니다."})}catch{return e.json({error:"구직자 삭제 중 오류가 발생했습니다."},500)}});f.get("/api/agent/:agentId/job-applications",async e=>{try{const t=e.req.param("agentId"),r=await e.env.DB.prepare(`
      SELECT ja.*, js.name as jobseeker_name, jp.title as job_title, e.company_name
      FROM job_applications ja
      LEFT JOIN job_seekers js ON ja.job_seeker_id = js.id
      LEFT JOIN job_postings jp ON ja.job_posting_id = jp.id
      LEFT JOIN employers e ON jp.employer_id = e.id
      WHERE ja.agent_id = ?
      ORDER BY ja.applied_at DESC
    `).bind(t).all();return e.json({applications:r.results})}catch{return e.json({error:"지원 현황 조회 중 오류가 발생했습니다."},500)}});f.get("/api/agent/:agentId/study-applications",async e=>{try{const t=e.req.param("agentId"),r=await e.env.DB.prepare(`
      SELECT sa.*, js.name as jobseeker_name, sp.program_name, sp.institution_name
      FROM study_applications sa
      LEFT JOIN job_seekers js ON sa.job_seeker_id = js.id
      LEFT JOIN study_programs sp ON sa.program_id = sp.id
      WHERE sa.agent_id = ?
      ORDER BY sa.applied_at DESC
    `).bind(t).all();return e.json({applications:r.results})}catch{return e.json({error:"유학 지원 현황 조회 중 오류가 발생했습니다."},500)}});f.post("/api/applications/job",async e=>{try{const{job_seeker_id:t,job_posting_id:r,agent_id:s,cover_letter:a}=await e.req.json(),n=await e.env.DB.prepare(`
      INSERT INTO job_applications (job_seeker_id, job_posting_id, agent_id, cover_letter)
      VALUES (?, ?, ?, ?)
    `).bind(t,r,s,a).run();return e.json({success:!0,applicationId:n.meta.last_row_id,message:"지원이 완료되었습니다."})}catch{return e.json({error:"지원 중 오류가 발생했습니다."},500)}});f.get("/api/stats",async e=>{try{const[t,r,s,a]=await Promise.all([e.env.DB.prepare('SELECT COUNT(*) as count FROM job_seekers WHERE status = "active"').first(),e.env.DB.prepare('SELECT COUNT(*) as count FROM employers WHERE status = "approved"').first(),e.env.DB.prepare('SELECT COUNT(*) as count FROM job_postings WHERE status = "active"').first(),e.env.DB.prepare('SELECT COUNT(*) as count FROM job_applications WHERE application_status = "accepted"').first()]);return e.json({jobSeekers:(t==null?void 0:t.count)||0,employers:(r==null?void 0:r.count)||0,jobPostings:(s==null?void 0:s.count)||0,successfulMatches:(a==null?void 0:a.count)||0})}catch{return e.json({error:"통계 조회 중 오류가 발생했습니다."},500)}});f.post("/api/job-seekers/register",async e=>{try{const t=await e.req.json();if(await e.env.DB.prepare("SELECT id FROM job_seekers WHERE email = ?").bind(t.email).first())return e.json({error:"이미 등록된 이메일입니다."},400);const s=await e.env.DB.prepare(`
      INSERT INTO job_seekers (
        email, password, name, birth_date, gender, nationality, 
        current_visa, desired_visa, phone, current_address, 
        korean_level, education_level, work_experience, status,
        desired_job_category, preferred_region, desired_salary_min, 
        desired_salary_max, self_introduction
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(t.email,t.password,t.name,t.birth_date||null,t.gender||null,t.nationality,t.current_visa||null,t.desired_visa||null,t.phone,t.current_address||null,t.korean_level||null,t.education_level||null,t.work_experience||null,t.status||"active",t.desired_job_category||null,t.preferred_region||null,t.desired_salary_min||null,t.desired_salary_max||null,t.self_introduction||null).run();return e.json({success:!0,jobSeekerId:s.meta.last_row_id,message:"구직정보가 성공적으로 등록되었습니다."})}catch(t){return console.error("구직자 등록 오류:",t),t.message.includes("UNIQUE constraint failed")?e.json({error:"이미 등록된 이메일입니다."},400):e.json({error:"구직정보 등록 중 오류가 발생했습니다."},500)}});f.get("/api/job-seekers",async e=>{try{const{nationality:t,visa:r,korean_level:s,job_category:a,region:n,page:o=1,limit:i=10}=e.req.query();let l=`
      SELECT 
        id, name, nationality, current_visa, desired_visa, korean_level,
        education_level, desired_job_category, preferred_region, 
        desired_salary_min, desired_salary_max, created_at, status
      FROM job_seekers 
      WHERE status = 'active'
    `;const c=[];t&&(l+=" AND nationality = ?",c.push(t)),r&&(l+=" AND (current_visa = ? OR desired_visa = ?)",c.push(r,r)),s&&(l+=" AND korean_level = ?",c.push(s)),a&&(l+=" AND desired_job_category = ?",c.push(a)),n&&(l+=" AND preferred_region = ?",c.push(n)),l+=" ORDER BY created_at DESC LIMIT ? OFFSET ?",c.push(parseInt(i),(parseInt(o)-1)*parseInt(i));const d=await e.env.DB.prepare(l).bind(...c).all();let p='SELECT COUNT(*) as total FROM job_seekers WHERE status = "active"';const m=[];t&&(p+=" AND nationality = ?",m.push(t)),r&&(p+=" AND (current_visa = ? OR desired_visa = ?)",m.push(r,r)),s&&(p+=" AND korean_level = ?",m.push(s)),a&&(p+=" AND desired_job_category = ?",m.push(a)),n&&(p+=" AND preferred_region = ?",m.push(n));const h=await e.env.DB.prepare(p).bind(...m).first();return e.json({jobSeekers:d.results,pagination:{page:parseInt(o),limit:parseInt(i),total:(h==null?void 0:h.total)||0,totalPages:Math.ceil(((h==null?void 0:h.total)||0)/parseInt(i))}})}catch(t){return console.error("구직자 목록 조회 오류:",t),e.json({error:"구직자 목록 조회 중 오류가 발생했습니다."},500)}});f.get("/api/job-seekers/:id",async e=>{try{const t=e.req.param("id"),r=e.req.header("Authorization");if(!r||!r.startsWith("Bearer "))return e.json({error:"로그인이 필요합니다.",message:"구직자의 상세 정보를 보시려면 로그인해주세요.",requireAuth:!0},401);const s=r.substring(7);if(s.startsWith("token_")){const n=s.split("_");if(n.length<3||!n[1]||!n[2])return e.json({error:"유효하지 않은 토큰입니다.",message:"다시 로그인해주세요.",requireAuth:!0},401)}else try{await qe(s,ot)}catch{return e.json({error:"유효하지 않은 토큰입니다.",message:"다시 로그인해주세요.",requireAuth:!0},401)}const a=await e.env.DB.prepare(`
      SELECT * FROM job_seekers WHERE id = ? AND status = 'active'
    `).bind(t).first();return a?(delete a.password,e.json({jobSeeker:a})):e.json({error:"구직자를 찾을 수 없습니다."},404)}catch(t){return console.error("구직자 상세 조회 오류:",t),e.json({error:"구직자 정보 조회 중 오류가 발생했습니다."},500)}});f.get("/api/job-seekers/:id/stats",async e=>{try{const t=e.req.param("id"),r=e.req.header("Authorization");if(!r||!r.startsWith("Bearer "))return e.json({error:"로그인이 필요합니다."},401);let s=0,a=[],n=[];try{const o=await e.env.DB.prepare(`
        SELECT COUNT(*) as count FROM job_applications WHERE job_seeker_id = ?
      `).bind(t).first(),i=(o==null?void 0:o.count)||0;return e.json({viewCount:0,applicationsCount:i,matchesCount:0,averageMatchScore:0})}catch(o){return console.log("데이터베이스 오류, 기본값 사용:",o.message),e.json({viewCount:0,applicationsCount:0,matchesCount:0,averageMatchScore:0})}}catch(t){return console.error("구직자 통계 조회 오류:",t),e.json({viewCount:0,applicationsCount:0,matchesCount:0,averageMatchScore:0})}});f.get("/api/agents/:id/students",async e=>{try{const t=e.req.param("id"),r=await e.env.DB.prepare(`
      SELECT id, email, name, nationality, korean_level, desired_visa, 
             phone, education_level, status, created_at
      FROM job_seekers 
      WHERE agent_id = ? 
      ORDER BY created_at DESC
    `).bind(t).all();return e.json({students:r.results||[]})}catch(t){return console.error("에이전트 유학생 목록 조회 오류:",t),e.json({error:"유학생 목록 조회 중 오류가 발생했습니다."},500)}});f.get("/api/agents/:id/jobseekers",async e=>{try{const t=e.req.param("id"),r=await e.env.DB.prepare(`
      SELECT id, email, name, nationality, korean_level, desired_visa, 
             phone, education_level, status, created_at
      FROM job_seekers 
      WHERE agent_id = ? 
      ORDER BY created_at DESC
    `).bind(t).all();return e.json({jobseekers:r.results||[]})}catch(t){return console.error("에이전트 구직자 목록 조회 오류:",t),e.json({error:"구직자 목록 조회 중 오류가 발생했습니다."},500)}});f.post("/api/agents/:id/register-student",async e=>{try{const t=e.req.param("id"),r=await e.req.json();if(await e.env.DB.prepare("SELECT id FROM job_seekers WHERE email = ?").bind(r.email).first())return e.json({error:"이미 등록된 이메일입니다."},400);const a=At(r.korean_level||""),n=await e.env.DB.prepare(`
      INSERT INTO job_seekers (
        email, password, name, birth_date, gender, nationality, 
        current_visa, desired_visa, phone, current_address, 
        korean_level, education_level, work_experience, agent_id, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
    `).bind(r.email,r.password||"agent_registered",r.name,r.birth_date||null,r.gender||null,r.nationality,r.current_visa||null,r.desired_visa||null,r.phone,r.current_address||null,a,r.education_level||null,r.work_experience||null,t).run();return e.json({success:!0,message:"유학생/구직자가 성공적으로 등록되었습니다.",student:{id:n.meta.last_row_id,email:r.email,name:r.name,agent_id:t}},201)}catch(t){return console.error("에이전트 유학생 등록 오류:",t),e.json({error:"유학생 등록 중 오류가 발생했습니다."},500)}});f.post("/api/matching/generate",async e=>{try{const[t,r]=await Promise.all([e.env.DB.prepare('SELECT * FROM job_seekers WHERE status = "active"').all(),e.env.DB.prepare('SELECT * FROM job_postings WHERE status = "active"').all()]);let s=0;const a=[];for(const n of t.results)for(const o of r.results){const i=Xa(n,o);if(i>=.3){const l=i>=.8?"perfect":i>=.6?"good":"fair",c=Za(n,o),d=e.env.DB.prepare(`
            INSERT OR REPLACE INTO job_matches 
            (job_seeker_id, job_posting_id, match_score, match_type, match_reasons, status)
            VALUES (?, ?, ?, ?, ?, 'pending')
          `).bind(n.id,o.id,i,l,JSON.stringify(c)).run();a.push(d),s++}}return await Promise.all(a),e.json({success:!0,matchesCreated:s,message:`${s}개의 새로운 매칭이 생성되었습니다.`})}catch(t){return console.error("매칭 생성 오류:",t),e.json({error:"매칭 생성 중 오류가 발생했습니다."},500)}});f.get("/api/matching/results",async e=>{try{const{limit:t=10,type:r}=e.req.query();let s=`
      SELECT 
        jm.*,
        js.name as job_seeker_name,
        js.nationality,
        js.korean_level,
        jp.title as job_title,
        e.company_name
      FROM job_matches jm
      LEFT JOIN job_seekers js ON jm.job_seeker_id = js.id
      LEFT JOIN job_postings jp ON jm.job_posting_id = jp.id
      LEFT JOIN employers e ON jp.employer_id = e.id
      WHERE 1=1
    `;const a=[];r&&(s+=" AND jm.match_type = ?",a.push(r)),s+=" ORDER BY jm.match_score DESC, jm.created_at DESC LIMIT ?",a.push(parseInt(t));const n=await e.env.DB.prepare(s).bind(...a).all();return e.json({matches:n.results})}catch(t){return console.error("매칭 결과 조회 오류:",t),e.json({error:"매칭 결과 조회 중 오류가 발생했습니다."},500)}});f.get("/api/matching/stats",async e=>{try{const[t,r,s]=await Promise.all([e.env.DB.prepare('SELECT COUNT(*) as count FROM job_matches WHERE match_type = "perfect"').first(),e.env.DB.prepare('SELECT COUNT(*) as count FROM job_matches WHERE match_type = "good"').first(),e.env.DB.prepare('SELECT COUNT(*) as count FROM job_matches WHERE status = "pending"').first()]);return e.json({perfectMatches:(t==null?void 0:t.count)||0,goodMatches:(r==null?void 0:r.count)||0,pendingMatches:(s==null?void 0:s.count)||0})}catch(t){return console.error("매칭 통계 조회 오류:",t),e.json({error:"매칭 통계 조회 중 오류가 발생했습니다."},500)}});f.get("/api/job-seekers/:id/matches",async e=>{try{const t=e.req.param("id"),r=await e.env.DB.prepare(`
      SELECT 
        jm.*,
        jp.title,
        jp.salary_min,
        jp.salary_max,
        jp.work_location,
        e.company_name
      FROM job_matches jm
      LEFT JOIN job_postings jp ON jm.job_posting_id = jp.id
      LEFT JOIN employers e ON jp.employer_id = e.id
      WHERE jm.job_seeker_id = ?
      ORDER BY jm.match_score DESC
    `).bind(t).all();return e.json({matches:r.results})}catch(t){return console.error("구직자 매칭 조회 오류:",t),e.json({error:"매칭 정보 조회 중 오류가 발생했습니다."},500)}});f.post("/api/messages",async e=>{try{const t=await e.req.json(),r=await e.env.DB.prepare(`
      INSERT INTO messages 
      (sender_type, sender_id, receiver_type, receiver_id, subject, content, message_type, job_posting_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(t.sender_type,t.sender_id,t.receiver_type,t.receiver_id,t.subject||null,t.content,t.message_type||"general",t.job_posting_id||null).run();return await e.env.DB.prepare(`
      INSERT INTO notifications 
      (user_type, user_id, notification_type, title, content, related_id, related_type)
      VALUES (?, ?, 'message', ?, ?, ?, 'message')
    `).bind(t.receiver_type,t.receiver_id,"새 메시지가 도착했습니다",t.subject||"새 메시지",r.meta.last_row_id).run(),e.json({success:!0,messageId:r.meta.last_row_id,message:"메시지가 전송되었습니다."})}catch(t){return console.error("메시지 전송 오류:",t),e.json({error:"메시지 전송 중 오류가 발생했습니다."},500)}});f.get("/api/messages/:userType/:userId",async e=>{try{const t=e.req.param("userType"),r=e.req.param("userId"),s=await e.env.DB.prepare(`
      SELECT * FROM messages 
      WHERE (receiver_type = ? AND receiver_id = ?) OR (sender_type = ? AND sender_id = ?)
      ORDER BY created_at DESC
    `).bind(t,r,t,r).all();return e.json({messages:s.results})}catch(t){return console.error("메시지 조회 오류:",t),e.json({error:"메시지 조회 중 오류가 발생했습니다."},500)}});f.get("/api/notifications/:userType/:userId",async e=>{try{const t=e.req.param("userType"),r=e.req.param("userId"),{unread_only:s}=e.req.query();let a="SELECT * FROM notifications WHERE user_type = ? AND user_id = ?";const n=[t,r];s==="true"&&(a+=" AND is_read = false"),a+=" ORDER BY created_at DESC";const o=await e.env.DB.prepare(a).bind(...n).all();return e.json({notifications:o.results})}catch(t){return console.error("알림 조회 오류:",t),e.json({error:"알림 조회 중 오류가 발생했습니다."},500)}});f.put("/api/notifications/:id/read",async e=>{try{const t=e.req.param("id");return await e.env.DB.prepare("UPDATE notifications SET is_read = true WHERE id = ?").bind(t).run(),e.json({success:!0})}catch(t){return console.error("알림 업데이트 오류:",t),e.json({error:"알림 업데이트 중 오류가 발생했습니다."},500)}});f.post("/api/files/upload",async e=>{try{const t=await e.req.formData(),r=t.get("file"),s=t.get("file_type"),a=t.get("user_id"),n=t.get("user_type");if(!r)return e.json({error:"파일이 선택되지 않았습니다."},400);if(r.size>10*1024*1024)return e.json({error:"파일 크기는 10MB를 초과할 수 없습니다."},400);if(!["application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","image/jpeg","image/png","image/jpg"].includes(r.type))return e.json({error:"지원하지 않는 파일 형식입니다."},400);const i=`${Date.now()}_${r.name}`,l=`/uploads/${n}/${a}/${i}`,c=await e.env.DB.prepare(`
      INSERT INTO uploaded_files 
      (user_type, user_id, file_type, original_filename, stored_filename, file_size, mime_type, file_path)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(n,a,s,r.name,i,r.size,r.type,l).run();return e.json({success:!0,fileId:c.meta.last_row_id,filename:r.name,size:r.size,message:"파일이 성공적으로 업로드되었습니다."})}catch(t){return console.error("파일 업로드 오류:",t),e.json({error:"파일 업로드 중 오류가 발생했습니다."},500)}});f.get("/api/files/:userType/:userId",async e=>{try{const t=e.req.param("userType"),r=e.req.param("userId"),{file_type:s,sort:a="created_at_desc"}=e.req.query();let n="SELECT * FROM uploaded_files WHERE user_type = ? AND user_id = ?";const o=[t,r];switch(s&&s!=="all"&&(n+=" AND file_type = ?",o.push(s)),a){case"date_asc":n+=" ORDER BY created_at ASC";break;case"name_asc":n+=" ORDER BY original_filename ASC";break;case"size_desc":n+=" ORDER BY file_size DESC";break;default:n+=" ORDER BY created_at DESC"}const i=await e.env.DB.prepare(n).bind(...o).all(),l={resume:0,certificate:0,photo:0,document:0,totalSize:0};return i.results.forEach(c=>{l[c.file_type]=(l[c.file_type]||0)+1,l.totalSize+=c.file_size}),e.json({files:i.results,stats:l})}catch(t){return console.error("파일 목록 조회 오류:",t),e.json({error:"파일 목록 조회 중 오류가 발생했습니다."},500)}});f.delete("/api/files/:id",async e=>{try{const t=e.req.param("id");return await e.env.DB.prepare("DELETE FROM uploaded_files WHERE id = ?").bind(t).run(),e.json({success:!0,message:"파일이 삭제되었습니다."})}catch(t){return console.error("파일 삭제 오류:",t),e.json({error:"파일 삭제 중 오류가 발생했습니다."},500)}});f.post("/api/reviews",async e=>{try{const t=await e.req.json(),r=await e.env.DB.prepare(`
      INSERT INTO reviews 
      (reviewer_type, reviewer_id, reviewee_type, reviewee_id, job_posting_id, rating, title, comment)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(t.reviewer_type,t.reviewer_id,t.reviewee_type,t.reviewee_id,t.job_posting_id||null,t.rating,t.title||null,t.comment||null).run();return e.json({success:!0,reviewId:r.meta.last_row_id,message:"평가가 등록되었습니다."})}catch(t){return console.error("평가 등록 오류:",t),e.json({error:"평가 등록 중 오류가 발생했습니다."},500)}});f.get("/api/reviews/:userType/:userId",async e=>{try{const t=e.req.param("userType"),r=e.req.param("userId"),s=await e.env.DB.prepare(`
      SELECT r.*, jp.title as job_title
      FROM reviews r
      LEFT JOIN job_postings jp ON r.job_posting_id = jp.id
      WHERE r.reviewee_type = ? AND r.reviewee_id = ?
      ORDER BY r.created_at DESC
    `).bind(t,r).all(),a=s.results.length>0?s.results.reduce((n,o)=>n+o.rating,0)/s.results.length:0;return e.json({reviews:s.results,averageRating:Math.round(a*10)/10,totalReviews:s.results.length})}catch(t){return console.error("평가 조회 오류:",t),e.json({error:"평가 조회 중 오류가 발생했습니다."},500)}});f.get("/api/visa-types",async e=>{try{const t=await e.env.DB.prepare("SELECT * FROM visa_types ORDER BY visa_code").all();return e.json({visaTypes:t.results})}catch{return e.json({error:"비자 정보 조회 중 오류가 발생했습니다."},500)}});f.get("/api/job-categories",async e=>{try{const t=await e.env.DB.prepare("SELECT * FROM job_categories ORDER BY category_name_ko").all();return e.json({categories:t.results})}catch{return e.json({error:"직종 정보 조회 중 오류가 발생했습니다."},500)}});f.get("/api/regions",async e=>{try{const t=await e.env.DB.prepare("SELECT * FROM regions ORDER BY region_name_ko").all();return e.json({regions:t.results})}catch{return e.json({error:"지역 정보 조회 중 오류가 발생했습니다."},500)}});function Xa(e,t){let r=0,s=0;const a=.3;e.desired_visa===t.required_visa||e.current_visa===t.required_visa?r+=a:e.current_visa&&["E-9","E-7","H-2"].includes(e.current_visa)&&["E-9","E-7","H-2"].includes(t.required_visa)&&(r+=a*.7),s+=a;const n=.25;e.desired_job_category===t.job_category&&(r+=n),s+=n;const o=.2;(e.preferred_region===t.region||e.preferred_region==="ALL")&&(r+=o),s+=o;const i=.15,l={beginner:1,intermediate:2,advanced:3,native:4},c={none:0,basic:1,intermediate:2,advanced:3},d=l[e.korean_level]||0,p=c[t.korean_level_required]||0;d>=p?r+=i:d>=p-1&&(r+=i*.7),s+=i;const m=.1;return e.desired_salary_min&&t.salary_min?e.desired_salary_min<=t.salary_max&&e.desired_salary_max>=t.salary_min?r+=m:Math.abs(e.desired_salary_min-t.salary_min)<=5e5&&(r+=m*.5):r+=m*.5,s+=m,Math.min(r/s,1)}function Za(e,t){const r=[];e.desired_visa===t.required_visa&&r.push("비자 요건이 완벽하게 일치합니다"),e.desired_job_category===t.job_category&&r.push("희망 직종과 일치합니다"),e.preferred_region===t.region&&r.push("희망 근무지역과 일치합니다");const s={beginner:1,intermediate:2,advanced:3,native:4},a={none:0,basic:1,intermediate:2,advanced:3},n=s[e.korean_level]||0,o=a[t.korean_level_required]||0;return n>o?r.push("한국어 수준이 요구사항을 초과합니다"):n===o&&r.push("한국어 수준이 요구사항과 일치합니다"),e.desired_salary_min&&t.salary_min&&e.desired_salary_min<=t.salary_max&&r.push("희망 급여 조건이 맞습니다"),r}f.get("/api/employers/:id/jobs",async e=>{try{const t=e.req.param("id"),{status:r}=e.req.query(),s=e.req.header("Authorization");if(!s||!s.startsWith("Bearer "))return e.json({error:"인증이 필요합니다."},401);let a="SELECT * FROM job_postings WHERE employer_id = ?";const n=[t];r&&r!=="all"&&(a+=" AND status = ?",n.push(r)),a+=" ORDER BY created_at DESC";const o=await e.env.DB.prepare(a).bind(...n).all();return e.json({jobs:o.results})}catch(t){return console.error("구인기업 구인공고 조회 오류:",t),e.json({error:"구인공고 조회 중 오류가 발생했습니다."},500)}});f.get("/api/employers/:id/applications",async e=>{try{const t=e.req.param("id"),{status:r}=e.req.query(),s=e.req.header("Authorization");if(!s||!s.startsWith("Bearer "))return e.json({error:"인증이 필요합니다."},401);let a=`
      SELECT 
        ja.*,
        js.name as job_seeker_name,
        js.nationality,
        js.korean_level,
        js.current_visa,
        jp.title as job_title,
        jp.work_location
      FROM job_applications ja
      LEFT JOIN job_seekers js ON ja.job_seeker_id = js.id
      LEFT JOIN job_postings jp ON ja.job_posting_id = jp.id
      WHERE jp.employer_id = ?
    `;const n=[t];r&&r!=="all"&&(a+=" AND ja.application_status = ?",n.push(r)),a+=" ORDER BY ja.applied_at DESC";const o=await e.env.DB.prepare(a).bind(...n).all();return e.json({applications:o.results})}catch(t){return console.error("구인기업 지원자 조회 오류:",t),e.json({error:"지원자 조회 중 오류가 발생했습니다."},500)}});f.get("/api/employers/:id/matches",async e=>{try{const t=e.req.param("id"),r=e.req.header("Authorization");if(!r||!r.startsWith("Bearer "))return e.json({error:"인증이 필요합니다."},401);const s=await e.env.DB.prepare(`
      SELECT 
        jm.*,
        js.name as job_seeker_name,
        jp.title as job_title
      FROM job_matches jm
      LEFT JOIN job_seekers js ON jm.job_seeker_id = js.id
      LEFT JOIN job_postings jp ON jm.job_posting_id = jp.id
      WHERE jp.employer_id = ?
      ORDER BY jm.match_score DESC, jm.created_at DESC
    `).bind(t).all();return e.json({matches:s.results})}catch(t){return console.error("구인기업 매칭 조회 오류:",t),e.json({error:"매칭 조회 중 오류가 발생했습니다."},500)}});f.get("/api/job-seekers/:id/applications",async e=>{try{const t=e.req.param("id"),{status:r}=e.req.query();let s=`
      SELECT 
        ja.*,
        jp.title as job_title,
        jp.work_location,
        jp.salary_min,
        jp.salary_max,
        e.company_name,
        CASE 
          WHEN jp.salary_min IS NOT NULL AND jp.salary_max IS NOT NULL 
          THEN CAST(jp.salary_min / 10000 AS TEXT) || '만원 ~ ' || CAST(jp.salary_max / 10000 AS TEXT) || '만원'
          ELSE '급여 협의'
        END as salary_text
      FROM job_applications ja
      LEFT JOIN job_postings jp ON ja.job_posting_id = jp.id
      LEFT JOIN employers e ON jp.employer_id = e.id
      WHERE ja.job_seeker_id = ?
    `;const a=[t];r&&r!=="all"&&(s+=" AND ja.application_status = ?",a.push(r)),s+=" ORDER BY ja.applied_at DESC";const n=await e.env.DB.prepare(s).bind(...a).all();return e.json({applications:n.results})}catch(t){return console.error("구직자 지원내역 조회 오류:",t),e.json({error:"지원내역 조회 중 오류가 발생했습니다."},500)}});f.get("/api/jobs/recommended/:jobSeekerId",async e=>{try{const t=e.req.param("jobSeekerId"),{filter:r}=e.req.query(),s=await e.env.DB.prepare("SELECT * FROM job_seekers WHERE id = ?").bind(t).first();if(!s)return e.json({error:"구직자 정보를 찾을 수 없습니다."},404);let a=`
      SELECT 
        jp.*,
        e.company_name,
        CASE 
          WHEN jp.required_visa = ? THEN 0.4
          WHEN jp.job_category = ? THEN 0.3
          WHEN jp.work_location LIKE '%' || ? || '%' THEN 0.2
          WHEN jp.korean_level_required <= ? THEN 0.1
          ELSE 0
        END as match_score
      FROM job_postings jp
      LEFT JOIN employers e ON jp.employer_id = e.id
      WHERE jp.status = 'active'
    `;const n=[s.desired_visa||s.current_visa,s.desired_job_category,s.desired_location||"",s.korean_level||"beginner"];r==="perfect"?a+=" HAVING match_score >= 0.8":r==="good"?a+=" HAVING match_score >= 0.5":r==="recent"&&(a+=' AND jp.created_at >= datetime("now", "-7 days")'),a+=" ORDER BY match_score DESC, jp.created_at DESC LIMIT 20";const o=await e.env.DB.prepare(a).bind(...n).all();return e.json({jobs:o.results})}catch(t){return console.error("추천 구인공고 조회 오류:",t),e.json({error:"추천 구인공고 조회 중 오류가 발생했습니다."},500)}});f.put("/api/jobs/:id",async e=>{try{const t=e.req.header("Authorization");if(!t||!t.startsWith("Bearer "))return e.json({error:"인증이 필요합니다."},401);const r=e.req.param("id"),{title:s,job_category:a,work_location:n,region:o,required_visa:i,salary_min:l,salary_max:c,korean_level_required:d,description:p,positions:m,deadline:h,requirements:v,benefits:g,work_hours:b,experience_required:j}=await e.req.json(),w=o||(n&&n.includes("서울")?"서울":n&&n.includes("경기")?"경기":n&&n.includes("인천")?"인천":n&&n.includes("부산")?"부산":n&&n.includes("대구")?"대구":n&&n.includes("대전")?"대전":n&&n.includes("광주")?"광주":n&&n.includes("울산")?"울산":"전국");return!s||!a||!n?e.json({error:"필수 정보가 누락되었습니다."},400):await e.env.DB.prepare("SELECT employer_id FROM job_postings WHERE id = ?").bind(r).first()?(await e.env.DB.prepare(`
      UPDATE job_postings SET 
        title = ?, job_category = ?, work_location = ?, region = ?, required_visa = ?,
        salary_min = ?, salary_max = ?, korean_level_required = ?, description = ?,
        requirements = ?, benefits = ?, work_hours = ?, experience_required = ?, deadline = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(s,a,n,w,i,l,c,d||"none",p,v||null,g||null,b||null,j||null,h||null,r).run()).success?e.json({success:!0,message:"구인공고가 수정되었습니다."}):e.json({error:"구인공고 수정에 실패했습니다."},500):e.json({error:"구인공고를 찾을 수 없습니다."},404)}catch(t){return console.error("구인공고 수정 오류:",t),e.json({error:"구인공고 수정 중 오류가 발생했습니다."},500)}});f.delete("/api/jobs/:id",async e=>{try{const t=e.req.param("id");return(await e.env.DB.prepare("DELETE FROM job_postings WHERE id = ?").bind(t).run()).success?e.json({success:!0,message:"구인공고가 삭제되었습니다."}):e.json({error:"구인공고 삭제에 실패했습니다."},500)}catch(t){return console.error("구인공고 삭제 오류:",t),e.json({error:"구인공고 삭제 중 오류가 발생했습니다."},500)}});f.put("/api/job-seekers/:id",async e=>{try{const t=e.req.param("id"),r=await e.req.json();console.log("구직자 프로필 수정 요청:",{jobSeekerId:t,seekerData:r});const s=await e.env.DB.prepare(`
      UPDATE job_seekers SET 
        name = ?, email = ?, birth_date = ?, gender = ?, nationality = ?,
        phone = ?, current_visa = ?, desired_visa = ?, korean_level = ?,
        current_address = ?, education_level = ?, desired_job_category = ?,
        work_experience = ?, preferred_region = ?, desired_salary_min = ?,
        self_introduction = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(r.name,r.email,r.birth_date,r.gender,r.nationality,r.phone,r.current_visa,r.desired_visa,r.korean_level,r.current_address,r.education_level,r.desired_job_category,r.work_experience,r.preferred_region,r.desired_salary_min,r.self_introduction,t).run();return console.log("업데이트 결과:",s),s.success?e.json({success:!0,message:"프로필이 수정되었습니다."}):e.json({error:"프로필 수정에 실패했습니다."},500)}catch(t){return console.error("구직자 정보 수정 오류:",t),e.json({error:"프로필 수정 중 오류가 발생했습니다."},500)}});f.post("/api/applications",async e=>{try{const{job_posting_id:t,job_seeker_id:r}=await e.req.json();return await e.env.DB.prepare("SELECT id FROM job_applications WHERE job_posting_id = ? AND job_seeker_id = ?").bind(t,r).first()?e.json({error:"이미 지원한 공고입니다."},400):(await e.env.DB.prepare(`
      INSERT INTO job_applications (job_posting_id, job_seeker_id, application_status, applied_at)
      VALUES (?, ?, 'pending', CURRENT_TIMESTAMP)
    `).bind(t,r).run()).success?e.json({success:!0,message:"지원이 완료되었습니다."},201):e.json({error:"지원 처리에 실패했습니다."},500)}catch(t){return console.error("지원 처리 오류:",t),e.json({error:"지원 처리 중 오류가 발생했습니다."},500)}});f.delete("/api/applications/:id",async e=>{try{const t=e.req.param("id");return(await e.env.DB.prepare("DELETE FROM job_applications WHERE id = ?").bind(t).run()).success?e.json({success:!0,message:"지원이 취소되었습니다."}):e.json({error:"지원 취소에 실패했습니다."},500)}catch(t){return console.error("지원 취소 오류:",t),e.json({error:"지원 취소 중 오류가 발생했습니다."},500)}});f.get("/api/admin/stats",async e=>{try{const t=await e.env.DB.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM employers) + 
        (SELECT COUNT(*) FROM agents) + 
        (SELECT COUNT(*) FROM job_seekers) + 
        (SELECT COUNT(*) FROM admins) as count
    `).first(),r=await e.env.DB.prepare("SELECT COUNT(*) as count FROM employers").first(),s=await e.env.DB.prepare("SELECT COUNT(*) as count FROM job_seekers").first(),a=await e.env.DB.prepare("SELECT COUNT(*) as count FROM agents").first(),n=await e.env.DB.prepare("SELECT COUNT(*) as count FROM job_postings WHERE status = 'active'").first(),o=await e.env.DB.prepare("SELECT COUNT(*) as count FROM job_applications").first(),i=await e.env.DB.prepare("SELECT COUNT(*) as count FROM job_applications WHERE application_status = 'accepted'").first();return e.json({totalUsers:(t==null?void 0:t.count)||0,totalEmployers:(r==null?void 0:r.count)||0,totalJobseekers:(s==null?void 0:s.count)||0,totalAgents:(a==null?void 0:a.count)||0,activeJobs:(n==null?void 0:n.count)||0,totalApplications:(o==null?void 0:o.count)||0,successfulMatches:(i==null?void 0:i.count)||0})}catch(t){return console.error("통계 데이터 조회 오류:",t),e.json({error:"통계 데이터 조회에 실패했습니다."},500)}});f.get("/api/admin/activities",async e=>{try{const t=await e.env.DB.prepare(`
      SELECT 'registration' as type, company_name as description, 'employer' as user_type, created_at 
      FROM employers ORDER BY created_at DESC LIMIT 5
    `).all(),r=await e.env.DB.prepare(`
      SELECT 'registration' as type, name as description, 'jobseeker' as user_type, created_at 
      FROM job_seekers ORDER BY created_at DESC LIMIT 5
    `).all(),s=await e.env.DB.prepare(`
      SELECT 'registration' as type, company_name as description, 'agent' as user_type, created_at 
      FROM agents ORDER BY created_at DESC LIMIT 5
    `).all(),a=[...t.results.map(n=>({...n,description:`${n.description} 기업 가입`})),...r.results.map(n=>({...n,description:`${n.description} 구직자 가입`})),...s.results.map(n=>({...n,description:`${n.description} 에이전트 가입`}))].sort((n,o)=>new Date(o.created_at).getTime()-new Date(n.created_at).getTime()).slice(0,10);return e.json(a)}catch(t){return console.error("활동 데이터 조회 오류:",t),e.json({error:"활동 데이터 조회에 실패했습니다."},500)}});f.get("/api/admin/users",async e=>{try{const t=e.req.query("type")||"employers";let r,s;switch(t){case"employers":s="employers",r="SELECT id, email, company_name, business_number, industry, contact_person, phone, address, region, status, created_at FROM employers ORDER BY created_at DESC";break;case"agents":s="agents",r="SELECT id, email, company_name, contact_person, phone, country, address, license_number, status, created_at FROM agents ORDER BY created_at DESC";break;case"jobseekers":s="job_seekers",r="SELECT id, email, name, nationality, current_visa, desired_visa, korean_level, phone, current_address, education_level, work_experience, status, created_at FROM job_seekers ORDER BY created_at DESC";break;default:return e.json({error:"잘못된 사용자 타입입니다."},400)}const a=await e.env.DB.prepare(r).all();return e.json(a.results||[])}catch(t){return console.error("사용자 데이터 조회 오류:",t),e.json({error:"사용자 데이터 조회에 실패했습니다."},500)}});f.put("/api/admin/users/:id/status",async e=>{var t;try{const r=e.req.param("id"),s=await e.req.json(),{status:a,userType:n}=s;console.log("Status update request:",{userId:r,status:a,userType:n,requestBody:s});let o;switch(n){case"employer":o="employers";break;case"agent":o="agents";break;case"jobseeker":case"jobseekers":o="job_seekers";break;default:return console.error("Invalid userType:",n),e.json({error:`잘못된 사용자 타입입니다: ${n}`},400)}console.log("Using table:",o,"for userType:",n);const i=await e.env.DB.prepare(`SELECT id FROM ${o} WHERE id = ?`).bind(r).first();if(!i)return console.error("User not found:",r,"in table:",o),e.json({error:"사용자를 찾을 수 없습니다."},404);console.log("Found user:",i);const l=await e.env.DB.prepare(`UPDATE ${o} SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`).bind(a,r).run();return console.log("Update result:",l),l.success?e.json({success:!0,message:"사용자 상태가 업데이트되었습니다.",changes:((t=l.meta)==null?void 0:t.changes)||l.changes||0}):(console.error("Update failed:",l),e.json({error:"상태 업데이트에 실패했습니다.",details:l},500))}catch(r){return console.error("사용자 상태 변경 오류:",r),e.json({error:"사용자 상태 변경에 실패했습니다.",details:r.message},500)}});f.post("/api/admin/backup",async e=>{try{const t=["admins","employers","agents","job_seekers","job_postings","job_applications","study_programs"],r={};for(const a of t){const n=await e.env.DB.prepare(`SELECT * FROM ${a}`).all();r[a]=n.results||[]}r.metadata={created_at:new Date().toISOString(),version:"1.0",total_records:Object.values(r).reduce((a,n)=>a+(Array.isArray(n)?n.length:0),0)};const s=JSON.stringify(r,null,2);return new Response(s,{headers:{"Content-Type":"application/json","Content-Disposition":`attachment; filename=wowcampus_backup_${new Date().toISOString().split("T")[0]}.json`}})}catch(t){return console.error("데이터 백업 오류:",t),e.json({error:"데이터 백업에 실패했습니다."},500)}});f.get("/api/admin/report",async e=>{try{const t=await e.env.DB.prepare(`
      SELECT 
        (SELECT COUNT(*) FROM employers) as employers_count,
        (SELECT COUNT(*) FROM agents) as agents_count,
        (SELECT COUNT(*) FROM job_seekers) as jobseekers_count,
        (SELECT COUNT(*) FROM job_postings WHERE status = 'active') as active_jobs_count,
        (SELECT COUNT(*) FROM job_applications) as applications_count
    `).first(),r=`
WOW-CAMPUS 시스템 리포트
생성일: ${new Date().toLocaleDateString("ko-KR")}

=== 사용자 현황 ===
구인기업: ${(t==null?void 0:t.employers_count)||0}개
에이전트: ${(t==null?void 0:t.agents_count)||0}개
구직자: ${(t==null?void 0:t.jobseekers_count)||0}명

=== 채용 현황 ===
활성 채용공고: ${(t==null?void 0:t.active_jobs_count)||0}개
총 지원서: ${(t==null?void 0:t.applications_count)||0}건

=== 시스템 상태 ===
상태: 정상 운영중
마지막 업데이트: ${new Date().toISOString()}

이 리포트는 WOW-CAMPUS 관리자 시스템에서 자동 생성되었습니다.
    `.trim();return new Response(r,{headers:{"Content-Type":"text/plain; charset=utf-8","Content-Disposition":`attachment; filename=system_report_${new Date().toISOString().split("T")[0]}.txt`}})}catch(t){return console.error("리포트 생성 오류:",t),e.json({error:"리포트 생성에 실패했습니다."},500)}});f.get("/api/agents/active",async e=>{try{const t=await e.env.DB.prepare(`
      SELECT id, company_name, contact_person, phone, country, email
      FROM agents 
      WHERE status = 'approved' 
      ORDER BY company_name ASC
    `).all();return e.json(t.results||[])}catch(t){return console.error("에이전트 목록 조회 오류:",t),e.json({error:"에이전트 목록 조회에 실패했습니다."},500)}});f.get("/api/agents/:id",async e=>{try{const t=e.req.param("id"),r=await e.env.DB.prepare(`
      SELECT id, company_name, contact_person, phone, country, email
      FROM agents 
      WHERE id = ? AND status = 'approved'
    `).bind(t).first();return r?e.json(r):e.json({error:"에이전트를 찾을 수 없습니다."},404)}catch(t){return console.error("에이전트 조회 오류:",t),e.json({error:"에이전트 조회에 실패했습니다."},500)}});f.put("/api/job-seekers/:id/agent",async e=>{try{const t=e.req.param("id"),{agent_id:r}=await e.req.json();return r&&!await e.env.DB.prepare(`
        SELECT id FROM agents WHERE id = ? AND status = 'approved'
      `).bind(r).first()?e.json({error:"유효하지 않은 에이전트입니다."},400):(await e.env.DB.prepare(`
      UPDATE job_seekers 
      SET agent_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(r,t).run()).success?e.json({success:!0,message:"에이전트 정보가 업데이트되었습니다."}):e.json({error:"업데이트에 실패했습니다."},500)}catch(t){return console.error("에이전트 업데이트 오류:",t),e.json({error:"에이전트 업데이트 중 오류가 발생했습니다."},500)}});f.post("/api/jobs",async e=>{try{const t=e.req.header("Authorization");if(!t||!t.startsWith("Bearer "))return e.json({error:"인증이 필요합니다."},401);const{title:r,job_category:s,work_location:a,region:n,required_visa:o,salary_min:i,salary_max:l,korean_level_required:c,description:d,employer_id:p,agent_id:m,agent_fee_percentage:h,agent_notes:v,positions:g,deadline:b,requirements:j,benefits:w,work_hours:T,experience_required:E}=await e.req.json(),D=n||(a&&a.includes("서울")?"서울":a&&a.includes("경기")?"경기":a&&a.includes("인천")?"인천":a&&a.includes("부산")?"부산":a&&a.includes("대구")?"대구":a&&a.includes("대전")?"대전":a&&a.includes("광주")?"광주":a&&a.includes("울산")?"울산":"전국");if(!r||!s||!a||!p)return e.json({error:"필수 정보가 누락되었습니다."},400);const M=await e.env.DB.prepare(`
      INSERT INTO job_postings (
        employer_id, title, job_category, work_location, region, required_visa,
        salary_min, salary_max, korean_level_required, description, 
        requirements, benefits, work_hours, experience_required, deadline,
        agent_id, agent_fee_percentage, agent_notes, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', CURRENT_TIMESTAMP)
    `).bind(p,r,s,a,D,o,i,l,c,d,j||null,w||null,T||null,E||null,b||null,m||null,h||0,v||null).run();return M.success?e.json({success:!0,message:"구인정보가 성공적으로 등록되었습니다.",job_id:M.meta.last_row_id},201):e.json({error:"구인정보 등록에 실패했습니다."},500)}catch(t){return console.error("구인정보 등록 오류:",t),e.json({error:"구인정보 등록 중 오류가 발생했습니다."},500)}});f.post("/api/upload/document",async e=>{try{const t=await e.req.formData(),r=t.get("file"),s=t.get("job_seeker_id"),a=t.get("document_type"),n=t.get("description");if(!r||!s||!a)return e.json({error:"필수 파라미터가 누락되었습니다."},400);const o=`${Date.now()}_${r.name.replace(/[^a-zA-Z0-9.-]/g,"_")}`,i=await e.env.DB.prepare(`
      INSERT INTO job_seeker_documents (
        job_seeker_id, document_type, original_filename, stored_filename,
        file_size, file_type, description, upload_date
      ) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    `).bind(s,a,r.name,o,r.size,r.type,n).run();return i.success?e.json({success:!0,message:"파일이 성공적으로 업로드되었습니다.",document_id:i.meta.last_row_id,filename:o},201):e.json({error:"파일 업로드에 실패했습니다."},500)}catch(t){return console.error("파일 업로드 오류:",t),e.json({error:"파일 업로드 중 오류가 발생했습니다."},500)}});f.get("/api/jobseeker/:id/documents",async e=>{try{const t=e.req.param("id"),r=await e.env.DB.prepare(`
      SELECT id, document_type, original_filename, file_size, file_type, 
             description, upload_date, is_public
      FROM job_seeker_documents 
      WHERE job_seeker_id = ? 
      ORDER BY upload_date DESC
    `).bind(t).all();return e.json(r.results||[])}catch(t){return console.error("서류 목록 조회 오류:",t),e.json({error:"서류 목록 조회에 실패했습니다."},500)}});f.get("/api/documents/:id/download",async e=>{try{const t=e.req.param("id"),r=e.req.header("X-User-Info");if(!r)return e.json({error:"인증이 필요합니다."},401);const s=JSON.parse(r),a=await e.env.DB.prepare(`
      SELECT jsd.*, js.name as job_seeker_name, js.email as job_seeker_email
      FROM job_seeker_documents jsd
      JOIN job_seekers js ON jsd.job_seeker_id = js.id
      WHERE jsd.id = ?
    `).bind(t).first();return a?s.type==="jobseeker"&&s.id!==a.job_seeker_id?e.json({error:"접근 권한이 없습니다."},403):(s.type==="employer"&&await e.env.DB.prepare(`
        INSERT INTO document_download_logs (document_id, employer_id, downloaded_at, ip_address)
        VALUES (?, ?, CURRENT_TIMESTAMP, ?)
      `).bind(t,s.id,e.req.header("CF-Connecting-IP")||"").run(),e.json({success:!0,download_url:`/files/${a.stored_filename}`,original_filename:a.original_filename,file_type:a.file_type,file_size:a.file_size})):e.json({error:"서류를 찾을 수 없습니다."},404)}catch(t){return console.error("서류 다운로드 오류:",t),e.json({error:"서류 다운로드에 실패했습니다."},500)}});f.post("/api/applications/:id/attach-documents",async e=>{try{const t=e.req.param("id"),{document_ids:r}=await e.req.json();if(!Array.isArray(r))return e.json({error:"서류 ID 목록이 필요합니다."},400);await e.env.DB.prepare("DELETE FROM application_documents WHERE application_id = ?").bind(t).run();for(const s of r)await e.env.DB.prepare(`
        INSERT OR IGNORE INTO application_documents (application_id, document_id, attached_at)
        VALUES (?, ?, CURRENT_TIMESTAMP)
      `).bind(t,s).run();return e.json({success:!0,message:"서류가 성공적으로 첨부되었습니다."})}catch(t){return console.error("서류 첨부 오류:",t),e.json({error:"서류 첨부에 실패했습니다."},500)}});f.get("/api/employers/:id/applications/documents",async e=>{try{const t=e.req.param("id"),r=await e.env.DB.prepare(`
      SELECT 
        ja.id as application_id,
        ja.job_posting_id,
        ja.application_status,
        ja.applied_at,
        js.id as job_seeker_id,
        js.name as job_seeker_name,
        js.email as job_seeker_email,
        js.nationality,
        js.current_visa,
        jp.title as job_title,
        jsd.id as document_id,
        jsd.document_type,
        jsd.original_filename,
        jsd.file_size,
        jsd.file_type,
        jsd.description as document_description,
        jsd.upload_date
      FROM job_applications ja
      JOIN job_postings jp ON ja.job_posting_id = jp.id
      JOIN job_seekers js ON ja.job_seeker_id = js.id
      LEFT JOIN application_documents ad ON ja.id = ad.application_id
      LEFT JOIN job_seeker_documents jsd ON ad.document_id = jsd.id
      WHERE jp.employer_id = ?
      ORDER BY ja.applied_at DESC, jsd.upload_date ASC
    `).bind(t).all();return e.json(r.results||[])}catch(t){return console.error("지원자 서류 조회 오류:",t),e.json({error:"지원자 서류 조회에 실패했습니다."},500)}});f.get("/api/applications/:id/documents",async e=>{try{const t=e.req.param("id"),r=await e.env.DB.prepare(`
      SELECT 
        jsd.id as document_id,
        jsd.document_type,
        jsd.original_filename,
        jsd.file_size,
        jsd.file_type,
        jsd.description,
        jsd.upload_date
      FROM application_documents ad
      JOIN job_seeker_documents jsd ON ad.document_id = jsd.id
      WHERE ad.application_id = ?
      ORDER BY jsd.upload_date DESC
    `).bind(t).all();return e.json({documents:r.results||[]})}catch(t){return console.error("지원서 서류 조회 오류:",t),e.json({error:"지원서 서류 조회에 실패했습니다."},500)}});f.delete("/api/documents/:id",async e=>{try{const t=e.req.param("id");return e.req.header("Authorization")?await e.env.DB.prepare(`
      SELECT job_seeker_id FROM job_seeker_documents WHERE id = ?
    `).bind(t).first()?(await e.env.DB.prepare(`
      DELETE FROM job_seeker_documents WHERE id = ?
    `).bind(t).run()).success?e.json({success:!0,message:"서류가 삭제되었습니다."}):e.json({error:"서류 삭제에 실패했습니다."},500):e.json({error:"서류를 찾을 수 없습니다."},404):e.json({error:"인증이 필요합니다."},401)}catch(t){return console.error("서류 삭제 오류:",t),e.json({error:"서류 삭제 중 오류가 발생했습니다."},500)}});f.get("/api/admin/stats",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=await e.env.DB.prepare("SELECT COUNT(*) as count FROM (SELECT id FROM employers UNION SELECT id FROM agents UNION SELECT id FROM job_seekers)").first(),s=await e.env.DB.prepare("SELECT COUNT(*) as count FROM employers").first(),a=await e.env.DB.prepare("SELECT COUNT(*) as count FROM job_seekers").first(),n=await e.env.DB.prepare("SELECT COUNT(*) as count FROM agents").first();let o={count:0},i={count:0},l={count:0};try{o=await e.env.DB.prepare('SELECT COUNT(*) as count FROM job_postings WHERE status = "active"').first()||{count:0},i=await e.env.DB.prepare("SELECT COUNT(*) as count FROM applications").first()||{count:0},l=await e.env.DB.prepare('SELECT COUNT(*) as count FROM applications WHERE status = "accepted"').first()||{count:0}}catch{console.log("Some tables not found, using default values")}return e.json({totalUsers:(r==null?void 0:r.count)||0,totalEmployers:(s==null?void 0:s.count)||0,totalJobseekers:(a==null?void 0:a.count)||0,totalAgents:(n==null?void 0:n.count)||0,activeJobs:(o==null?void 0:o.count)||0,totalApplications:(i==null?void 0:i.count)||0,successfulMatches:(l==null?void 0:l.count)||0})}catch(t){return console.error("Stats fetch error:",t),e.json({error:"통계 데이터 조회 중 오류가 발생했습니다."},500)}});f.get("/api/admin/activities",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=[{id:1,type:"registration",description:"새 구직자 회원이 가입했습니다.",user_type:"구직자",created_at:new Date().toISOString()},{id:2,type:"job_post",description:"새 채용공고가 등록되었습니다.",user_type:"구인기업",created_at:new Date(Date.now()-36e5).toISOString()}];return e.json(r)}catch(t){return console.error("Activities fetch error:",t),e.json({error:"활동 데이터 조회 중 오류가 발생했습니다."},500)}});f.get("/api/admin/users",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const{type:r="employers"}=e.req.query();let s;switch(r){case"employers":s="employers";break;case"agents":s="agents";break;case"jobseekers":s="job_seekers";break;default:s="employers"}const a=await e.env.DB.prepare(`
      SELECT * FROM ${s} ORDER BY created_at DESC LIMIT 50
    `).all();return e.json(a.results||[])}catch(t){return console.error("Users fetch error:",t),e.json({error:"사용자 목록 조회 중 오류가 발생했습니다."},500)}});f.put("/api/admin/users/:id/status",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id"),{status:s,userType:a}=await e.req.json();let n;switch(a){case"employer":n="employers";break;case"agent":n="agents";break;case"jobseeker":n="job_seekers";break;default:return e.json({error:"잘못된 사용자 유형입니다."},400)}return await e.env.DB.prepare(`
      UPDATE ${n} SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
    `).bind(s,r).run(),e.json({success:!0,message:"사용자 상태가 업데이트되었습니다."})}catch(t){return console.error("User status update error:",t),e.json({error:"사용자 상태 업데이트 중 오류가 발생했습니다."},500)}});f.get("/api/admin/users/:userType",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("userType");let s="";switch(r){case"employers":s="employers";break;case"agents":s="agents";break;case"jobseekers":s="job_seekers";break;default:return e.json({error:"유효하지 않은 사용자 타입입니다."},400)}const a=await e.env.DB.prepare(`
      SELECT * FROM ${s} ORDER BY created_at DESC
    `).all();return e.json({users:a.results})}catch(t){return console.error("사용자 목록 조회 오류:",t),e.json({error:"사용자 목록 조회 중 오류가 발생했습니다."},500)}});f.get("/api/admin/stats",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=await e.env.DB.prepare("SELECT COUNT(*) as count FROM employers").first(),s=await e.env.DB.prepare("SELECT COUNT(*) as count FROM agents").first(),a=await e.env.DB.prepare("SELECT COUNT(*) as count FROM job_seekers").first();return e.json({totalEmployers:(r==null?void 0:r.count)||0,totalAgents:(s==null?void 0:s.count)||0,totalJobseekers:(a==null?void 0:a.count)||0,totalUsers:((r==null?void 0:r.count)||0)+((s==null?void 0:s.count)||0)+((a==null?void 0:a.count)||0)})}catch(t){return console.error("통계 정보 조회 오류:",t),e.json({error:"통계 정보 조회 중 오류가 발생했습니다."},500)}});f.post("/api/admin/users/:id/temp-password",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id"),{userType:s}=await e.req.json(),a=Math.random().toString(36).substring(2,8).toUpperCase();let n;switch(s){case"employer":n="employers";break;case"agent":n="agents";break;case"jobseeker":n="job_seekers";break;default:return e.json({error:"잘못된 사용자 유형입니다."},400)}const o=await We(a);return await e.env.DB.prepare(`
      UPDATE ${n} 
      SET password = ?, temp_password = 1, updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).bind(o,r).run(),e.json({success:!0,tempPassword:a,message:"임시 패스워드가 발급되었습니다."})}catch(t){return console.error("Temp password generation error:",t),e.json({error:"임시 패스워드 발급 중 오류가 발생했습니다."},500)}});f.put("/api/admin/users/bulk-status",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const{userIds:r,status:s,userType:a}=await e.req.json();let n;switch(a){case"employer":n="employers";break;case"agent":n="agents";break;case"jobseeker":n="job_seekers";break;default:return e.json({error:"잘못된 사용자 유형입니다."},400)}const o=r.map(()=>"?").join(",");return await e.env.DB.prepare(`
      UPDATE ${n} 
      SET status = ?, updated_at = CURRENT_TIMESTAMP 
      WHERE id IN (${o})
    `).bind(s,...r).run(),e.json({success:!0,message:`${r.length}명의 사용자 상태가 업데이트되었습니다.`})}catch(t){return console.error("Bulk status update error:",t),e.json({error:"일괄 상태 업데이트 중 오류가 발생했습니다."},500)}});f.post("/api/admin/backup",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r={timestamp:new Date().toISOString(),notice:"이 기능은 실제 환경에서 구현되어야 합니다.",data:{employers:[],agents:[],job_seekers:[]}};return new Response(JSON.stringify(r,null,2),{headers:{"Content-Type":"application/json","Content-Disposition":`attachment; filename="wowcampus_backup_${new Date().toISOString().split("T")[0]}.json"`}})}catch(t){return console.error("Backup error:",t),e.json({error:"백업 생성 중 오류가 발생했습니다."},500)}});f.get("/api/admin/report",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=`WOW-CAMPUS 시스템 리포트
생성일: ${new Date().toLocaleDateString("ko-KR")}

이 기능은 실제 환경에서 PDF 생성 라이브러리와 함께 구현되어야 합니다.
`;return new Response(r,{headers:{"Content-Type":"text/plain","Content-Disposition":`attachment; filename="system_report_${new Date().toISOString().split("T")[0]}.txt"`}})}catch(t){return console.error("Report error:",t),e.json({error:"리포트 생성 중 오류가 발생했습니다."},500)}});f.get("/api/admin/notices",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=await e.env.DB.prepare(`
      SELECT id, title, content, is_active, created_at, updated_at
      FROM notices 
      ORDER BY created_at DESC
    `).all();return e.json(r.results)}catch(t){return console.error("Fetch notices error:",t),e.json({error:"공지사항 조회 중 오류가 발생했습니다."},500)}});f.get("/api/admin/notices/:id",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id"),s=await e.env.DB.prepare(`
      SELECT * FROM notices WHERE id = ?
    `).bind(r).first();return s?e.json(s):e.json({error:"공지사항을 찾을 수 없습니다."},404)}catch(t){return console.error("Fetch notice error:",t),e.json({error:"공지사항 조회 중 오류가 발생했습니다."},500)}});f.post("/api/admin/notices",R,async e=>{try{const t=e.get("user");if(t.userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const{title:r,content:s,is_active:a}=await e.req.json();if(!r||!s)return e.json({error:"제목과 내용은 필수입니다."},400);const n=await e.env.DB.prepare(`
      INSERT INTO notices (title, content, is_active, created_by)
      VALUES (?, ?, ?, ?)
    `).bind(r,s,a?1:0,t.id).run();return e.json({success:!0,id:n.meta.last_row_id,message:"공지사항이 등록되었습니다."})}catch(t){return console.error("Create notice error:",t),e.json({error:"공지사항 등록 중 오류가 발생했습니다."},500)}});f.put("/api/admin/notices/:id",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id"),{title:s,content:a,is_active:n}=await e.req.json();return!s||!a?e.json({error:"제목과 내용은 필수입니다."},400):(await e.env.DB.prepare(`
      UPDATE notices 
      SET title = ?, content = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(s,a,n?1:0,r).run(),e.json({success:!0,message:"공지사항이 수정되었습니다."}))}catch(t){return console.error("Update notice error:",t),e.json({error:"공지사항 수정 중 오류가 발생했습니다."},500)}});f.delete("/api/admin/notices/:id",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id");return await e.env.DB.prepare(`
      DELETE FROM notices WHERE id = ?
    `).bind(r).run(),e.json({success:!0,message:"공지사항이 삭제되었습니다."})}catch(t){return console.error("Delete notice error:",t),e.json({error:"공지사항 삭제 중 오류가 발생했습니다."},500)}});f.get("/api/admin/faqs",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=await e.env.DB.prepare(`
      SELECT id, category, question, answer, is_active, order_index, created_at, updated_at
      FROM faqs 
      ORDER BY category, order_index, created_at DESC
    `).all();return e.json(r.results)}catch(t){return console.error("Fetch FAQs error:",t),e.json({error:"FAQ 조회 중 오류가 발생했습니다."},500)}});f.get("/api/admin/faqs/:id",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id"),s=await e.env.DB.prepare(`
      SELECT * FROM faqs WHERE id = ?
    `).bind(r).first();return s?e.json(s):e.json({error:"FAQ를 찾을 수 없습니다."},404)}catch(t){return console.error("Fetch FAQ error:",t),e.json({error:"FAQ 조회 중 오류가 발생했습니다."},500)}});f.post("/api/admin/faqs",R,async e=>{try{const t=e.get("user");if(t.userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const{category:r,question:s,answer:a,is_active:n,order_index:o=0}=await e.req.json();if(!r||!s||!a)return e.json({error:"카테고리, 질문, 답변은 필수입니다."},400);const i=await e.env.DB.prepare(`
      INSERT INTO faqs (category, question, answer, is_active, order_index, created_by)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(r,s,a,n?1:0,o,t.id).run();return e.json({success:!0,id:i.meta.last_row_id,message:"FAQ가 등록되었습니다."})}catch(t){return console.error("Create FAQ error:",t),e.json({error:"FAQ 등록 중 오류가 발생했습니다."},500)}});f.put("/api/admin/faqs/:id",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id"),{category:s,question:a,answer:n,is_active:o,order_index:i=0}=await e.req.json();return!s||!a||!n?e.json({error:"카테고리, 질문, 답변은 필수입니다."},400):(await e.env.DB.prepare(`
      UPDATE faqs 
      SET category = ?, question = ?, answer = ?, is_active = ?, order_index = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(s,a,n,o?1:0,i,r).run(),e.json({success:!0,message:"FAQ가 수정되었습니다."}))}catch(t){return console.error("Update FAQ error:",t),e.json({error:"FAQ 수정 중 오류가 발생했습니다."},500)}});f.delete("/api/admin/faqs/:id",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id");return await e.env.DB.prepare(`
      DELETE FROM faqs WHERE id = ?
    `).bind(r).run(),e.json({success:!0,message:"FAQ가 삭제되었습니다."})}catch(t){return console.error("Delete FAQ error:",t),e.json({error:"FAQ 삭제 중 오류가 발생했습니다."},500)}});f.get("/api/admin/inquiries",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=await e.env.DB.prepare(`
      SELECT id, name, email, phone, category, subject, message, status, created_at, updated_at
      FROM inquiries 
      ORDER BY created_at DESC
    `).all();return e.json(r.results)}catch(t){return console.error("Fetch inquiries error:",t),e.json({error:"문의 조회 중 오류가 발생했습니다."},500)}});f.get("/api/admin/inquiries/:id",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id"),s=await e.env.DB.prepare(`
      SELECT * FROM inquiries WHERE id = ?
    `).bind(r).first();return s?e.json(s):e.json({error:"문의를 찾을 수 없습니다."},404)}catch(t){return console.error("Fetch inquiry error:",t),e.json({error:"문의 조회 중 오류가 발생했습니다."},500)}});f.delete("/api/admin/inquiries/:id",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id");return await e.env.DB.prepare(`
      DELETE FROM inquiries WHERE id = ?
    `).bind(r).run(),e.json({success:!0,message:"문의가 삭제되었습니다."})}catch(t){return console.error("Delete inquiry error:",t),e.json({error:"문의 삭제 중 오류가 발생했습니다."},500)}});f.put("/api/admin/inquiries/:id/reply",R,async e=>{try{const t=e.get("user");if(t.userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("id"),{reply:s}=await e.req.json();return s?(await e.env.DB.prepare(`
      UPDATE inquiries 
      SET reply = ?, status = 'completed', replied_at = CURRENT_TIMESTAMP, replied_by = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(s,t.id,r).run(),e.json({success:!0,message:"문의 답변이 등록되었습니다."})):e.json({error:"답변 내용은 필수입니다."},400)}catch(t){return console.error("Reply inquiry error:",t),e.json({error:"문의 답변 중 오류가 발생했습니다."},500)}});f.get("/api/admin/policies/:type",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("type"),s=await e.env.DB.prepare(`
      SELECT * FROM policies WHERE type = ?
    `).bind(r).first();return s?e.json(s):e.json({content:"",last_updated:new Date().toISOString().split("T")[0]})}catch(t){return console.error("Fetch policy error:",t),e.json({error:"정책 조회 중 오류가 발생했습니다."},500)}});f.put("/api/admin/policies/:type",R,async e=>{try{const t=e.get("user");if(t.userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=e.req.param("type"),{content:s,last_updated:a}=await e.req.json();if(!s)return e.json({error:"내용은 필수입니다."},400);const n=a||new Date().toISOString().split("T")[0];return await e.env.DB.prepare(`
      SELECT id FROM policies WHERE type = ?
    `).bind(r).first()?await e.env.DB.prepare(`
        UPDATE policies 
        SET content = ?, last_updated = ?, updated_at = CURRENT_TIMESTAMP, updated_by = ?
        WHERE type = ?
      `).bind(s,n,t.id,r).run():await e.env.DB.prepare(`
        INSERT INTO policies (type, content, last_updated, updated_by)
        VALUES (?, ?, ?, ?)
      `).bind(r,s,n,t.id).run(),e.json({success:!0,message:"정책이 저장되었습니다."})}catch(t){return console.error("Save policy error:",t),e.json({error:"정책 저장 중 오류가 발생했습니다."},500)}});f.get("/api/admin/contact",R,async e=>{try{if(e.get("user").userType!=="admin")return e.json({error:"관리자 권한이 필요합니다."},403);const r=await e.env.DB.prepare(`
      SELECT * FROM contact_info ORDER BY created_at DESC LIMIT 1
    `).first();return r?e.json(r):e.json({phone1:"02-3144-3137",phone2:"054-464-3137",email:"wow3d16@naver.com",address1:"서울특별시 강남구 테헤란로 123",address2:"경상북도 포항시 남구 지곡로 80",hours:"평일 09:00 - 18:00"})}catch(t){return console.error("Fetch contact error:",t),e.json({error:"연락처 정보 조회 중 오류가 발생했습니다."},500)}});f.put("/api/admin/contact",R,async e=>{try{const t=e.get("user");if(t.userType!=="admin")return e.json({error:"관리자 권한이 필요습니다."},403);const{phone1:r,phone2:s,email:a,address1:n,address2:o,hours:i}=await e.req.json();if(!r||!a||!n||!i)return e.json({error:"필수 정보가 누락되었습니다."},400);const l=await e.env.DB.prepare(`
      SELECT id FROM contact_info LIMIT 1
    `).first();return l?await e.env.DB.prepare(`
        UPDATE contact_info 
        SET phone1 = ?, phone2 = ?, email = ?, address1 = ?, address2 = ?, hours = ?, 
            updated_at = CURRENT_TIMESTAMP, updated_by = ?
        WHERE id = ?
      `).bind(r,s,a,n,o,i,t.id,l.id).run():await e.env.DB.prepare(`
        INSERT INTO contact_info (phone1, phone2, email, address1, address2, hours, updated_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(r,s,a,n,o,i,t.id).run(),e.json({success:!0,message:"연락처 정보가 저장되었습니다."})}catch(t){return console.error("Save contact error:",t),e.json({error:"연락처 정보 저장 중 오류가 발생했습니다."},500)}});f.get("/api/contact",async e=>{try{const t=await e.env.DB.prepare(`
      SELECT phone1, phone2, email, address1, address2, hours
      FROM contact_info 
      ORDER BY created_at DESC 
      LIMIT 1
    `).first();return t?e.json(t):e.json({phone1:"02-1234-5678",phone2:"054-987-6543",email:"info@wowcampus.com",address1:"서울특별시 강남구 테헤란로 456",address2:"경상북도 포항시 남구 지곡로 123",hours:"평일 09:00 - 18:00"})}catch(t){return console.error("Fetch contact error:",t),e.json({error:"연락처 정보 조회 중 오류가 발생했습니다."},500)}});f.post("/api/inquiries",async e=>{try{const{name:t,email:r,phone:s,category:a,subject:n,message:o}=await e.req.json();if(!t||!r||!a||!n||!o)return e.json({error:"필수 정보가 누락되었습니다."},400);const i=await e.env.DB.prepare(`
      INSERT INTO inquiries (name, email, phone, category, subject, message, status)
      VALUES (?, ?, ?, ?, ?, ?, 'pending')
    `).bind(t,r,s,a,n,o).run();return e.json({success:!0,id:i.meta.last_row_id,message:"문의가 접수되었습니다."})}catch(t){return console.error("Create inquiry error:",t),e.json({error:"문의 접수 중 오류가 발생했습니다."},500)}});f.get("/api/notices",async e=>{try{const{page:t=1,limit:r=10}=e.req.query(),s=await e.env.DB.prepare(`
      SELECT id, title, content, created_at
      FROM notices 
      WHERE is_active = 1
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `).bind(parseInt(r),(parseInt(t)-1)*parseInt(r)).all();return e.json({notices:s.results,page:parseInt(t),limit:parseInt(r)})}catch(t){return console.error("Fetch public notices error:",t),e.json({error:"공지사항 조회 중 오류가 발생했습니다."},500)}});f.get("/api/faqs",async e=>{try{const{category:t}=e.req.query();let r=`
      SELECT id, category, question, answer, order_index
      FROM faqs 
      WHERE is_active = 1
    `;const s=[];t&&(r+=" AND category = ?",s.push(t)),r+=" ORDER BY category, order_index, created_at";const a=await e.env.DB.prepare(r).bind(...s).all();return e.json(a.results)}catch(t){return console.error("Fetch public FAQs error:",t),e.json({error:"FAQ 조회 중 오류가 발생했습니다."},500)}});f.get("/api/job-seekers/:id/profile",async e=>{try{const t=e.req.param("id");if(!e.req.header("authorization"))return e.json({error:"인증이 필요합니다."},401);const s=await e.env.DB.prepare(`
      SELECT 
        js.id, js.email, js.name, js.nationality, js.gender, 
        js.birth_date, js.phone, js.current_address,
        js.current_visa, js.desired_visa, js.visa_expiry,
        js.korean_level, js.english_level, js.other_languages,
        js.education_level, js.major, js.university, js.graduation_year,
        js.work_experience, js.skills, js.certifications,
        js.desired_job_type, js.desired_location, js.desired_salary,
        js.introduction, js.status, js.created_at,
        a.company_name as agent_company_name, a.contact_person as agent_contact
      FROM job_seekers js
      LEFT JOIN agents a ON js.agent_id = a.id
      WHERE js.id = ?
    `).bind(t).first();if(!s)return e.json({error:"구직자를 찾을 수 없습니다."},404);const a=await e.env.DB.prepare(`
      SELECT 
        ja.id, ja.application_status, ja.applied_at, ja.cover_letter, ja.notes,
        jp.title as job_title, jp.company_name, jp.work_location
      FROM job_applications ja
      JOIN job_postings jp ON ja.job_posting_id = jp.id
      WHERE ja.job_seeker_id = ?
      ORDER BY ja.applied_at DESC
    `).bind(t).all(),n=await e.env.DB.prepare(`
      SELECT document_id, document_type, original_filename, file_size, uploaded_at
      FROM job_seeker_documents 
      WHERE job_seeker_id = ?
      ORDER BY uploaded_at DESC
    `).bind(t).all();return e.json({jobSeeker:s,applications:a.results||[],documents:n.results||[]})}catch(t){return console.error("구직자 프로필 조회 오류:",t),e.json({error:"구직자 정보를 조회할 수 없습니다."},500)}});f.put("/api/applications/:id/status",async e=>{try{const t=e.req.param("id"),{status:r,notes:s}=await e.req.json();if(!e.req.header("authorization"))return e.json({error:"인증이 필요합니다."},401);if(!["pending","submitted","interview","accepted","rejected"].includes(r))return e.json({error:"유효하지 않은 상태입니다."},400);const o=await e.env.DB.prepare(`
      SELECT ja.id, ja.job_seeker_id, jp.employer_id, js.name as job_seeker_name, jp.title as job_title
      FROM job_applications ja
      JOIN job_postings jp ON ja.job_posting_id = jp.id
      JOIN job_seekers js ON ja.job_seeker_id = js.id
      WHERE ja.id = ?
    `).bind(t).first();return o?(await e.env.DB.prepare(`
      UPDATE job_applications 
      SET application_status = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(r,s||null,t).run()).success?(console.log(`지원 상태 변경: ${o.job_seeker_name} -> ${o.job_title} (${r})`),e.json({success:!0,message:"지원 상태가 업데이트되었습니다.",application:{id:t,status:r,job_seeker_name:o.job_seeker_name,job_title:o.job_title}})):e.json({error:"지원 상태 업데이트에 실패했습니다."},500):e.json({error:"지원서를 찾을 수 없습니다."},404)}catch(t){return console.error("지원 상태 변경 오류:",t),e.json({error:"지원 상태 변경에 실패했습니다."},500)}});f.put("/api/applications/batch-update",async e=>{try{const{applicationIds:t,status:r,notes:s}=await e.req.json();if(!e.req.header("authorization"))return e.json({error:"인증이 필요합니다."},401);if(!Array.isArray(t)||t.length===0)return e.json({error:"지원서 ID 목록이 필요합니다."},400);if(!["pending","submitted","interview","accepted","rejected"].includes(r))return e.json({error:"유효하지 않은 상태입니다."},400);const o=t.map(()=>"?").join(","),i=await e.env.DB.prepare(`
      UPDATE job_applications 
      SET application_status = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id IN (${o})
    `).bind(r,s||null,...t).run();return e.json({success:!0,message:`${t.length}개의 지원서 상태가 ${r}로 변경되었습니다.`,updatedCount:i.changes||0})}catch(t){return console.error("지원서 일괄 처리 오류:",t),e.json({error:"지원서 일괄 처리에 실패했습니다."},500)}});const rr=new Nr,en=Object.assign({"/src/index.tsx":f});let ts=!1;for(const[,e]of Object.entries(en))e&&(rr.all("*",t=>{let r;try{r=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,r)}),rr.notFound(t=>{let r;try{r=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,r)}),ts=!0);if(!ts)throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");export{rr as default};
